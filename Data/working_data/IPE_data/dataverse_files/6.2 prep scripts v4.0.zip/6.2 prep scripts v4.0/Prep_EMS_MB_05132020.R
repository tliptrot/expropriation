# /***************************
# UN International Migrant Stocks
# 2019 Update
# 
# URL: https://www.un.org/en/development/desa/population/migration/data/estimates2/estimates19.asp
# 
# Countries: 197
# Time Period: 1990-2019
#
# Miriam Barnum
# ****************************/

library(readxl)
library(tidyr)

#import
ems <- read_excel(paste(rawdata, "RAWDATA_EMS_2019.xlsx", sep=""), sheet = 2)

# clean headers, keep only observations for total stock (col 6-12)
names(ems) <- ems[11,]
names(ems)[2] <- "country"
ems <- ems[-c(1:11), c(2, 6:12)]

# reshape
ems <- pivot_longer(ems, -country, names_to = "year", values_to = "EmigrantStock")

#numeric variable types
ems$year <- as.numeric(ems$year)
ems$EmigrantStock <- as.numeric(ems$EmigrantStock)

# append IDs
ems <-  append_ids(ems, breaks = FALSE)

# check for duplicates
n_occur <- data.frame(table(vdem$gwno, vdem$year))
n_occur[n_occur$Freq>1,]

# remove regional micronesia observations
ems <- ems[!(ems$countryname_raw == "Micronesia"),]

# how many countries? what time period?
length(unique(ems$gwno)) # 197
range(ems$year) # 1990-2019

# label variables
library(Hmisc)
label(ems$EmigrantStock) =	"Total emigrant stock from [UN]"

#suffix
ems <- append_suffix(ems, "EMS")


# Save
save(ems, file = paste(preppeddata,"prepped_EMS_2019_MB.RDATA", sep=""))

