# /************************* 
# Source: Research and Expertise on the World Economy  
# Accessed: May 24, 2017
# URL(Distance):  http://www.cepii.fr/cepii/en/bdd_modele/download.asp?id=6
# URL(English as common official language): http://www.cepii.fr/CEPII/en/bdd_modele/presentation.asp?id=19
#
# By: Jessica Xu
# Revised by: Suzie Mulesky (May 1, 2018)
# Suffix: CE
#
# Variables: 
# english_off_BEL_CE = "Whether the common official language with Belgium is English [CE]"
# english_off_CHN_CE = "Whether the common official language with China is English [CE]"
# english_off_GBR_CE = "Whether the common official language with the UK is English [CE]"
# english_off_RUS_CE = "Whether the common official language with Russia is English [CE]"
# english_off_USA_CE = "Whether the common official language with the US is English [CE]"
# dist_BEL_CE = "Distance between country and Belgium (km between most populous cities) [CE]"
# dist_CHN_CE = "Distance between country and China (km between most populous cities) [CE]"
# dist_GBR_CE = "Distance between country and the UK (km between most populous cities) [CE]"
# dist_RUS_CE = "Distance between country and Russia (km between most populous cities) [CE]"
# dist_USA_CE = "Distance between country and the US (km between most populous cities) [CE]"

# *************************/
library(foreign)
library(readxl)
library(tidyr)
library(dplyr)
library(readstata13)
library(Hmisc)

# Import
dist_CEPII <- read.dta13(paste(rawdata, "RAWDATA_CEPII_dist_JX.dta", sep = ""))
English_off_CEPII <- read.dta13(paste(rawdata, "RAWDATA_CEPII_ling_JX.dta", sep = ""))

# Rename variables
names(English_off_CEPII)[names(English_off_CEPII)=="col"]="english_off"

# Keep specific rows
dist_CEPII <- dist_CEPII[c(dist_CEPII$iso_o=="USA"| dist_CEPII$iso_o=="BEL"|
                             dist_CEPII$iso_o=="CHN"| dist_CEPII$iso_o=="RUS" | 
                             dist_CEPII$iso_o == "GBR"),]


English_off_CEPII <- English_off_CEPII[c(English_off_CEPII$iso_o=="USA"| 
                                           English_off_CEPII$iso_o=="BLX"|
                                           English_off_CEPII$iso_o=="CHN"| 
                                           English_off_CEPII$iso_o=="RUS"|
                                           English_off_CEPII$iso_o == "GBR"),]


# Rename some of the ISO codes so they match 
English_off_CEPII$iso_o[English_off_CEPII$iso_o=="BLX"]<- "BEL"
English_off_CEPII$iso_d[English_off_CEPII$iso_d=="BLX"]<- "BEL"
English_off_CEPII$iso_d[English_off_CEPII$iso_d=="ROU"]<- "ROM"
English_off_CEPII$iso_d[English_off_CEPII$iso_d=="COD"]<- "ZAR"

# Drop PAL - it's Palestine and will cause problems later during the append IDs.
#dist_CEPII <- dist_CEPII[!(dist_CEPII$iso_d=="PAL"),]

# Keep only the variables we need
dist_CEPII = dist_CEPII[, c("iso_o","iso_d", "dist")]
English_off_CEPII= English_off_CEPII[,c("iso_o","country_o", "iso_d", "country_d", "english_off")]

# Convert long to wide
dist_CEPII_wide <- spread(dist_CEPII, key = iso_o, value = dist)

English_off_CEPII_wide <- English_off_CEPII %>% 
  select(-country_o) %>% 
  spread(key = iso_o, value = english_off)

# Make variable names informative
names(dist_CEPII_wide)[names(dist_CEPII_wide)=="BEL"] <- "dist_BEL"
names(dist_CEPII_wide)[names(dist_CEPII_wide)=="CHN"] <- "dist_CHN"
names(dist_CEPII_wide)[names(dist_CEPII_wide)=="GBR"] <- "dist_GBR"
names(dist_CEPII_wide)[names(dist_CEPII_wide)=="RUS"] <- "dist_RUS"
names(dist_CEPII_wide)[names(dist_CEPII_wide)=="USA"] <- "dist_USA"

names(English_off_CEPII_wide)[names(English_off_CEPII_wide)=="BEL"] <- "english_off_BEL"
names(English_off_CEPII_wide)[names(English_off_CEPII_wide)=="CHN"] <- "english_off_CHN"
names(English_off_CEPII_wide)[names(English_off_CEPII_wide)=="GBR"] <- "english_off_GBR"
names(English_off_CEPII_wide)[names(English_off_CEPII_wide)=="RUS"] <- "english_off_RUS"
names(English_off_CEPII_wide)[names(English_off_CEPII_wide)=="USA"] <- "english_off_USA"

# Merge 
CEPII <- merge (dist_CEPII_wide, English_off_CEPII_wide, by = "iso_d", all = TRUE)

#Rename variable
names(CEPII)[names(CEPII) == "country_d"] <- "country"

# Some countries have missing country names but they have iso codes
sum(is.na(CEPII$iso_d))
sum(is.na(CEPII$country))
CEPII <- mutate(CEPII, country = ifelse(is.na(country), iso_d, country))

# Check for duplicates
n_occur <- data.frame(table(CEPII$country))
n_occur[n_occur$Freq>1,]

# Append IDs
CEPII <- append_ids(CEPII, breaks = F)

# Check for duplicates
n_occur <- data.frame(table(CEPII$country))
n_occur[n_occur$Freq>1,]

# based on the distances, I think PAL is actually Palestine, but is getting assigned to Palau - MB
CEPII <- CEPII[-which(CEPII$countryname_raw == "PAL"),]

# Append Suffix
CEPII = append_suffix(CEPII, "CE")

length(unique(CEPII$gwno)) # 192


# Add variable labels
label(CEPII$english_off_BEL_CE) = "Whether the common official language with Belgium is English [CE]"
label(CEPII$english_off_CHN_CE) = "Whether the common official language with China is English [CE]"
label(CEPII$english_off_GBR_CE) = "Whether the common official language with the UK is English [CE]"
label(CEPII$english_off_RUS_CE) = "Whether the common official language with Russia is English [CE]"
label(CEPII$english_off_USA_CE) = "Whether the common official language with the US is English [CE]"

label(CEPII$dist_BEL_CE) = "Distance between country and Belgium (km between most populous cities) [CE]"
label(CEPII$dist_CHN_CE) = "Distance between country and China (km between most populous cities) [CE]"
label(CEPII$dist_GBR_CE) = "Distance between country and the UK (km between most populous cities) [CE]"
label(CEPII$dist_RUS_CE) = "Distance between country and Russia (km between most populous cities) [CE]"
label(CEPII$dist_USA_CE) = "Distance between country and the US (km between most populous cities) [CE]"

# Save
save(CEPII, file = paste(preppeddata, "PREPPED_CEPII_SM_20180501.RDATA", sep=""))

#write.csv(CEPII, file = paste(preppeddata, "PREPPED_CEPII_SM_20180501.csv", sep=""))
