# /******************/
# Data: Fariss Latent Human Rights Protection
# Dataset: HumanRightsProtectionScores
# Datasource URL: https://dataverse.harvard.edu/dataset.xhtml?persistentId=doi:10.7910/DVN/24872&studyListingIndex=0_e7af33cc17dea625f160fbbfe463
# Time: 1949 - 2010
# By: Emily Heuring
# Last Updated On: 04/15/2018
# Suffix: FA
#
# Citation:
# Fariss, Christopher J. 2014. “Respect for human rights has improved over time: Modeling the
# changing standard of accountability.” American Political Science Review 108(2): 297–318.
#
# Schnakenberg, Keith E., and Christopher J. Fariss. 2014. “Dynamic Patterns of Human Rights
# Practices.” Political Science Research and Methods 2(1): 1–31.
#
# /******************/
library(Hmisc)

#import the dataset
load(paste(rawdata,"RAWDATA_FA_2014.RDATA", sep=""))

fa <- data

#keep the variables we are interested in 
fa = fa[,c("NAME", "COW", "YEAR", "DISAP", "KILL","POLPRIS", "TORT", 
           "Amnesty", "State", "hathaway", "ITT", "genocide", "rummel", 
           "massive_repression", "executions", "killing", "additive", "latentmean", "latentsd")]

#rename country variable
names(fa)[names(fa)=="NAME"] <- "country"

#rename year variable
names(fa)[names(fa)=="YEAR"] <- "year"

#append ids
fa = append_ids(fa, breaks = F)

# check for duplicates
n_occur <- data.frame(table(fa$country, fa$year))
n_occur[n_occur$Freq>1,]

fa <- fa[!(fa$countryname_raw == "Germany" & fa$year == 1990),]
fa <- fa[!(fa$countryname_raw == "Czech Republic" & fa$year == 1992),]
fa <- fa[!(fa$countryname_raw == "Yemen" & fa$year == 1990),]

#label variables
label(fa$DISAP) <- "3 category ordered variable for disappearances from the CIRI dataset [FA]"
label(fa$KILL) <- "3 category ordered variable from extra-judicial killing the CIRI dataset [FA]"
label(fa$POLPRIS) <- "3 category ordered variable for political imprisonment from the CIRI  dataset [FA]"
label(fa$TORT) <- "3 category ordered variable for torture from the CIRI dataset [FA]"
label(fa$Amnesty) <- "5 category [FA]"
label(fa$State) <- "5 category [FA]"
label(fa$hathaway) <- "5 category ordered variable for torture from the Hathaway (2002) article [FA]"
label(fa$ITT) <- "6 category ordered varible for torture from the ITT dataset [FA]"
label(fa$genocide) <- "a binary variable for genocide from Harff's 2003 APSR article [FA]"
label(fa$rummel) <- "a binary variable for politicide/genocide based on data from Rummel [FA]"
label(fa$massive_repression) <- "a binary variable for massive repressive events taken from Harff and Gurr's 1980 ISQ article [FA]"
label(fa$executions) <- "a binary variable taken from the World Handbook of political indicators [FA]"
label(fa$killing) <- "binary version based on the UCDP one sided violence count data [FA]"
label(fa$additive) <- "the CIRI Physint scale [FA]"
label(fa$latentmean) <- "the posterior mean of the latent variable (i.e. human rights protection) [FA]"
label(fa$latentsd) <- "the standard deviation of the posterior estimates for human rights protection [FA]"

#number of unique countries
length(unique(fa$gwno)) #200

#range of dataset
range(fa$year) #1949 - 2010

#append suffix
fa = append_suffix(fa, "FA")

save(fa,file=paste(preppeddata,"PREP_FA_EH_03312018.RDATA", sep=""))
