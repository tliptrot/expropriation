####################################
#This code creates the augmented data
#using the WDI and Penn World Tables Data
#
# Grace Xu (06/29/17)
#
# edited: Miriam Barnum (11/4/2018)
# edited: Miriam Barnum (5/14/2020)
######################################

library (Hmisc)
library(dplyr)

load(paste(preppeddata,"prepped_WDI_MB_2019.RDATA",sep=""))

load(paste(preppeddata,"PREPPED_PW_SW_051420.RDATA",sep=""))

wdi_pwt <- full_join(wdi, pw) 

# population

wdi_pwt$popraw_PW <- (wdi_pwt$pop_PW*1000000)
popest <- lm(formula = wdi_pwt$pop_WDI ~ 0 + wdi_pwt$popraw_PW)
#popfit <- predict.lm(popest)

wdi_pwt$pop_WDI_PW <- ifelse(is.na(wdi_pwt$pop_WDI), wdi_pwt$popraw_PW * popest[[1]], wdi_pwt$pop_WDI)


# gdp

wdi_pwt$rgdpnaraw_PW = wdi_pwt$rgdpna_PW*1000000
gdpest <- lm(formula = wdi_pwt$gdp_WDI ~ 0 + wdi_pwt$rgdpnaraw_PW)

wdi_pwt$gdp_WDI_PW <- ifelse(is.na(wdi_pwt$gdp_WDI), wdi_pwt$rgdpnaraw_PW * gdpest[[1]], wdi_pwt$gdp_WDI)

# gdp per capita

wdi_pwt$gdppc_PW = wdi_pwt$rgdpna_PW / wdi_pwt$pop_PW
gdppcest <- lm(formula = wdi_pwt$gdppc_WDI ~ 0 + wdi_pwt$gdppc_PW)

wdi_pwt$gdppc_WDI_PW <- ifelse(is.na(wdi_pwt$gdppc_WDI), wdi_pwt$gdppc_PW * gdppcest[[1]], wdi_pwt$gdppc_WDI)

# growth

wdi_pwt$growth_PW = NA
wdi_pwt$growth_PW = as.numeric(wdi_pwt$growth_PW)

for(n in 1:nrow(wdi_pwt)){
  year = wdi_pwt[n, 'year']
  if(identical(wdi_pwt[n, 'country.x'], wdi_pwt[n+1, 'country.x']) == TRUE){
    wdi_pwt[n+1, 'growth_PW'] = (((wdi_pwt[n+1, 'rgdpna_PW']/wdi_pwt[n, 'rgdpna_PW'])-1)*100)
  }
}

growthest <- lm(formula = wdi_pwt$growth_WDI ~ 0 + wdi_pwt$growth_PW)

wdi_pwt$growth_WDI_PW <- ifelse(is.na(wdi_pwt$growth_WDI), wdi_pwt$growth_PW * growthest[[1]], wdi_pwt$growth_WDI)

# remove unneeded variables
wdi_pwt = wdi_pwt[,c(1:7, 91:ncol(wdi_pwt))]
wdi_pwt = wdi_pwt[,-c(9,11,13)]

#gdppc -- should we do this, or keep the regression version above
wdi_pwt$gdppc_WDI_PW <- wdi_pwt$gdp_WDI_PW/wdi_pwt$pop_WDI_PW

#logged variables
wdi_pwt$lnpop_WDI_PW = log(wdi_pwt$pop_WDI_PW)
wdi_pwt$lngdp_WDI_PW = log(wdi_pwt$gdp_WDI_PW)
wdi_pwt$lngdppc_WDI_PW = log(wdi_pwt$gdppc_WDI_PW)

#labels

label(wdi_pwt$gdp_WDI_PW) = "GDP (constant 2005 US$) [WDI_PW]"
label(wdi_pwt$gdppc_WDI_PW) = "Gross Domestic Product Per Capita [WDI_PW]"
label(wdi_pwt$growth_WDI_PW) = "GDP growth (annual %) [WDI_PW]"
label(wdi_pwt$pop_WDI_PW) = "Population, total [WDI_PW]"
label(wdi_pwt$lngdp_WDI_PW) = "GDP (constant 2005 US$) [WDI_PW] logged"
label(wdi_pwt$lngdppc_WDI_PW) = "Gross Domestic Product Per Capita [WDI_PW] logged"
label(wdi_pwt$lnpop_WDI_PW) = "Population, total [WDI_PW] logged"

#check for duplicates
n_occur <- data.frame(table(wdi_pwt$gwno, wdi_pwt$year))
print(n_occur[n_occur$Freq > 1,])

sum(is.na(wdi_pwt$year))
wdi_pwt <- wdi_pwt[!(is.na(wdi_pwt$year)),]
length(unique(wdi_pwt$gwno)) #200
wdi_pwt[is.na(wdi_pwt$country),] 
sum(is.na(wdi_pwt$gwno))
range(wdi_pwt$year) # 1950-2019

#save(wdi_pwt,file="prepped_WDI_PW.RDATA")
save(wdi_pwt,file=paste(preppeddata,"prepped_WDI_PW.RDATA",sep=""))
