
###############################
# Freedom House
# Version: 2018
# Accessed: February 10, 2019
# Year Range: 1972-2018
# Suffix: FH
# Last update: 02/10/2019
#
# Data: https://freedomhouse.org/report-types/freedom-world#.VbAczPlViko
# 
# Citation: Freedom House. 2018. Individual country ratings and status, FIW 1973-2018. 
# Freedom in the World. https://freedomhouse.org/report-types/freedom-world#.VbAczPlViko
# Accessed on February 10, 2019
# 
# Variables: RL: Rule of Law Index, CL: Gastil index of civil liberties, 
# PL: Gastil index of political liberties
# 
# Edited by Stephen Campbell, 2018
# Edited by Anna Lipscomb, 2019
# Edited MB 5/7/2020
###############################

#used for rl
library(readxl)
library(Hmisc)
#used for cl and pr
library(dplyr)
library(tidyr)
library(stringr)

#change from .xls to .xlsx requires setting as data frame
FHrl = data.frame("Country", "Year", "rulelaw")

#manually set column names
colnames(FHrl) = c("Country", "Year", "rulelaw")
FHrl[,1:3] = as.numeric(FHrl[,1:3])

#importing for rule of law variable from separate spreadsheets
#only goes from 2006 to 2018, because the 2003-2005 data does not include RL variable, only CL and PR which I will grab from the other dataset
sheet_year = 2006
for(sheet_year in c(2006:2018)){
  ##2019 because I need to offset the sheets by 2
  fh = read_excel(paste(rawdata, "RAWDATA_FH_rulelaw_2018.xlsx",sep=""), sheet = 2020-sheet_year)
  #renaming variables
  names(fh)[names(fh)=="F Aggr"] = "rulelaw"
  names(fh)[names(fh)=="Country/Territory"] = "Country"
  
  #adding a new column that specifies year
  fh$Year = sheet_year
  #Keep only the variables we need
  fh = fh[, c("Country",
              "Year",
              "rulelaw")]
  
  #taking out territories get a vector of all territories
  territory_vector = grep("\\*",fh$Country)
  #take them out
  fh = fh[-c(territory_vector),]
  
  FHrl = rbind(FHrl, fh)
}

FHrl = FHrl[-c(1),]

#appending gwnos
FHrl = append_ids(FHrl, breaks = F)
FHrl = append_suffix(FHrl, "FH")

#Add variable labels
label(FHrl$rulelaw_FH) = "Rule of Law Index [FH]"

length(unique(FHrl$gwno)) #198
range(FHrl$year) # 2006-2018

remove(fh)


##### part 2 #####

#importing CL and PR variables from the large dataset
fh = read_excel(paste(rawdata, "RAWDATA_FH_PRCL_2018.xls",sep=""), sheet = 2)

#adding labels and headers
fh[2,1] = "Country"
colnames(fh) = fh[2,]

#deleting all of the 'Status' variable to keep what we need
fh = fh[, -which(names(fh) %in% c("Status"))]

#they started formatting their paper differently during 1989 and thus 
#there is no data for that year because it overlaps with the 1988 and 1990 data

#create the headers
columnnames = c()
for(x in 1:47){
  pryears = paste(c(1972:2018), "_pl", sep = "")
  clyears = paste(c(1972:2018), "_cl", sep = "")
  if(x != 18){
    columnnames = append(columnnames, values = pryears[x], after = length(columnnames))
    columnnames = append(columnnames, clyears[x], after = length(columnnames))
  }
  remove(pryears)
  remove(clyears)
}

#renaming columns
colnames(fh) = c("Country", columnnames)

#cutting out headers, including empty rows of "NA" at the bottom
fh = fh[3:207,]

#reshape from all years after a country to country, yr_indicator, value
fh = gather(fh, "year", "value", 2:ncol(fh))

#split yr_indicator
year_ind = str_split_fixed(fh$year, "_", 2)

fh$year = year_ind[,1]
fh$indicator = year_ind[,2]

FHprcl <- pivot_wider(fh, names_from = "indicator", values_from = "value")

#cleanup
remove(fh)
remove(year_ind)
remove(columnnames)

#converting data to numerics
FHprcl$pl = as.numeric(FHprcl$pl)
FHprcl$cl = as.numeric(FHprcl$cl)

#append ids
FHprcl = append_ids(FHprcl, breaks = F)
FHprcl = append_suffix(FHprcl, "FH")

FHprcl <- FHprcl[!(is.na(FHprcl$pl) & is.na(FHprcl$pl)),]
FHprcl$year <- as.numeric(FHprcl$year)

# merge with RL
FHrl$countryname_raw_FH <- NULL
FH <- full_join(FHprcl, FHrl)

# Check Duplicates
n_occur <- data.frame(table(FH$countryname_raw, FH$year))
print(n_occur[n_occur$Freq > 1,])

length(unique(FH$gwno)) # 202
range(FH$year) # 1972-2018

#Add variable labels
label(FH$pl_FH) = "Gastil index of political liberties [FH]"
label(FH$cl_FH) = "Gastil index of civil liberties [FH]"

#clanup
remove(n_occur)
remove(FHprcl, FHrl)

#saving prepped data
save(FH,file=paste(preppeddata,"prepped_FH_2018.RDATA",sep=""))

