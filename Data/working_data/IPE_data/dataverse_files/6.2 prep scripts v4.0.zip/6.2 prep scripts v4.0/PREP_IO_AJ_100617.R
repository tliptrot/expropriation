# /************************* 
# Source: International Labor Mobility and the Variety of Democratic Political Institutions 
# By David H. Bearce and Andrew F. Hart
# Accessed: Sep 29, 2017
# URL: https://doi.org/10.1017/S0020818316000266
# 
# Time: 1996-2012
# Coded by: Amanda Joseph
# Revised by: Suzie Mulesky (5/7/2018)
# Suffix: IO
# *************************/

library(haven)
library(Hmisc)

#import
IO <- read_dta(paste(rawdata,"RAWDATA_IO_AJ.dta",sep = ""))

#subset the columns for ExternalLoadOpenness and FarRight
IO=IO[,c("country","year","ExternalLaborOpenness","FarRight")]

# change year variable to numeric
IO$year <- as.numeric(IO$year)

# check for duplicates
n_occur <- data.frame(table(IO$country, IO$year))
n_occur[n_occur$Freq>1,]

#append ids
IO$country[IO$country == "Korea"] <- "South Korea"
IO=append_ids(IO, breaks = FALSE)

#append suffix
IO=append_suffix(IO,"IO")

# check for duplicates
n_occur <- data.frame(table(IO$gwno, IO$year))
n_occur[n_occur$Freq>1,]

#label the variables
label(IO$FarRight_IO) = "Far Right Vote Share [IO]"
label(IO$ExternalLaborOpenness_IO) = "External Labor Openness [IO]"

# how many countries and what time period?
length(unique(IO$gwno)) # 36
range(IO$year) # 1996-2012

#save
save(IO, file = paste(preppeddata,"PREPPED_IO_AJ_100617.RDATA", sep=""))
#write.csv(IO, file = paste(preppeddata,"PREPPED_IO_AJ_100617.csv", sep=""))

