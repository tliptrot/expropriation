library(readxl)
library(Hmisc)

#importing data
ubd_splits = read_excel("/Volumes/GoogleDrive/My Drive/Master IPE Data/raw-data v2/RAWDATA_UBD_UCDP.xlsx")

#keeping only variables we need and renaming variables
#ubd_splits = ubd_splits[,c("Year", "BattleLocation","BdLow", "BdHigh", "BdBest")]
ubd_splits = ubd_splits[,c("Year", "BattleLocation","DyadID")]
ubd_splits$Country <- ubd_splits$BattleLocation
#names(ubd_splits)[names(ubd_splits)=="BattleLocation"] = "Country"

# "
# Country splits (country before semi-colon is where death numbers were assigned to):
# Line 1-2: Iran; (Iran, Iraq)
# Line 30-31, 39-41: India; (India, Pakistan)
# Line 44-45, 52-53, 60, 62: Myanmar (Burma); (Myanmar (Burma), Thailand)
# Line 103: Yemen (North Yemen); (Saudi Arabia, Yemen (North Yemen))
# Line 120-122: Israel; (Israel, Lebanon)
# Line 123: Israel; (France, Israel, Lebanon)
# Line 126: Israel; (Israel, Malta)
# Line 132: Israel; (Israel, Syria)
# Line 134: Israel; (Israel, Lebanon)
# Line 151: Myanmar (Burma); (Myanmar (Burma), Thailand)
# Line 168: Iraq; (Iraq, Syria)
# # majority of deaths occured in Syria
# Line 169: Syria; (France, Iraq, Syria, Libya)
# Line 182-183: Myanmar (Burma); (Myanmar (Burma), Thailand)
# Line 214: Iraq; (Iran, Iraq)
# Line 225: DR Congo (Zaire); (DR Congo (Zaire), Uganda)
# Line 229-230: DR Congo (Zaire); (DR Congo (Zaire), Rwanda)
# Line 242: Burundi; (Burundi, DR Congo (Zaire))
# Line 249-250, 267: Chad; (Chad, Sudan)
# Line 286: Colombia; (Colombia, Venezuela)
# Line 287: Colombia; (Colombia, Ecuador)
# Line 310: Cambodia; (Cambodia (Kampuchea), Thailand)
# Line 315: Nigeria; (Cameroon, Nigeria)
# Line 316: Nigeria; (Chad, Niger, Nigeria)
# Line 318: Syria; (Syria, Turkey)
# Line 319: Syria; (Iraq, Lebanon, Syria)
# Line 321: Syria; (Jordan, Syria)
# Line 322, 330-331: Cambodia (Kampuchea); (Cambodia (Kampuchea), Thailand)
# Line 333: Guinea; (Guinea, Liberia, Sierra Leone)
# Line 359-361: Sudan; (Sudan, Uganda)
# Line 379: Sudan; (Chad, Sudan)
# Line 381: Sudan; (Ethiopia, Sudan)
# Line 384-385: Sudan; (South Sudan, Sudan)
# Line 393, 395, 401-403: Uganda; (Sudan, Uganda)
# Line 394, 396-400: Uganda; (DR Congo (Zaire), Uganda)
# Line 404: Uganda; (DR Congo (Zaire), Sudan, Uganda)
# # Majority of deaths occured in DR Congo
# Line 406: DR Congo (Zaire); (DR Congo (Zaire), Sudan)
# Line 407-408, 410-411: DR Congo (Zaire); (Central African Republic, DR Congo (Zaire), Sudan)
# Line 409: DR Congo (Zaire); (Central African Republic, DR Congo (Zaire), South Sudan, Sudan)
# Line 414: United Kingdom; (Germany, United Kingdom)
# Line 415: United Kingdom; (Germany, Netherlands, United Kingdom)
# Line 441: Angola; (Angola, DR Congo (Zaire))
# Line 444-445, 447: Angola; (Angola, Namibia)
# Line 450, 452, 457, 463: Ethiopia; (Ethiopia, Somalia)
# Line 464: Ethiopia; (Ethiopia, Kenya)
# Line 485, 494-505: Afghanistan; (Afghanistan, Pakistan)
# Line 516-517: Somalia; (Djibouti, Somalia)
# Line 527, 531-532, 535: Somalia; (Kenya, Somalia)
# Line 533-534: Somalia; (Ethiopia, Kenya, Somalia)
# Line 536, 538-541, 543-544, 548: Iran; (Iran, Iraq)
# Line 537: Iran; (Iran, Iraq, Italy, Pakistan)
# Line 545: Iran; (Iran, Iraq, Pakistan)
# Line 550: Liberia; (Ivory Coast, Liberia)
# Line 582: Sri Lanka; (France, Sri Lanka)
# Line 598, 600-606, 608-609, 613-620: Turkey; (Iraq, Turkey)
# Line 633: India; (India, Pakistan)
# Line 679: Papua New Guinea; (Papua New Guinea, Solomon Islands)
# Line 686: Kuwait; (Iraq, Kuwait, Philippines, Saudi Arabia)
# Line 702-703, 711: Rwanda; (DR Congo (Zaire), Rwanda)
# Line 713, 718: Senegal; (Guinea-Bissau, Senegal)
# Line 739: Sierra Leone; (Liberia, Sierra Leone)
# Line 767: Algeria; (Algeria, Chad, Niger)
# Line 768: Algeria; (Algeria, Mali)
# Line 789-791, 794, 796, 798: Azerbaijan; (Armenia, Azerbaijan)
# Line 799: Bosnia-Herzegovina; (Bosnia-Herzegovina, Croatia, Serbia (Yugoslavia))
# Line 803, 805, 833: Bosnia-Herzegovina; (Bosnia-Herzegovina, Croatia)
# Line 808: Egypt; (Egypt, Ethiopia)
# Line 820, 822: Tajikistan; (Afghanistan, Tajikistan)
# Line 847: Russia (Soviet Union); (Qatar, Russia (Soviet Union))
# Line 852: Peru; (Ecuador, Peru)
# Line 861, 865: Pakistan; (Afghanistan, Pakistan)
# Line 871: Congo; (Congo, DR Congo (Zaire))
# #More deaths on Ethiopia side
# Line 874-876: Ethiopia; (Eritrea, Ethiopia)
# Line 881: Serbia (Yugoslavia); (Albania, Serbia (Yugoslavia))
# Line 889, 891: Ethiopia; (Ethiopia, Kenya)
# Line 906: Uzbekistan; (Kyrgyzstan, Uzbekistan)
# Line 908: Uzbekistan; (Kyrgyzstan, Tajikistan, Uzbekistan)
# Line 910: Central African Republic; (Central African Republic, Chad)
# Line 917: Macedonia; (Macedonia, FYR)
# Line 918: Afghanistan; (Afghanistan, Pakistan, United States of America)
# Line 919-920, 927: Afghanistan; (Afghanistan, Pakistan)
# Line 921-923: Afghanistan; (Afghanistan, Pakistan, Saudi Arabia)
# Line 924: Afghanistan; (Afghanistan, Pakistan, Saudi Arabia, Somalia)
# Line 925: Afghanistan; (Afghanistan, Pakistan, Somalia, Yemen (North Yemen))
# Line 926, 928-930: Afghanistan; (Afghanistan, Pakistan, Somalia)
# Line 931-932: Afghanistan; (Afghanistan, Pakistan, Syria)
# Line 942: India; (Bhutan, India)
# Line 971: Lebanon; (Argentina, Israel, Lebanon)
# Line 972, 974-975, 979: Lebanon; (Israel, Lebanon)
# Line 991: Russia (Soviet Union); (Russia (Soviet Union), Turkey)
# Line 995: Russia (Soviet Union); (Russia (Soviet Union), Syria)
# Line 999, 1001: Myanmar (Burma); (China, Myanmar (Burma))
# # Mauritanian army in Mali
# Line 1002-1003: Mali; (Mali, Mauritania)
# Line 1019: Mali; (Mali, Niger)
# Line 1024: South Sudan; (South Sudan, Sudan)
# Line 1027: Myanmar (Burma); (India, Myanmar (Burma))
# Line 1032: Malaysia; (Malaysia, Philippines)
# Line 1038: Ukraine; (Russia (Soviet Union), Ukraine)
# Line 1055: Kenya; (Kenya, Somalia)
# "

#assigning the deaths to only one country
ubd_splits[c(1:2),2] = "Iran"
ubd_splits[c(30:31,39:41),2] = "India"
ubd_splits[c(44:45,52:53,60,62),2] = "Myanmar (Burma)"
ubd_splits[c(103),2] = "Yemen (North Yemen)"
ubd_splits[c(120:122),2] = "Israel"
ubd_splits[c(123),2] = "Israel"
ubd_splits[c(126),2] = "Israel"
ubd_splits[c(132),2] = "Israel"
ubd_splits[c(134),2] = "Israel"
ubd_splits[c(151),2] = "Myanmar (Burma)"
ubd_splits[c(168),2] = "Iraq"
ubd_splits[c(169),2] = "Syria"
ubd_splits[c(182:193),2] = "Myanmar (Burma)"
ubd_splits[c(214),2] = "Iraq"
ubd_splits[c(225),2] = "DR Congo (Zaire)"
ubd_splits[c(229:230),2] = "DR Congo (Zaire)"
ubd_splits[c(242),2] = "Burundi"
ubd_splits[c(249:250,267),2] = "Chad"
ubd_splits[c(286),2] = "Colombia"
ubd_splits[c(287),2] = "Colombia"
ubd_splits[c(310),2] = "Cambodia (Kampuchea)"
ubd_splits[c(315),2] = "Nigeria"
ubd_splits[c(316),2] = "Nigeria"
ubd_splits[c(318),2] = "Syria"
ubd_splits[c(319),2] = "Syria"
ubd_splits[c(321),2] = "Syria"
ubd_splits[c(322,330:331),2] = "Cambodia (Kampuchea)"
ubd_splits[c(333),2] = "Guinea"
ubd_splits[c(359:361),2] = "Sudan"
ubd_splits[c(379),2] = "Sudan"
ubd_splits[c(381),2] = "Sudan"
ubd_splits[c(384:385),2] = "Sudan"
ubd_splits[c(393,395,401:403),2] = "Uganda"
ubd_splits[c(394,396:400),2] = "Uganda"
ubd_splits[c(404),2] = "Uganda"
ubd_splits[c(406),2] = "DR Congo (Zaire)"
ubd_splits[c(407:408,410:411),2] = "DR Congo (Zaire)"
ubd_splits[c(409),2] = "DR Congo (Zaire)"
ubd_splits[c(414),2] = "United Kingdom"
ubd_splits[c(415),2] = "United Kingdom"
ubd_splits[c(441),2] = "Angola"
ubd_splits[c(444:445,447),2] = "Angola"
ubd_splits[c(450,452,457,463),2] = "Angola"
ubd_splits[c(464),2] = "Ethiopia"
ubd_splits[c(485,494:505),2] = "Afghanistan"
ubd_splits[c(516:517),2] = "Somalia"
ubd_splits[c(527,531:532,535),2] = "Somalia"
ubd_splits[c(533:534),2] = "Somalia"
ubd_splits[c(536,538:541,543:544,548),2] = "Iran"
ubd_splits[c(537),2] = "Iran"
ubd_splits[c(545),2] = "Iran"
ubd_splits[c(550),2] = "Liberia"
ubd_splits[c(582),2] = "Sri Lanka"
ubd_splits[c(598,600:606,608:609,613:620),2] = "Turkey"
ubd_splits[c(633),2] = "India"
ubd_splits[c(679),2] = "Papua New Guinea"
ubd_splits[c(686),2] = "Kuwait"
ubd_splits[c(702:703,711),2] = "Rwanda"
ubd_splits[c(713,718),2] = "Senegal"
ubd_splits[c(739),2] = "Sierra Leone"
ubd_splits[c(767),2] = "Algeria"
ubd_splits[c(768),2] = "Algeria"
ubd_splits[c(789:791,794,796,798),2] = "Azerbaijan"
ubd_splits[c(799),2] = "Bosnia-Herzegovina"
ubd_splits[c(803,805,833),2] = "Bosnia-Herzegovina"
ubd_splits[c(808),2] = "Egypt"
ubd_splits[c(820,822),2] = "Tajikistan"
ubd_splits[c(847),2] = "Russia"
ubd_splits[c(852),2] = "Peru"
ubd_splits[c(861,865),2] = "Pakistan"
ubd_splits[c(871),2] = "Congo"
ubd_splits[c(874:876),2] = "Ethiopia"
ubd_splits[c(881),2] = "Serbia"
ubd_splits[c(889,891),2] = "Ethiopia"
ubd_splits[c(906),2] = "Uzbekistan"
ubd_splits[c(908),2] = "Uzbekistan"
ubd_splits[c(910),2] = "Central African Republic"
ubd_splits[c(917),2] = "Macedonia"
ubd_splits[c(918),2] = "Afghanistan"
ubd_splits[c(919:920,927),2] = "Afghanistan"
ubd_splits[c(921:923),2] = "Afghanistan"
ubd_splits[c(924),2] = "Afghanistan"
ubd_splits[c(925),2] = "Afghanistan"
ubd_splits[c(926,928:930),2] = "Afghanistan"
ubd_splits[c(931:932),2] = "Afghanistan"
ubd_splits[c(942),2] = "India"
ubd_splits[c(971),2] = "Lebanon"
ubd_splits[c(972,974:975,979),2] = "Lebanon"
ubd_splits[c(991),2] = "Russia (Soviet Union)"
ubd_splits[c(995),2] = "Russia (Soviet Union)"
ubd_splits[c(999,1001),2] = "Myanmar (Burma)"
ubd_splits[c(1002:1003),2] = "Mali"
ubd_splits[c(1019),2] = "Mali"
ubd_splits[c(1024),2] = "South Sudan"
ubd_splits[c(1027),2] = "Myanmar (Burma)"
ubd_splits[c(1032),2] = "Malaysia"
ubd_splits[c(1038),2] = "Ukraine"
ubd_splits[c(1055),2] = "Kenya"

# converting conflict IDs to new system
conf_ids <- read.csv("/Users/miriam/Downloads/translate_dyad.csv") %>% filter(type_of_violence == 1)
#conf_ids$old_id <- as.numeric(conf_ids$old_id)
ubd_splits <- separate(ubd_splits, DyadID, c("dyad_id", "dyad_id2"), remove = T) %>%
  mutate_at(vars(dyad_id, dyad_id2), as.numeric) %>%
  pivot_longer(3:4, names_to = "id_pos", values_to = "dyad_id") %>%
  left_join(conf_ids, c("dyad_id" = "old_id")) %>%
  filter(!is.na(dyad_id))

save(ubd_splits, file = paste(rawdata, "rawdata_ubd_splits.RDATA", sep=""))
