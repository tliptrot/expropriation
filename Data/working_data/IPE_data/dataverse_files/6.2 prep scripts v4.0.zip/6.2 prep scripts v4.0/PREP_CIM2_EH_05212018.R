###############################
# IMF Contract Intensive Money
# Version: 2017
# Accessed: July 13, 2017
# Updated On: May 5, 2018
# Updated By: EH
# Year Range: 1950-2016
# Suffix: CIM2
#
# Updated Data of Quasi-Money: http://data.imf.org/?sk=388DFA60-1D26-4ADE-B505-A05A558D9A42&sId=1479331931186 
#
# Updated Data of Currency Outside Other Depository Corporations: http://data.imf.org/?sk=388DFA60-1D26-4ADE-B505-A05A558D9A42&sId=1479331931186
# 
# Updated Variable: cim2_CIM2 
###############################

library(readxl)
library(Hmisc)
library(reshape2)
library(tidyr)
library(plyr)

#importing raw data
CIM2 = read_excel(paste(rawdata, "RAWDATA_CIM.xlsx", sep=""))

#change year from wide to long
CIM2 = gather(CIM2, "Year", "value",3:ncol(CIM2))

# stripping white space for dcast function later
colnames(CIM2) = trimws(colnames(CIM2), which = c("both"))

#change concept from long to wide
CIM2 = dcast(CIM2, country + Year ~ concept, value.var = "value" )

#trim again
colnames(CIM2) = trimws(colnames(CIM2), which = c("both"))

#renaming variables
CIM2 = rename(CIM2, c("NA" = "cim2"))
CIM2 = rename(CIM2, c("Currency Outside Other Depository Corporations" = "CO"))
CIM2 = rename(CIM2, c("Quasi_Money" = "QM"))

#calculate CIM = 1-(currency outside other depository corporations/quasi_money)
CIM2$cim2 <- (1-(CIM2$CO/CIM2$QM))

#drop na country names 
CIM2 <- CIM2[complete.cases(CIM2),]

# Add variable labels
label(CIM2$cim2) = "Contract intensive money [IMF_IFS]"

#Keep only the variables we need
CIM2= CIM2[, c("country",
            "Year",
            "cim2")]

#appending gwnos
CIM2 = append_ids(CIM2, breaks = F)

#append suffix
CIM2 = append_suffix(CIM2, "CIM")

# Checking for duplicates - there are none
n_occur <- data.frame(table(CIM2$gwno, CIM2$year))
n_occur[n_occur$Freq > 1,]

length(unique(CIM2$gwno))  #159
range(CIM2$year) #1950-2016

save(CIM2,file=paste(preppeddata,"PREP_CIM2_EH_05052018.RDATA",sep=""))
