###############################
# Transparency International Corruption Perceptions Index [TI]
# Version: 2016
# Accessed: April 26, 2017
# Year Range: 1995-2018
# Prepped By: Rohit Madan
# Updated By: Emily Heuring
# Suffix: TI
# Last update: 03/21/2019
# Updated By: Baiyu Zhu
#
# Data: http://www.transparency.org/permissions/#datasets
# 
#
# Citation: Transparency International. 2016."Corruption Perceptions Index 2016." 
# http://www.transparency.org/permissions/#datasets. Accessed on April 26, 2016.
#
# Variables: ti_cpi_TI, Label: "Corruption perceptions index [TI]"
#
# Note: This code updates the data from 1995-2014 in the current version of the IPE to 1995-2016.
# Note: Methodology changes after 2012. Scores go from 0-10 to 0-100. 
# 
###############################

library(readxl)
library(reshape2)
library(Hmisc)

#Read raw data 
ti = read_excel(path = (paste(rawdata, "RAWDATA_TI_2011.xlsx", sep="")), sheet = "CPI 1995-2016", skip = 2)

ti <- ti[-c(1), ]

varsToKeep <- c("Country/Territory...19", "2011 CPI Score", "2010 CPI Score", "2009 CPI Score", "2008 CPI Score", "2007 CPI Score", "2006 CPI Score", "2005 CPI Score", "2004 CPI Score", "2003 CPI Score", "2002 CPI Score", "2001 CPI Score", "2000 CPI Score", "1999 CPI Score", "1998 CPI Score", "1997 CPI Score", "1996 CPI Score", "1995 CPI Score")
ti <- ti[varsToKeep]

#Change variable names to make reshape possible
names(ti)[2:18] <- substr(names(ti)[2:18], 1,4)

ti2 = read_excel(path = (paste(rawdata, "RAWDATA_TI_2018.xlsx", sep="")), sheet = "CPI Timeseries 2012 - 2018", skip = 2)

ti2 <- ti2[-c(1), ]

varsToKeep <- c("Country", "CPI score 2018", "CPI score 2017", "CPI score 2016", "CPI score 2015", "CPI score 2014", "CPI Score 2013", "CPI Score 2012")
ti2 <- ti2[varsToKeep]
#Change variable names to make reshape possible
names(ti2)[2:8] <- substr(names(ti2)[2:8], 11,14)

#Reshape
# Specify id.vars: the variables to keep but not split apart on
ti <- melt(ti, id.vars=c("Country/Territory...19"))

#Change names
#Change name of variable
names(ti)[names(ti)=="Country/Territory...19"] <- "Country"
names(ti)[names(ti)=="variable"] <- "year"
names(ti)[names(ti)=="value"] <- "ti_cpi"

#cast to int
ti$year <- as.numeric(as.character(ti$year))
ti$ti_cpi <- as.numeric(as.character(ti$ti_cpi))

sum(is.na(ti$Country))

#Repeat the reshape process for ti2(second half of the data set)
ti2 <- melt(ti2, id.vars=c("Country"))
names(ti2)[names(ti2)=="variable"] <- "year"
names(ti2)[names(ti2)=="value"] <- "ti_cpi"
ti2$year <- as.numeric(as.character(ti2$year))
ti2$ti_cpi <- as.numeric(as.character(ti2$ti_cpi))
sum(is.na(ti2$Country))

#Merge the two data frames
total <- rbind(ti, ti2)
total <- total[order(total[,2]),]

#Append IDs
total <- append_ids(total, breaks = F)

#Remove wrong rows
total <- total[!(total$country == "Serbia" & total$countryname_raw == "Yugoslavia"),]
total <- total[!(total$country == "Yugoslavia" & total$countryname_raw == "Serbia"),]

#Check for Duplicates
n_occur <- data.frame(table(total$country, total$year))
print(n_occur[n_occur$Freq > 1,])

append_suffix(total, "TI")

#Label
label(total$ti_cpi_TI) <- "Corruption perceptions index [TI]" 

#check number of countries
length(unique(total$gwno)) #187

#check range of dataset 
range(total$year) #1995 - 2016

#save prepped data
save(total,file=paste(preppeddata,"PREPPED_TI_BZ_0321_2019.RDATA",sep=""))
