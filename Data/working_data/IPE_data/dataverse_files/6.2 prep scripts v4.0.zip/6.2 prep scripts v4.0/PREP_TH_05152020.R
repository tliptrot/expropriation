# /************************* 
# Tax Heaven DOT
# extrapolate through 2019
# Handle Korea
# *************************/

library(Hmisc)
library(readstata13)

# Read the dta file from prepped data folder
TH <-read.dta13(paste(rawdata,"RAWDATA_TH.dta", sep=""))


# Drop gwno == 730 & year > 1947
TH = TH[-which(TH$gwno == 730 & TH$year > 1947),]


# Add variable labels
label(TH$taxhavwhen_TH) = "Year estimate of when the state became a tax haven [DOT]"
label(TH$taxhav_TH) = "Binary, 1 if considered a tax haven, 0 if not [DOT]"
label(TH$taxhavens_extrapolated_TH) = "Binary, 1 if considered a tax haven, 0 if not. Extrapolated from taxhav [DOT]"
TH$year <- as.numeric(TH$year)

# add extrapolation through 2019
for(i in 2016:2019){
  tmp <- TH[TH$year == 2015,]
  tmp$year <- i
  TH <- rbind(TH, tmp)
}


length(unique(TH$gwno)) #204
range(TH$year) #1983-2015

save(TH,file=paste(preppeddata,"PREPPED_TH_SW_070717.RDATA",sep=""))



