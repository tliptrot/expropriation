# /************************* 
# Source: EU,IMF,NATO,WTO,OECD  
# Accessed: May 25, 2017
# URL(EU):http://europa.eu/about-eu/countries/
# URL(IMF):http://www.imf.org/external/np/sec/memdir/memdate.htm
# URL(NATO):http://www.nato.int/cps/en/natolive/topics_52044.htm
# URL(OECD):http://www.oecd.org/about/membersandpartners/list-oecd-member-countries.htm
# URL(WTO):http://www.wto.org/english/thewto_e/whatis_e/tif_e/org6_e.htm
# Query specifications: all countries, all years, variables: WTOwhen_WTO, WTOmem_WTO, IMFwhem_IMF, IMFmem_IMF, NATOwhen_NATO, NATOmem_NATO, euwhen_EU, eumem_EU, oecd_joinyear_OE,oecd_OE
# Time: 1945-2018
# By: Jessica Xu
# Updated by Anna Lipscomb, April 2019
# Edited MB, May 2020
# Suffix: MEM
# Variables: WTOwhen_WTO: year of accession [WTO], WTOmem_WTO: binary, 1 if member, 0 if not [WTO], IMFwhen_IMF:year of accession [IMF],  IMFmem_IMF:binary, 1 if member, 0 if not [IMF],  NATOwhen_NATO:year of accession [NATO], NATOmem_NATO:binary, 1 if member, 0 if not [NATO],  euwhen_EU:year of accession [EU],  eumem_EU:binary, 1 if member, 0 if not [EU],  oecd_joinyear_OE:year of accession [OECD], oecd_OE:binary, 1 if member, 0 if not [OECD]
# *************************/

library(readxl)
library(dplyr)
library(Hmisc)

#import
MEM <- read_excel(paste(rawdata, "RAWDATA_MEM_2018.xlsx", sep=""))

#renaming variables
names(MEM)[names(MEM)=="Eu"]="EUmem"
names(MEM)[names(MEM)=="Eu when"] = "EUwhen"
names(MEM)[names(MEM)=="NATO"] = "NATOmem"
names(MEM)[names(MEM)=="NATO When"] = "NATOwhen"
names(MEM)[names(MEM)=="WTO"] = "WTOmem"
names(MEM)[names(MEM)=="WTO when"] = "WTOwhen"
names(MEM)[names(MEM)=="IMF"] = "IMFmem"
names(MEM)[names(MEM)=="IMF When"] = "IMFwhen"
names(MEM)[names(MEM)=="OECD"] = "OECDmem"
names(MEM)[names(MEM)=="OECD When"] = "OECDwhen"

#label
label(MEM$EUmem) <- "binary, 1 if member, 0 if not [EU]"
label(MEM$EUwhen) <- "year of accession [EU]"
label(MEM$WTOwhen) <- " year of accession [WTO]"
label(MEM$WTOmem) <- "binary, 1 if member, 0 if not [WTO]"
label(MEM$IMFwhen) <- " year of accession [IMF]"
label(MEM$IMFmem) <- "binary, 1 if member, 0 if not [IMF]"
label(MEM$NATOwhen) <- " year of accession [NATO]"
label(MEM$NATOmem) <- "binary, 1 if member, 0 if not [NATO]"
label(MEM$OECDwhen) <- "year of accession [OECD]"
label(MEM$OECDmem) <- "binary, 1 if member, 0 if not [OECD]"

#appending gwnos
MEM = append_ids(MEM, breaks = F)
sum(is.na(MEM$country))

# Merge MEM and Simple CI
load(paste(rawdata, "Country_GWNO_Year_Simple.RDATA", sep = ""))
MEM <- left_join(simpleCY, MEM) %>%
  filter(!is.na(country)) %>%
  mutate(EUmem = ifelse(is.na(EUwhen), 0, as.numeric(year >= EUwhen)), 
         NATOmem = ifelse(is.na(NATOwhen), 0, as.numeric(year >= NATOwhen)), 
         WTOmem = ifelse(is.na(WTOwhen), 0, as.numeric(year >= WTOwhen)), 
         IMFmem = ifelse(is.na(IMFwhen), 0, as.numeric(year >= IMFwhen)), 
         OECDmem = ifelse(is.na(OECDwhen), 0, as.numeric(year >= OECDwhen)))


#append suffix
MEM = append_suffix(MEM, "MEM")

save(MEM,file=paste(preppeddata,"PREPPED_MEM_2018_AL.RDATA",sep=""))
