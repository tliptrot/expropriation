#/**************************
# Source: Freedom House 
# Dataset: Freedom of the Press 
# Data source url: https://freedomhouse.org/report-types/freedom-press 
# Codebook url: https://freedomhouse.org/report/freedom-press-2016-methodology 
# Time: 1979-2016
# Created By: Baiyu Zhu
# Edited MB 05/07/2020
# Data download: 2019. 04. 23
# Suffix: FHP
# 
# Notes:
#  Adjustments made for Serbia, Montenegro, Yugoslavia transition
#  at end of file. Has separate observations for Montenegro/Serbia from 2006.
#****************************/

library(Hmisc)
library(readxl)
library(dplyr)
library(stringr)
library(tidyr)

# --- Import dataset
FHP = read_excel(paste(rawdata,"RAWDATA_FHP_2017.xlsx", sep=""), 2, col_names = TRUE)

# --- Create variable names
names(FHP)[1] = "country"
names(FHP)[2] = "p_1979"
names(FHP)[3] = "b_1979"
names(FHP)[4] = "p_1980"
names(FHP)[5] = "b_1980"
names(FHP)[6] = "p_1981"
names(FHP)[7] = "b_1981" 
names(FHP)[8] = "p_1982"
names(FHP)[9] = "b_1982"
names(FHP)[10] =	"p_1983"
names(FHP)[11] = "b_1983"
names(FHP)[12] =	"p_1984"
names(FHP)[13] = "b_1984"
names(FHP)[14] =	"p_1985"
names(FHP)[15] = "b_1985"
names(FHP)[16] =	"p_1986"
names(FHP)[17] =	"b_1986"
names(FHP)[18] = "ss_1988"
names(FHP)[19] = "ss_1989"
names(FHP)[20] = "ss_1990"
names(FHP)[21] = "ss_1991"
names(FHP)[22] = "ss_1992"

names(FHP)[23] = "A:broadcast_1993"
names(FHP)[24] = "A:print_1993"
names(FHP)[25] = "B:broadcast_1993"
names(FHP)[26] = "B:print_1993"
names(FHP)[27] = "C:broadcast_1993"
names(FHP)[28] = "C:print_1993"
names(FHP)[29] = "D:broadcast_1993"
names(FHP)[30] = "D:print_1993"
names(FHP)[31] = "sr_1993"
names(FHP)[32] = "ss_1993"
names(FHP)[33] = "A:broadcast_1994"
names(FHP)[34] = "A:print_1994"
names(FHP)[35] = "B:broadcast_1994"
names(FHP)[36] = "B:print_1994"
names(FHP)[37] = "C:broadcast_1994"
names(FHP)[38] = "C:print_1994"
names(FHP)[39] = "D:broadcast_1994"
names(FHP)[40] = "D:print_1994"
names(FHP)[41] = "sr_1994"
names(FHP)[42] = "ss_1994"
names(FHP)[43] = "A:broadcast_1995"
names(FHP)[44] = "A:print_1995"
names(FHP)[45] = "B:broadcast_1995"
names(FHP)[46] = "B:print_1995"
names(FHP)[47] = "C:broadcast_1995"
names(FHP)[48] = "C:print_1995"
names(FHP)[49] = "D:broadcast_1995"
names(FHP)[50] = "D:print_1995"
names(FHP)[51] = "sr_1995"
names(FHP)[52] = "ss_1995"
names(FHP)[53] = "A:broadcast_1996"
names(FHP)[54] = "A:print_1996"
names(FHP)[55] = "B:broadcast_1996"
names(FHP)[56] = "B:print_1996"
names(FHP)[57] = "C:broadcast_1996"
names(FHP)[58] = "C:print_1996"
names(FHP)[59] = "D:broadcast_1996"
names(FHP)[60] = "D:print_1996"
names(FHP)[61] = "sr_1996"
names(FHP)[62] = "ss_1996"
names(FHP)[63] = "A:broadcast_1997"
names(FHP)[64] = "A:print_1997"
names(FHP)[65] = "B:broadcast_1997"
names(FHP)[66] = "B:print_1997"
names(FHP)[67] = "C:broadcast_1997"
names(FHP)[68] = "C:print_1997"
names(FHP)[69] = "D:broadcast_1997"
names(FHP)[70] = "D:print_1997"
names(FHP)[71] = "sr_1997"
names(FHP)[72] = "ss_1997"
names(FHP)[73] = "A:broadcast_1998"
names(FHP)[74] = "A:print_1998"
names(FHP)[75] = "B:broadcast_1998"
names(FHP)[76] = "B:print_1998"
names(FHP)[77] = "C:broadcast_1998"
names(FHP)[78] = "C:print_1998"
names(FHP)[79] = "D:broadcast_1998"
names(FHP)[80] = "D:print_1998"
names(FHP)[81] = "sr_1998"
names(FHP)[82] = "ss_1998"
names(FHP)[83] = "A:broadcast_1999"
names(FHP)[84] = "A:print_1999"
names(FHP)[85] = "B:broadcast_1999"
names(FHP)[86] = "B:print_1999"
names(FHP)[87] = "C:broadcast_1999"
names(FHP)[88] = "C:print_1999"
names(FHP)[89] = "D:broadcast_1999"
names(FHP)[90] = "D:print_1999"
names(FHP)[91] = "sr_1999"
names(FHP)[92] = "ss_1999"
names(FHP)[93] = "A:broadcast_2000"
names(FHP)[94] = "A:print_2000"
names(FHP)[95] = "B:broadcast_2000"
names(FHP)[96] = "B:print_2000"
names(FHP)[97] = "C:broadcast_2000"
names(FHP)[98] = "C:print_2000"
names(FHP)[99] = "D:broadcast_2000"
names(FHP)[100] = "D:print_2000"
names(FHP)[101] = "sr_2000"
names(FHP)[102] = "ss_2000"


index <- 103
year <- 2000
while (index < 183) {
  year = year + 1
  yearstr = toString(year)
  names(FHP)[index] = paste("A:legal_", yearstr, sep="")
  names(FHP)[index+1] = paste("B:political_", yearstr, sep="")
  names(FHP)[index+2] = paste("C:economic_", yearstr, sep="")
  names(FHP)[index+3] = paste("sr_", yearstr, sep="")
  names(FHP)[index+4] = paste("ss_", yearstr, sep="")
  index = index + 5
}

FHP = FHP[-c(1:4),]
#FHP[FHP == "N/A"] = NA
#FHP[FHP == "-"] = NA

# --- Reshape data
FHP = gather(FHP, "year", "value", 2:ncol(FHP))

# --- Split the year variable 
year_ind = str_split_fixed(FHP$year, "_", 2)

FHP$indicator = year_ind[,1]
FHP$year = year_ind[,2]

FHP <- pivot_wider(FHP, names_from = indicator, values_from = value)
names(FHP) <- gsub("print", "p", names(FHP))
names(FHP) <- gsub("broadcast", "b", names(FHP))
names(FHP) <- gsub(":", "_", names(FHP))

FHP$sr = as.numeric(FHP$sr)

# --- Relabel values
# NF = not free = 0
# PF = partly free = 1
# F = free = 2
FHP[FHP == "NF"] = "0"
FHP[FHP == "PF"] = "1"
FHP[FHP == "F"] = "2"
FHP <- mutate_at(FHP, 3:ncol(FHP), as.numeric)

# --- Checking for duplicates: no duplicates
n_occur <- data.frame(table(FHP$country, FHP$year))
n_occur[n_occur$Freq > 1,]

# --- Append IDs
FHP = append_ids(FHP, breaks = F)
FHP = append_suffix(FHP, "FHP")

# --- Checking for duplicates: there are many duplicates
n_occur <- data.frame(table(FHP$country, FHP$year))
n_occur[n_occur$Freq > 1,]

# --- Drop the duplicates
# Germany duplicates
FHP = FHP[!(FHP$countryname_raw_FHP == "Germany, West" & FHP$year >= 1990),]
FHP = FHP[-which(FHP$countryname_raw_FHP == "Germany" & FHP$year <= 1989),]

# Russia duplicates
FHP = FHP[-which(FHP$countryname_raw_FHP == "USSR" & FHP$year >= 1992),]
FHP = FHP[-which(FHP$countryname_raw_FHP == "Russia" & FHP$year <= 1991),]

# Yemen duplicates
FHP = FHP[-which(FHP$countryname_raw_FHP == "Yemen, North" & FHP$year >= 1990),]
FHP = FHP[-which(FHP$countryname_raw_FHP == "Yemen" & FHP$year <= 1989),]

# Czechoslovakia / Czech Republic duplicates
FHP = FHP[-which(FHP$countryname_raw_FHP == "Czechoslovakia" & FHP$year >= 1993),]
FHP = FHP[-which(FHP$countryname_raw_FHP == "Czech Republic" & FHP$year <= 1992),]

# Yugoslavia / Serbia & Montenegro duplicates
FHP = FHP[-which(FHP$countryname_raw_FHP == "Yugoslavia" & FHP$year >= 1993),]
FHP = FHP[-which(FHP$countryname_raw_FHP == "Serbia and Montenegro" & FHP$year <= 1992),]

# Serbia duplicates
FHP = FHP[-which(FHP$countryname_raw_FHP == "Serbia and Montenegro" & FHP$year >= 2006),]
FHP = FHP[-which(FHP$countryname_raw_FHP == "Serbia" & FHP$year >= 1993),]
FHP = FHP[-which(FHP$countryname_raw_FHP == "Serbia" & FHP$year >= 1979 & FHP$year <= 1992),]

# --- Number of countries in the dataset = 199
length(unique(FHP$country))
n_countries = FHP %>%
  group_by(country) %>%
  dplyr::summarise(n_years = n() ) %>%
  arrange(desc(n_years))
View(n_countries)

# --- Year range
range(FHP$year) #1979-2016

# --- Variable labels
label(FHP$p_FHP) = "Printing press freedom [FHP]"
label(FHP$b_FHP) = "Broadcast press freedom [FHP]"
label(FHP$ss_FHP) = "Free status [FHP]"
label(FHP$sr_FHP) = "Numerical score [FHP]"
label(FHP$A_p_FHP) = "Laws and Regulations in printing"
label(FHP$A_b_FHP) = "Laws and Regulations in broadcasting"
label(FHP$B_p_FHP) = "Political pressures and controls in printing"
label(FHP$B_b_FHP) = "Political pressures and controls in broadcasting"
label(FHP$C_p_FHP) = "Economic influences on printing"
label(FHP$C_b_FHP) = "Economic influences on broadcasting"
label(FHP$D_p_FHP) = "Repressive actions in printing"
label(FHP$D_b_FHP) = "Repressive actions in broadcasting"
label(FHP$A_legal_FHP) = "Legal Environment"
label(FHP$B_political_FHP) = "Political Environment"
label(FHP$C_economic_FHP) = "Economic Environment"


# --- Saving prepped data
save(FHP,file=paste(preppeddata,"prepped_FHP_BZ.RDATA",sep=""))
