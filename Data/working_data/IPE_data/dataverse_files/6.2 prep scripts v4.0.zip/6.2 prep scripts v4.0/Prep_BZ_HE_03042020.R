# the following code cannot be used since the updated sheet is not coherent with RAWDATA_BZ file
# here's the workout of solution:
# go through the indicator name and find the variables we need, change the name to the variable name
# assign it to a new column name for a new dataset
# then to the new dataset, go thorugh the previous column again and for the corresponding data, assign it to the new dataset

# use a dictionary for the conversion
# information on dictionary
# https://github.com/mkuhn/dict


# load the master DBI dataset
load(paste(rawdata, "OLD_PREPPED_BZ.rdata", sep=""))

# prepping the updated dataset and merging it to the master BZ dataset
# prepping code from "Prep_BZ_GX_160317" edited by Huiyeon
library(readxl)
library(plyr)
library(Hmisc)
library(dict)
library(tidyverse)

# read the excel file for the updated variables
bz_update <- read_excel(paste(rawdata,"DBI_2019.xlsx", sep=""), sheet = "Data", col_names = TRUE)

# change the column name for append_ids function
names(bz_update)[names(bz_update)=="Country Name"] = "Country"

# creating a dictionary with key as the indicator name and value as the variable name 
d <- dict()

# putting key-value pair to the dictionary 
# bz = rename(bz, c("Economy" = "Country"))
d[["Rank: Ease of doing business index (DB19 methodology) (1=most business-friendly regulations)"]] <- "rank_BZ"
d[["Rank: Starting a business (DB19 methodology)"]] <- "rank_sb_BZ" 
d[["Starting a business: Procedures required - Men (number)"]] <- "sb_proc_BZ"
d[["Starting a business: Time - Men (days)"]] <- "sb_time_BZ"
d[["Starting a business: Cost - Men (% of income per capita)"]] <- "sb_cost_BZ"
d[["Starting a business: Minimum capital (% of income per capita)"]] <- "sb_paid_BZ"
d[["Rank: Dealing with construction permits  (DB19 methodology) (1=most business-friendly regulations)"]] <- "rank_cp_BZ"
d[["Dealing with construction permits: Procedures (number)"]] <- "cp_proc_BZ"
d[["Dealing with construction permits: Time (days)"]] <- "cp_time_BZ"
d[["Dealing with construction permits: Cost (% of Warehouse value)"]] <- "cp_cost_BZ"
d[["Rank: Getting electricity (1=most business-friendly regulations) (DB19 methodology)"]] <- "rank_ge_BZ"
d[["Getting electricity: Procedures (number)"]] <- "ge_proc_BZ"
d[["Getting electricity: Time (days)"]] <- "ge_time_BZ"
d[["Getting electricity: Cost to get electricity (% of income per capita)"]] <- "ge_cost_BZ"
d[["Rank: Registering property (1=most business-friendly regulations)  (DB19 methodology)"]] <- "rank_rp_BZ"
d[["Registering property: Procedures (number)"]] <- "rp_proc_BZ"
d[["Registering property: Time (days)"]] <- "rp_time_BZ"
d[["Registering property: Cost (% of property value)"]] <- "rp_cost_BZ"
d[["Rank: Getting credit  (DB19 methodology) (1=most business-friendly regulations)"]] <- "rank_gc_BZ"
d[["Getting credit: Strength of legal rights index (0-12) (DB15-19 methodology)"]] <- "gc_legal_BZ"
d[["Getting credit: Strength of legal rights index (0-10) (DB05-14 methodology)"]] <- "gc_legal_old_BZ"
d[["Getting credit: Depth of credit information index (0-8) (DB15-19 methodology)"]] <- "gc_info_BZ"
d[["Getting credit: Depth of credit information index (0-6) (DB05-14 methodology)"]] <- "gc_info_old_BZ"
d[["Getting credit: Credit registry coverage (% of adults)"]] <- "gc_pub_BZ"
d[["Getting credit: Credit bureau coverage (% of adults)"]] <- "gc_priv_BZ"
d[["Rank: Protecting minority investors (1=most business-friendly regulations)  (DB19 methodology)"]] <- "rank_pi_BZ"
d[["Protecting minority investors: Extent of disclosure index (0-10)"]] <- "pi_disc_BZ"
d[["Protecting minority investors: Extent of director liability index (0-10)"]] <- "pi_dl_BZ"
d[["Protecting minority investors: Ease of shareholder suits index (0-10) (DB15-19 methodology)"]] <- "pi_shsu_BZ"
d[["Protecting minority investors: Ease of shareholder suits index (0-10) (DB06-14 methodology)"]] <- "pi_shsu_old_BZ"
d[["Protecting minority investors: Strength of minority investor protection index (0-10) (DB15-19 methodology)"]] <- "pi_ip_BZ"
d[["Protecting minority investors: Strength of investor protection index (0-10) (DB06-14 methodology)"]] <- "pi_ip_old_BZ"
d[["Rank: Paying taxes (1=most business-friendly regulations) (DB19 methodology)"]] <- "rank_pt_BZ"
d[["Paying taxes: Payments (number per year)"]] <- "pt_pay_BZ"
d[["Paying taxes: Time (hours per year)"]] <- "pt_time_BZ"
d[["Paying taxes: Profit tax (% of profits)"]] <- "pt_prof_BZ"
d[["Paying taxes: Labor tax and contributions (% of commercial profits)"]] <- "pt_lab_BZ"
d[["Other taxes (% of profits)"]] <- "pt_other_BZ"
d[["Paying taxes: Total tax rate (% of profit)"]] <- "pt_tot_BZ"
d[["Rank: Trading across borders (1=most business-friendly regulations) (DB19 methodology)"]] <- "rank_tr_BZ"
d[["Trading across borders: Documents to export (number) (DB06-15 methodology)"]] <- "tr_exdo_old_BZ"
d[["Trading across borders: Time to export (days) (DB06-15 methodology) - Score"]] <- "tr_exti_old_BZ"
d[["Trading across borders: Cost to export (US$ per container deflated) (DB06-15 methodology)"]] <- "tr_exco_old_BZ"
d[["Trading across borders: Documents to import (number) (DB06-15 methodology)"]] <- "tr_imdo_BZ"
d[["Trading across borders: Time to import (days) (DB06-15 methodology) - Score"]] <- "tr_imti_old_BZ"
d[["Trading across borders: Cost to import (US$ per container)(DB06-15 methodology) - Score"]] <- "tr_imco_old_BZ"
d[["Rank: Enforcing contracts (1=most business-friendly regulations) (DB19 methodology)"]] <- "rank_ec_BZ"
d[["Enforcing contracts: Time (days)"]] <- "ec_time_BZ"
d[["Enforcing contracts: Cost (% of claim)"]] <- "ec_cost_BZ"
d[["Rank: Resolving insolvency  (DB19 methodology)"]] <- "rank_ri_BZ"
d[["Resolving insolvency: Time (years)"]] <- "ri_time_BZ"
d[["Resolving insolvency: Cost (% of estate)"]] <- "ri_cost_BZ"
d[["Resolving insolvency: Outcome (0 as piecemeal sale and 1 as going concern)"]] <- "ri_out_BZ"
d[["Resolving insolvency: Recovery rate (cents on the dollar)"]] <- "ri_reco_BZ"

# change the Indicator Name column values to the corresponding indicator name from the master dataset (bz)
for(i in 1:nrow(bz_update)){
  if(bz_update$`Indicator Name`[i] %in% d$keys()){
    bz_update$`Indicator Name`[i] <- d[[bz_update$`Indicator Name`[i]]]
  }
}

# clean the bz_update to the columns that are absolutely necessary
keepCols = c("Country", "Indicator Name", "2018", "2019")
bz_update = bz_update[keepCols]

# column names to keep from the dictionary values
# bz_cleaned will store only the variables match with the master dataset
# then bz_cleaned will be merged with the original dataset
cleanCols <- d$values()
cleanCols <- unlist(cleanCols)
bz_cleaned = bz_cleaned[cleanCols]

# reshape and clean bz_cleaned from bz_update
# pivot_longer based on the two year columns (2018, 2019)
# pivot_wider based on the indicator name; make it the same structure as the master dataset bz
bz_cleaned <- pivot_longer(bz_update, 3:4) %>%
  pivot_wider(names_from = 'Indicator Name', values_from = value, id_cols = c(Country, name)) %>% 
  select(year = name, 'Country', ends_with("_BZ"))

# gwno_var to use when merged
gwno_var <- c('country', 'gwno', 'year', 'ccode', 'ifs', 'ifscode', 'gwabbrev')

# from the original dataset, select gwno_var and necessary variables (= ones ending with _BZ)
# bz <- as_tibble(bz)
bz <- select(bz, gwno_var, ends_with("_BZ"))

names(bz_cleaned)[2] <- "country" # change the column name as the one in the master dataset
bz_cleaned <- append_ids(bz_cleaned) # append_ids to use for merging
bz_cleaned <- select(bz_cleaned, gwno_var, cleanCols) # select gwno_var and necessary variables (= stored in cleanCols)

# bz_final <- rbind.data.frame(bz, bz_cleaned)
bz_final <- merge(bz, bz_cleaned, all = TRUE)

# save as .RDATA
save(bz_final, file=paste(preppeddata, "Prep_BZ(up to 2019)_HE_030420.RDATA", sep ='')) 
