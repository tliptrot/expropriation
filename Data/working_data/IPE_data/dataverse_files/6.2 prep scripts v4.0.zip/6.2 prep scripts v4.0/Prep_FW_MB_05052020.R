#/***********************
#  Forbes and Warnock Surges, stops, flight, and retrenchment data
# Citation:
#  Forbes, Kristin J., and Francis E. Warnock. "Capital flow waves: 
# Surges, stops, flight, and retrenchment." Journal of International 
# Economics 88, no. 2 (2012): 235-251.
#
# Data updated: October 2019
# Prep script: Miriam Barnum, 05/05/2020
#
#************************/

library(readstata13)
library(Hmisc)
library(dplyr)

fw <-  read.dta13(paste(rawdata,"RAWDATA_FW_2019.dta",sep=""))

fw <- fw %>% select(-id, -time, -qtr, -region_d) %>%
  separate( yr_qtr, c("year", NA), "_") %>%
  group_by(country, year) %>% summarise_all(sum, na.rm = T)

#Append country IDs
fw$country[fw$country == "Korea"] <-  "South Korea"
fw$country[fw$country == "Guatamala"] <-  "Guatemala"
fw <-  append_ids(fw, breaks = F)

#Add variable labels
label(fw$surge_epiTO) <- "Capital Surge Episodes [FW]"
label(fw$stop_epiTO) <- "Capital Stop Episodes [FW]"
label(fw$flight_epiTO) <- "Capital Flight Episodes [FW]"
label(fw$retrench_epiTO) <- "Capital Retrenchment Episodes [FW]"
label(fw$surge_epiDI) <- "FDI Capital Surge Episodes [FW]"
label(fw$stop_epiDI) <- "FDI Capital Stop Episodes [FW]"
label(fw$flight_epiDI) <- "FDI Capital Flight Episodes [FW]"
label(fw$retrench_epiDI) <- "FDI Capital Retrenchment Episodes [FW]"
label(fw$surge_epiDE) <- "Debt Portfolio Capital Surge Episodes [FW]"
label(fw$stop_epiDE) <- "Debt Portfolio Capital Stop Episodes [FW]"
label(fw$flight_epiDE) <- "Debt Portfolio Capital Flight Episodes [FW]"
label(fw$retrench_epiDE) <- "Debt Portfolio Capital Retrenchment Episodes [FW]"
label(fw$surge_epiEQ) <- "Equity Portfolio Capital Surge Episodes [FW]"
label(fw$stop_epiEQ) <- "Equity Portfolio Capital Stop Episodes [FW]"
label(fw$flight_epiEQ) <- "Equity Portfolio Capital Flight Episodes [FW]"
label(fw$retrench_epiEQ) <- "Equity Portfolio Capital Retrenchment Episodes [FW]"
label(fw$surge_epiBK) <- "Bank (and other) Capital Surge Episodes [FW]"
label(fw$stop_epiBK) <- "Bank (and other) Capital Stop Episodes [FW]"
label(fw$flight_epiBK) <- "Bank (and other) Capital Flight Episodes [FW]"
label(fw$retrench_epiBK) <- "Bank (and other) Capital Retrenchment Episodes [FW]"

fw <- append_suffix(fw,"FW")

length(unique(fw$gwno)) #59
range(fw$year) #1980-2018

save(fw,file=paste(preppeddata,"PREPPED_FW_MB_05052020.RDATA",sep=""))

