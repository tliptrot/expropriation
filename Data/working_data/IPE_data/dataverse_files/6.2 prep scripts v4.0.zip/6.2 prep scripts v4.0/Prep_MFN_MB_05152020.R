# /**************************
# Dataset: Tariff rate, most favored nation, simple mean, all products (%)
# Data source url: https://data.worldbank.org/indicator/TM.TAX.MRCH.SM.FN.ZS 
# Codebook url: 
#   Time: 1988-2018
#   Countries: 198
# Updated: 2020.05.15
# By: Miriam Barnum
# Suffix: MFN
# Notes:
#   ****************************/

library(plyr)
library(dplyr)
library(tidyr)
library(zoo)

# read, trimming header whitespace
mfn <- read.csv(paste(rawdata, "RAWDATA_MFN_2018.csv", sep = ""), skip = 4) %>% 
  
  # discard unneeded columns
  select(-Country.Code, -Indicator.Name, -Indicator.Code) %>% 
  
  # reshape
  pivot_longer(-Country.Name, names_to = "year", values_to = "MFNtariff") %>%
  
  # year to numeric
  mutate(year = as.numeric(gsub("X","", year))) %>% 
  
  # no actual observations for these years
  filter(year >= 1988 & year != 2019) %>% 
  
  # interpolation
  group_by(Country.Name) %>% arrange(Country.Name, year) %>%
  mutate(iMFNtariff = na.approx(MFNtariff, na.rm = F)) %>%
  
  # append ids and suffixes
  plyr::rename(c("Country.Name" = "country")) %>%
  append_ids(breaks = F) %>%
  append_suffix("MFN")

# countries and time range
range(mfn$year)
length(unique(mfn$gwno))

# saving
save(mfn, file = paste(preppeddata, "PREPPED_MFN_MB_2018.RDATA", sep =""))
