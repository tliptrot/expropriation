# /************************* 
# Source: The Peace Research Institute Oslo 
# Accessed: May 17, 2017
# URL: https://www.prio.org/Data/Armed-Conflict/Onset-and-Duration-of-Intrastate-Conflict/Onset-Data/
# Query specifications: all gwnos, all years, variables: onset2_AO, onset3_AO, onset4_AO, onset5_AO, onset6_AO, onset7_AO, onset8_AO, onset9_AO
# Time: 1946-2004
# By: Jessica Xu
# Suffix: AO
# Variables: onset2_AO, onset3_AO, onset4_AO, onset5_AO, onset6_AO, onset7_AO, onset8_AO, onset9_AO
# *************************/

library(readstata13)
library (Hmisc)
#import
AO <- read.dta13(paste(rawdata,"RAWDATA_AO.dta", sep=""))

#label
label(AO$onset2) <- "2 years between onset variables coded [Strand]"
label(AO$onset3) <- "3 years between onset variables coded [Strand]"
label(AO$onset4) <- "4 years between onset variables coded [Strand]"
label(AO$onset5) <- "5 years between onset variables coded [Strand]"
label(AO$onset6) <- "6 years between onset variables coded [Strand]"
label(AO$onset7) <- "7 years between onset variables coded [Strand]"
label(AO$onset8) <- "8 years between onset variables coded [Strand]"
label(AO$onset9) <- "9 years between onset variables coded [Strand]"

AO <- append_suffix(AO, "AO")

save(AO,file=paste(preppeddata,"PREPPED_AO_JX_2017.RDATA",sep=""))
