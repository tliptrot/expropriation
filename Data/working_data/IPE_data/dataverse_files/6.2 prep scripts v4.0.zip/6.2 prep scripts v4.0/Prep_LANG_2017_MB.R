# /************************* 
# Data: Reporters Without Borders: Freedom of the Press [LANG]
# Data source url: https://www.nationsonline.org/oneworld/languages.htm
# Time:2012-2017
# By: Sherry
# Edited by: Michael Jaksland
# Edited MB 05/07/2020
# Suffix: LANG
#
# country-only version, merge with TSCS data to use in TSCS context
# *************************/


library(Hmisc)
library(readxl)


# Read the excel file that contains year 2012- 2014
LANG <-read_excel(paste(rawdata,"RAWDATA_LANG.xlsx", sep=""),sheet = 6, na = "NA")

# Rename Column Variables
names(LANG)[names(LANG)=="language 1"] = "lang1"
names(LANG)[names(LANG)=="language2"] = "lang2"

# append IDS - gwno will be based on 2015 country names
LANG = append_ids(LANG)

# Label Variables
label(LANG$lang1) <- "Official Language 1 [LANG]"
label(LANG$lang2) <- "Official Language 2 [LANG]"

#Append suffix LANG to variables
LANG = append_suffix(LANG,"LANG")

save(LANG,file=paste(preppeddata,"PREPPED_LANG_SW_052517.RDATA",sep=""))