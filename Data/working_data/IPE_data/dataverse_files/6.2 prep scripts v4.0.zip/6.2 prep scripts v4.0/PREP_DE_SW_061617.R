# /************************* 
# Append Gwno to system democracy data
# *************************/

library(foreign)
library(Hmisc)
library(readstata13)


# Read the dta file from prepped data folder
DE <-read.dta13(paste(rawdata,"system_democracy.dta", sep=""))
load(paste(rawdata, "Country_GWNO_Year_Simple.RDATA", sep = ""))
load(paste(rawdata, "Country_GWNO_Year_Standard.RDATA", sep = ""))


sum(is.na(DE))

DE <- merge(DE,CY, by=c("year"), all = TRUE)

# Remove rows with empty gwno entries
DE <- DE[!rowSums(is.na(DE["gwno"])),]

# Remove empty rows with empty entries
DE <- DE[!rowSums(is.na(DE["democracy_share_DE"])),]

# Drop Uneccessary columns
DE$ccode <- NULL
DE$minYear <- NULL
DE$maxYear <- NULL

names(DE)[names(DE)=="Country"] = "countryname_raw_DE"

# Add variable labels
label(DE$democracy_share_DE) <- "System Level Democratic Share [DE]"
label(DE$democracy_count_DE) <- "Count of Democracies in the System [DE]"
label(DE$lndemsys_DE) <- "Count of Democracies in the System (logged) [DE]"

length(unique(DE$gwno)) #227
range(DE$year) #1816-2015

save(DE,file=paste(preppeddata,"PREPPED_DE_SW_0615617.RDATA",sep=""))

