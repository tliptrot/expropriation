# /**************************
# Data: LexisNexis-based Information Measures [LX] 
# Data source url: 
# Time: 19922 - 2012
# Updated: 2018.02.17
# By: Emily on 05.10.2018
# Suffix: LX
# 
# Citation:
# Kingsley, Allison and Benjamin A.T. Graham. 2017. “The Capital Effects of Information Voids
# in Emerging Markets.” Journal of International Business Studies 48(3): 324-343.
# #****************************/
library(Hmisc)
library(readstata13)

LX = read.dta13(paste(rawdata, "RAWDATA_LX.dta", sep = ""))

#label variables
label(LX$baselinemwp) = "News Coverage (total articles) [GKJ]"
label(LX$investmentmwp) = "Investment Articles in LexisNexis (keyword) [GKJ]"
label(LX$subjectmwp) = "Potentially Business Relevant Articles in LexisNexis (subjects) [GKJ]"
label(LX$ln_baselinemwp) = "Total Articles in LexisNexis (logged) [GKJ]"
label(LX$ln_investmentmwp) = "Investment Articles in LexisNexis (keyword) (logged) [GKJ]"
label(LX$ln_subjectmwp) = "Potentially Business Relevant Articles in LexisNexis (subjects) (logged)"

#appending ids
LX = append_ids(LX)

#append suffix
LX = append_suffix(LX, "LX")

#length of dataset
length(unique(LX$gwno)) #173

#range of dataset
range(LX$year) #1992 - 2012

#save file
save(LX,file=paste(preppeddata,"PREP_LX_EH_05102018.RDATA",sep=""))
