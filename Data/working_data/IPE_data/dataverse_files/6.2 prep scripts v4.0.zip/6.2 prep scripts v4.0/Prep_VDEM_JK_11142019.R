# /***************************
# Varieties of Democracy
# Version 7 (July 2017)
# 
# URL: https://www.v-dem.net/en/data/data-version-8/
# 
# Citation: Coppedge, Michael, John Gerring, Staffan I. Lindberg, Svend-Erik Skaaning,
# Jan Teorell, David Altman, Michael Bernhard, M. Steven Fish, Adam Glynn, Allen Hicken,
# Carl Henrik Knutsen, Kyle L. Marquardt, Kelly McMann, Valeriya Mechkova, Pamela Paxton,
# Daniel Pemstein, Laura Saxer, Brigitte Seim, Rachel Sigman, and Jeffrey Staton. 2017.
# "V-Dem Codebook v7.1." Varieties of Democracy (V-Dem) Project
# 
# Time Period: 1789-2017
# Coded by: Grace Xu
# Revised by: Suzie Mulesky (5/7/2018)
# Revised by: Anna Lipscomb (Feb 2019)
# Revised by: John Kang (Nov 2019)
# ****************************/

vdem <- read.csv(paste(rawdata, "RAWDATA_VDEM_2019.csv", sep=""))

variables = c( "country_name","year","v2x_polyarchy", 
              "v2x_api", 
              "v2x_mpi",
              "v2x_EDcomp_thick",
              "v2x_libdem",
              "v2x_liberal",
              "v2x_partipdem",
              "v2x_partip",
              "v2x_delibdem",
              "v2xdl_delib",
              "v2x_egaldem",
              "v2x_egal",
              "v2x_frassoc_thick",
              #"v2x_freexp_thick", #According to codebook, "Expanded freedom of expression index" (v2x_freexp_thick) has been renamed to "Freedom of Expression and Alternative Sources of Information index" (v2x_freexp_altinf) 
              "v2x_freexp_altinf",
              "v2xme_altinf",
              "v2x_suffr",
              "v2xel_frefair",
              "v2x_elecoff",
              "v2xcl_rol",
              "v2x_jucon",
              "v2xlg_legcon",
              "v2x_cspart",
              "v2xdd_dd",
              "v2xel_locelec",
              "v2xel_regelec",
              "v2xeg_eqprotec",
              "v2xeg_eqdr",
              "v2xcs_ccsi",
              "v2xps_party",
              "v2x_gender",
              "v2x_gencl",
              "v2x_gencs",
              "v2x_genpp",
              "v2x_elecreg",
              "v2xex_elecreg",
              "v2xlg_elecreg",
              "v2xel_elecparl",
              "v2xlg_leginter",
              "v2xel_elecpres",
              "v2x_hosinter",
              "v2x_corr",
              "v2x_pubcorr",
              "v2x_execorr",
              "v2x_divparctrl",
              "v2x_feduni",
              "v2x_civlib",
              "v2x_clphy",
              "v2x_clpol",
              "v2x_clpriv",
              "v2elsrgel",
              "v2elreggov",
              "v2cltrnslw",
              "v2juhcind",
              "v2juhccomp",
              #"v2jureview", #can't find in excel
              "v2excrptps",
              "v2jucorrdc",
              "v2exbribe",
              "v2lgcrrpt"
             
)

vdem = vdem[variables]

library(plyr)
# note that if the line below does not run, the rename function 
# in dplyr interferes with the rename in plyr, so you must unload
# dyplr, which can be done by running this line: detach("package:dplyr", unload=TRUE)
vdem = rename(vdem, c("country_name" = "country"))

# check for duplicates
n_occur <- data.frame(table(vdem$country, vdem$year))
n_occur[n_occur$Freq>1,]

str(vdem)

# append IDs
vdem = append_ids(vdem, breaks = FALSE)
vdem = append_suffix(vdem, "VDEM")

# check for duplicates
n_occur <- data.frame(table(vdem$gwno, vdem$year))
n_occur[n_occur$Freq>1,]

# how many countries? what time period?
length(unique(vdem$gwno)) # 195
range(vdem$year) # 1789-2019

# label variables
library(Hmisc)
label(vdem$v2x_polyarchy_VDEM) =	"Electoral democracy index [VDEM]"
label(vdem$v2x_api_VDEM)	= "Additive polyarchy index [VDEM]"
label(vdem$v2x_mpi_VDEM) = "Multiplicative polyarchy index [VDEM]"
label(vdem$v2x_EDcomp_thick_VDEM) =	"Electoral component index [VDEM]"
label(vdem$v2x_libdem_VDEM) =	"Liberal democracy index [VDEM]"
label(vdem$v2x_liberal_VDEM) =	"Liberal component index [VDEM]"
label(vdem$v2x_partipdem_VDEM) =	"Participatory democracy index [VDEM]"
label(vdem$v2x_partip_VDEM) =	"Participatory component index [VDEM]"
label(vdem$v2x_delibdem_VDEM) =	"Deliberative democracy index [VDEM]"
label(vdem$v2xdl_delib_VDEM) =	"Deliberative component index [VDEM]"
label(vdem$v2x_egaldem_VDEM) =	"Egalitarian democracy index [VDEM]"
label(vdem$v2x_egal_VDEM) =	"Egalitarian component index [VDEM]"
label(vdem$v2x_frassoc_thick_VDEM) =	"Freedom of association (thick) index [VDEM]"
label(vdem$v2x_freexp_altinf_VDEM) =	"Freedom of expression and alternative sources of information index [VDEM]"
#label(vdem$v2x_freexp_thick_VDEM) =	"Expanded freedom of expression index [VDEM]" #in V8, it was renamed to "Freedom of Expression and Alternative Sources of Information index"
#label(vdem$v2x_freexp_VDEM) =	"Freedom of expression index [VDEM]"
label(vdem$v2xme_altinf_VDEM)	= "Alternative sources of information index [VDEM]"
label(vdem$v2x_suffr_VDEM) =	"Share of population with suffrage [VDEM]"
label(vdem$v2xel_frefair_VDEM) =	"Clean elections index [VDEM]"
label(vdem$v2x_elecoff_VDEM) =	"Elected executive index [VDEM]"
label(vdem$v2xcl_rol_VDEM) =	"Equality before the law and individual liberty index [VDEM]"
label(vdem$v2x_jucon_VDEM) =	"Judicial constraints on the executive index [VDEM]"
label(vdem$v2xlg_legcon_VDEM) =	"Legislative constraints on the executive index [VDEM]"
label(vdem$v2x_cspart_VDEM) = "Civil society participation index [VDEM]"
label(vdem$v2xdd_dd_VDEM) =	"Direct popular vote index [VDEM]"
label(vdem$v2xel_locelec_VDEM) =	"Local government index [VDEM]"
label(vdem$v2xel_regelec_VDEM)	= "Regional government index [VDEM]"
label(vdem$v2xeg_eqprotec_VDEM) =	"Equal protection index [VDEM]"
label(vdem$v2xeg_eqdr_VDEM) = "Equal distribution of resources index [VDEM]"
label(vdem$v2xcs_ccsi_VDEM) =	"Core civil society index [VDEM]"
label(vdem$v2xps_party_VDEM) =	"Party system institutionalization index [VDEM]"
label(vdem$v2x_gender_VDEM) =	"Women political empowerment index [VDEM]"
label(vdem$v2x_gencl_VDEM) =	"Women civil liberties index [VDEM]"
label(vdem$v2x_gencs_VDEM) =	"Women civil society participation index [VDEM]"
label(vdem$v2x_genpp_VDEM) =	"Women political participation index [VDEM]"
label(vdem$v2x_elecreg_VDEM) =	"Electoral regime index [VDEM]"
label(vdem$v2xex_elecreg_VDEM)	= "Executive electoral regime index [VDEM]"
label(vdem$v2xlg_elecreg_VDEM) =	"Legislative electoral regime index [VDEM]"
label(vdem$v2xel_elecparl_VDEM) =	"Legislative or constituent assembly election [VDEM]"
label(vdem$v2xlg_leginter_VDEM) =	"Legislature closed down or aborted [VDEM]"
label(vdem$v2xel_elecpres_VDEM) =	"Presidential election [VDEM]"
label(vdem$v2x_hosinter_VDEM) = "Chief executive no longer elected [VDEM]"
label(vdem$v2x_corr_VDEM) = "Political corruption [VDEM]"
label(vdem$v2x_pubcorr_VDEM) = "Public sector corruption index [VDEM]"
label(vdem$v2x_execorr_VDEM) = "Executive corruption index [VDEM]"
label(vdem$v2x_divparctrl_VDEM) =	"Divided party control of legislature [VDEM]"
label(vdem$v2x_feduni_VDEM) =	"Division of power index [VDEM]"
label(vdem$v2x_civlib_VDEM) =	"Civil liberties index [VDEM]"
label(vdem$v2x_clphy_VDEM) =	"Physical violence index [VDEM]"
label(vdem$v2x_clpol_VDEM) =	"Political liberties index [VDEM]"
label(vdem$v2x_clpriv_VDEM) =	"Private liberties index [VDEM]"
label(vdem$v2elsrgel_VDEM) =	"Regional Government Elected [VDEM]"
label(vdem$v2elreggov_VDEM) =	"Regional Government Exists [VDEM]"
label(vdem$v2cltrnslw_VDEM) =	"Transparent laws with predictable enforcement [VDEM]"
label(vdem$v2juhcind_VDEM) =	"High court independence [VDEM]"
label(vdem$v2juhccomp_VDEM) =	"Government compliance with high court [VDEM]"
#label(vdem$v2jureview_VDEM) =	"Judicial review [VDEM]"

# Save
save(vdem, file = paste(preppeddata,"prepped_VDEM_2019_JK.RDATA", sep=""))

