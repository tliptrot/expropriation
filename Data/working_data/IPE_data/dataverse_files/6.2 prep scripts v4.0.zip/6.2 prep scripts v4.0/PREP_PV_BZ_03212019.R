###############################
# Major Episodes of Political Violence (MEPV) [PV]
# Version: 1946-2015
# Accessed: April 27, 2017
# Year Range: 1946-2015
# Prepped By: Rohit Madan
# Updated By: Emily Heuring
# Suffix: PV
# Last update: 04/15/2018
#
# Data: http://www.systemicpeace.org/inscrdata.html
# 
# Note: This is the standard version of the data not including data on neighbouring states. 
###############################

library(readxl)
library(Hmisc)

pvStd = read_excel(path = (paste(rawdata, "RAWDATA_PV_2017.xls", sep="")))

#Keep only these variables
pvStd <- pvStd[, c("country", "year","intind","intviol","intwar","civviol", "civwar","ethviol","ethwar","inttot","civtot","actotal","nborder")]

#Append ids
pvStd <- append_ids(pvStd, breaks = F)

#Check Duplicates
n_occur <- data.frame(table(pvStd$country, pvStd$year))
print(n_occur[n_occur$Freq > 1,])

# Vietnam Duplicates
pvStd = pvStd[-which(pvStd$countryname_raw == "Vietnam" & pvStd$year == 1954),]

## Append Suffix
pvStd <- append_suffix(pvStd, "PV")

#Label
label(pvStd$intind_PV) <- "War of Independence, Magnitude [PV]" 
label(pvStd$intviol_PV) <- "International Violence, Magnitude [PV]" 
label(pvStd$intwar_PV) <- "International Warfare, Magnitude [PV]" 
label(pvStd$civviol_PV) <- "Civil Violence, Magnitude [PV]" 
label(pvStd$civwar_PV) <- "Civil War, Magnitude [PV]" 
label(pvStd$ethviol_PV) <- "Ethnic violence, Magnitude [PV]" 
label(pvStd$ethwar_PV) <- "Ethnic War, Magnitude [PV]" 
label(pvStd$inttot_PV) <- "Total interstate MEPVS, Magnitude [PV]" 
label(pvStd$civtot_PV) <- "Total civil and ethnic MEPVS, Magnitude [PV]" 
label(pvStd$actotal_PV) <- "Total MEPVS, Magnitude [PV]" 
label(pvStd$nborder_PV) <- "Number of states sharing a border [PV]" 

#check number of countries
length(unique(pvStd$gwno)) #173

#check number of years
range(pvStd$year) #1946 - 2016

#save prepped data
save(pvStd,file=paste(preppeddata,"PREPPED_PV_BZ_2017.RDATA",sep=""))
