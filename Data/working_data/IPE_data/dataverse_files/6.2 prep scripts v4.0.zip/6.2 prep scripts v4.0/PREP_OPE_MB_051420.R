# /*************************
#   BEA US Outward  PPE
# Source: U.S. Bureau of Economic Analysis
# Years: 2009-2013
# Citation: U.S. Bureau of Economic Analysis, "U.S. Direct Investment Abroad,
# All Majority-owned Foreign Affiliates”
# (accessed May 14, 2020)
#
#  197 countries, 1997-2017
#
# Variable(s):
# - gross_ppe_OPE: Gross Property, Plant, and Equipment (2007-2017)
# - net_ppe_OPE: Net Property, Plant, and Equipment (1997-2013)
#
# Miriam Barnum (05/14/2020)
# *************************/

library(readxl)
library(readstata13)
library(dplyr)
library(Hmisc)

datalist <- list()

for(i in 1:11){
  #i = 1
  s = as.character(2007:2017)[i]
  sheet = read_excel(paste(rawdata, "RAWDATA_OPE_2017.xls", sep =""), sheet = s)
  names(sheet) <- sheet[3,]
  names(sheet)[1] <- "country"
  sheet <- sheet[c("country", "Gross property, plant, and equipment")]
  sheet$year <- s
  datalist[[i]] <- sheet
}

ope <- do.call(rbind, datalist)

names(ope)[names(ope) == "Gross property, plant, and equipment"] <- "gross_ppe"
ope$year <- as.numeric(ope$year)

ope <- append_ids(ope, breaks = F)
ope <- append_suffix(ope, "OPE")

# merge in old net ppe data
net <- read.dta13(paste(rawdata, "PREPPED_OPE_290517.dta", sep =""))
net[net == "."] <- NA

ope <- select(net, -countryname_raw_OPE) %>% 
  mutate(country = replace(country, country == "Germany", "German Federal Republic")) %>%
  full_join(ope)

#check duplicates
n_occur <- data.frame(table(ope$gwno, ope$year))
print(n_occur[n_occur$Freq > 1,])

# no useful data in "venezuela" obs
ope <- ope[-which(ope$countryname_raw_OPE == "Venezuela"),]

label(ope$gross_ppe_OPE) <- "Gross Property, Plant, and Equipment (USD millions) [OPE]"
label(ope$net_ppe_OPE) <- "Net Property, Plant, and Equipment (USD millions) [OPE]"

save(ope, file = paste(preppeddata, "Prepped_OPE_2017.Rdata", sep =""))
