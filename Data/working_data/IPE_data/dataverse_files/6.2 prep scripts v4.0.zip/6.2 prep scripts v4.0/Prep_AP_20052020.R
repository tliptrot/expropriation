# /************************* 
# Change Figi to Fiji
# Archipelagos Data [AP]
# *************************/

library(foreign)
library(Hmisc)
library(readstata13)



# Read the dta file from prepped data folder
AP <-read.dta13(paste(rawdata,"archipelagos.dta", sep=""))

# Change Figi -> Fiji
AP$country[AP$country == "Figi"] <- "Fiji"

# Drop gwno>1000
AP <- AP[!AP$gwno >= 1100, ]

#renaming variables
names(AP)[names(AP)=="lnislands"]="lnislands_AP"

# Add variable labels
label(AP$lnislands_AP) = "Number of islands (ppl > 100000) logged [Archipelagos]"
label(AP$archipelago_AP) = "At least two islands"
label(AP$comments_AP) = "List of the islands in each country"
label(AP$numislands_AP) = "Number of Islands (ppl > 100000)"

length(unique(AP$gwno)) #223
range(AP$year) #1800-2015

#check that there are no over time changes
test <- AP %>% group_by(gwno) %>% 
  summarise(change = length(unique(numislands_AP))) %>%
  filter(change > 1)
test

# cross-sectional format
AP <- select(AP, -year) %>%
  filter(!duplicated(gwno))
arc <- arc[!duplicated(arc),]
arc <- arc[!duplicated(arc$gwno),]

save(AP,file=paste(preppeddata,"PREPPED_AP_MB_20052020.RDATA",sep=""))
