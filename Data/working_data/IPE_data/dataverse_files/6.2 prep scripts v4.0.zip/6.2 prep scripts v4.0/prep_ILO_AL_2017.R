# /************************* 
# Source: The International Labor Organization
# Accessed: May 15th, 2017
# URL: http://www.ilo.org/ilostat/faces/oracle/webcenter/portalapp/pagehierarchy/Page27.jspx?subject=EAR&indicator=LAC_XEES_ECO_NB&datasetCode=A&collectionCode=YI&_afrLoop=450386476161074&_afrWindowMode=0&_afrWindowId=o26mf2g7z_356#!%40%40%3Findicator%3DLAC_XEES_ECO_NB%26_afrWindowId%3Do26mf2g7z_356%26subject%3DEAR%26_afrLoop%3D450386476161074%26datasetCode%3DA%26collectionCode%3DYI%26_afrWindowMode%3D0%26_adf.ctrl-state%3Do26mf2g7z_388
# Query: All years, all countries, "Aggregate categories of economic activity: Total"
# 
# Time: 2000-2017
# Coded by: Grace Xu
# Updated February 25, 2019 by Anna Lipscomb
#
# Suffix: ILO
# Variables: unitlaborcost_ILO
# *************************/

library(readxl)
library(Hmisc)
library(tidyr)
library(dplyr)

ilo = read_excel(path = (paste(rawdata, "RAWDATA_ILO_2017.xlsx", sep="")))

#renaming columns & removing unneccessary ones
colnames(ilo) = ilo[6,]
ilo = ilo[,-c(2:4)]

#cutting out blank rows at bottom
ilo = ilo[-c(1:6, 64:67),1:ncol(ilo)]

#reshape
ilo = gather(ilo, "year", "unitlaborcost", 2:ncol(ilo))

# cleans some duplicates - MB 06/2020
ilo <- ilo[!is.na(ilo$unitlaborcost),]
ilo <- ilo[!duplicated(ilo),]

# take mean if there is more than one data source - MB 06/2020
ilo <- ilo %>% 
  mutate_at(vars(-Country), as.numeric) %>% # also change to numeric
  group_by(Country, year) %>% 
  dplyr::summarise(unitlaborcost = mean(unitlaborcost, na.rm = T))


#label
label(ilo$unitlaborcost) <- "Mean nominal hourly labour cost per employee (Local Currency) [ILO]"

#append ID and suffixes
ilo = append_ids(ilo, breaks = F)
ilo = append_suffix(ilo, "ILO")

length(unique(ilo$gwno)) # 53
range(ilo$year) # 2008-2017

#save
save(ilo, file = paste(preppeddata, "Prepped_ILO_2017_AL.RData", sep=""))
