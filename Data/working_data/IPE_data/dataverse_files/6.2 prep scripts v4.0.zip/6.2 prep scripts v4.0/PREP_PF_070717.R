# run the .do prep script before running this one

library(foreign)
library(Hmisc)
library(readstata13)



# Read the dta file from prepped data folder
PF <-read.dta13(paste(rawdata,"Fortna_peacekeeping.dta", sep=""))

# Drop gwno == 730 & year > 1910
PF = PF[-which(PF$gwno == 730 & PF$year > 1947),]


# Add variable labels
label(PF$peacekeep_PF) = "Whether the state hosted a UN Peacekeeping mission that year [PF]"

length(unique(PF$gwno)) #223
range(PF$year) #1800-2015

save(PF,file=paste(preppeddata,"PREPPED_PF_SW_070717.RDATA",sep=""))



