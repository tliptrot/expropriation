# /********************/
# Data: Cingranelli-Richards (CIRI) Human Rights Dataset 
# Dataset: Complete CIRI Data, 1981 - 2011 (.xlsx format)
# Datasoure URL: http://www.humanrightsdata.com/p/data-documentation.html
# Codebook URL: http://www.humanrightsdata.com/p/data-documentation.html
# Time: 1981 - 2011
# By: Emily on 03.30.2018
# Suffix: CR
# 
# Citation: 
# Cingranelli, David L., David L. Richards and K. Chad Clay. 2014. “The CIRI Human Rights
# Dataset”. http://www.humanrightsdata.com. Dataset Version: 2014.04.14
# 
# Cingranelli, David L., and David L. Richards. 2014. “The Cingranelli-Richards (CIRI) Human
# Rights Data Project Coding Manual Version 5.20.14.” http://www.humanrightsdata.com/p/data-documentation.html
# /*******************/

library(readxl)
library(dplyr)
library(Hmisc)

#import
cr = read_excel(paste(rawdata, "RAWDATA_CR_2014.xlsx",sep=""))

#keep the variables we want
cr = cr[,c("CTRY","YEAR","COW","PHYSINT","DISAP","KILL","POLPRIS","TORT","ASSN","FORMOV","DOMMOV",
           "OLD_MOVE","SPEECH","ELECSD","OLD_RELFRE","NEW_RELFRE","WORKER","WECON",
           "WOPOL","WOSOC","INJUD")]

# rename country variable
names(cr)[names(cr)=="CTRY"] = "country"

#append ids
cr = append_ids(cr, breaks = F)

#label variables
label(cr$PHYSINT) <- "Physical Integrity Rights Index [CIRI]"
label(cr$DISAP) <- "Disappearance [CIRI]"
label(cr$KILL) <- "Extrajudicial Killing [CIRI]"
label(cr$POLPRIS) <- "Political Imprisonment [CIRI]"
label(cr$TORT) <- "Torture [CIRI]"
label(cr$ASSN) <- "Freedom of Assembly and Association [CIRI]"
label(cr$FORMOV) <- "Freedom of Foreign Movement [CIRI]"
label(cr$DOMMOV) <- "Freedom of Domestic Movement [CIRI]"
label(cr$OLD_MOVE) <- "Freedom of Movement Before 2007 [CIRI]"
label(cr$SPEECH) <- "Freedom of Speech [CIRI]"
label(cr$ELECSD) <- "Electoral Self-Determination [CIRI]"
label(cr$OLD_RELFRE) <- "Freedom of Religion Before 2007"
label(cr$NEW_RELFRE) <- "Freedom of Religion From 2007"
label(cr$WORKER) <- "Worker's Rights [CIRI]"
label(cr$WECON) <- "Women's Economic Rights [CIRI]"
label(cr$WOPOL) <- "Women's Political Rights [CIRI]"
label(cr$WOSOC) <- "Women's Social Rights [CIRI]"
label(cr$INJUD) <- "Independence of the Judiciary [CIRI]"

#number of unique countries
length(unique(cr$gwno)) #196

#range of dataset
range(cr$year) #1981 - 2011

cr = append_suffix(cr, "CR")

# filter out duplicate country-years which have no data (countries that didn't exist) - MB
cr <- cr %>% filter_at(9:26, any_vars(!is.na(.)))

# these didn't get caught - each had one non-missing val - MB
cr <- cr[!(cr$countryname_raw == "Yemen Arab Republic" & cr$year > 1990), ]
cr <- cr[!(cr$countryname_raw == "Yemen" & cr$year < 1990), ]

save(cr,file=paste(preppeddata, "PREPPED_CR_EH_03302018.RDATA", sep=""))
