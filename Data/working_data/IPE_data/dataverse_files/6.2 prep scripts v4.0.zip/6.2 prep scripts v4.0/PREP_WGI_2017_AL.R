# /************************* 
# Data: Worldwide Governance Indicators
# Data source url: http://info.worldbank.org/governance/wgi/#home
# Codebook url: http://info.worldbank.org/governance/wgi/#doc

# Time:1996-2017	
# By: Sherry
# Updated by Anna Lipscomb, March 2019
# Suffix: WGI
# 
# Citation:
# Kaufmann, Daniel, Aart Kraay, and Massimo Mastruzzi.  2009. 
# "Governance Matters VIII: Aggregate and Individual Governance Indicators, 1996-2008." 
# World Bank Policy Research Working Paper 4978. Available at http://papers.ssrn.com/sol3/papers.cfm?abstract_id=1424591
# 
# Kaufmann, Daniel, Aart Kraay, and Massimo Mastruzzi. 2011. 
# “The Worldwide Governance Indicators: Methodology and Analytical Issues.” 
# Hague Journal on the Rule of Law 3(2): 220–246. doi:10.1017/S1876404511200046.

# Voice and accountability, estimate [VA_EST_WGI]

# *************************/

library(Hmisc)
library(readxl)
library(tidyr)

#import data
wgi_VA = read_excel(paste(rawdata,"RAWDATA_WGI_2017.xlsx", sep=""), 2, col_names = TRUE)
wgi_VA = wgi_VA[-c(1:12),]
wgi_VA = wgi_VA[,-c(2,4:8,
              10:14,
              16:20,
              22:26,
              28:32,
              34:38,
              40:44,
              46:50,
              52:56,
              58:62,
              64:68,
              70:74,
              76:80,
              82:86,
              88:92,
              94:98,
              100:104,
              106:110,
              112:116)]

#Make the variable names the corresponding years
# From 1996-2002, data is only available for every other year (1996,1998,2000, 2002). Data exists for each year following
names(wgi_VA)<- wgi_VA[1,]
names(wgi_VA)[1] <- "country"
wgi_VA = wgi_VA[-c(1:2),]

# Reshape the data
wgi_VA= gather(wgi_VA,"year","VA_EST",2:20)

# Fix missing data
wgi_VA$VA_EST <- as.numeric(wgi_VA$VA_EST)


# Political stability absence of violence, estimate [PV_EST_WGI]

#import data
wgi_PV = read_excel(paste(rawdata,"RAWDATA_WGI_2017.xlsx", sep=""), 3, col_names = TRUE)

wgi_PV = wgi_PV[-c(1:12),]
wgi_PV = wgi_PV[,-c(2,4:8,
                    10:14,
                    16:20,
                    22:26,
                    28:32,
                    34:38,
                    40:44,
                    46:50,
                    52:56,
                    58:62,
                    64:68,
                    70:74,
                    76:80,
                    82:86,
                    88:92,
                    94:98,
                    100:104,
                    106:110,
                    112:116)]

#Make the variable names the corresponding years
names(wgi_PV)<- wgi_PV[1,]
names(wgi_PV)[1] <- "country"
wgi_PV = wgi_PV[-c(1:2),]

# Reshape the data
wgi_PV= gather(wgi_PV,"year","PV_EST",2:20)

# Fix missing data
wgi_PV$PV_EST <- as.numeric(wgi_PV$PV_EST)

# Government effectiveness, estimate [GE_EST_WGI]

wgi_GE = read_excel(paste(rawdata,"RAWDATA_WGI_2017.xlsx", sep=""), 4, col_names = TRUE)

wgi_GE = wgi_GE[-c(1:12),]
wgi_GE = wgi_GE[,-c(2,4:8,
                    10:14,
                    16:20,
                    22:26,
                    28:32,
                    34:38,
                    40:44,
                    46:50,
                    52:56,
                    58:62,
                    64:68,
                    70:74,
                    76:80,
                    82:86,
                    88:92,
                    94:98,
                    100:104,
                    106:110,
                    112:116)]

names(wgi_GE)<- wgi_GE[1,]
names(wgi_GE)[1] <- "country"
wgi_GE = wgi_GE[-c(1:2),]

# Reshape the data
wgi_GE= gather(wgi_GE,"year","GE_EST",2:20)

# Fix missing data
wgi_GE$GE_EST <- as.numeric(wgi_GE$GE_EST)


# Regulatory quality, estimate [GQ_EST_WGI]
wgi_GQ = read_excel(paste(rawdata,"RAWDATA_WGI_2017.xlsx", sep=""), 5, col_names = TRUE)

wgi_GQ = wgi_GQ[-c(1:12),]
wgi_GQ = wgi_GQ[,-c(2,4:8,
                    10:14,
                    16:20,
                    22:26,
                    28:32,
                    34:38,
                    40:44,
                    46:50,
                    52:56,
                    58:62,
                    64:68,
                    70:74,
                    76:80,
                    82:86,
                    88:92,
                    94:98,
                    100:104,
                    106:110,
                    112:116)]

#Make the variable names the corresponding years
names(wgi_GQ)<- wgi_GQ[1,]
names(wgi_GQ)[1] <- "country"
wgi_GQ = wgi_GQ[-c(1:2),]

# Reshape the data
wgi_GQ= gather(wgi_GQ,"year","GQ_EST",2:20)

# Fix missing data
wgi_GQ$GQ_EST <- as.numeric(wgi_GQ$GQ_EST)

#	Rule of law, estimate [RL_EST_WGI]
wgi_RL = read_excel(paste(rawdata,"RAWDATA_WGI_2017.xlsx", sep=""), 6, col_names = TRUE)
wgi_RL = wgi_RL[-c(1:12),]
wgi_RL = wgi_RL[,-c(2,4:8,
                    10:14,
                    16:20,
                    22:26,
                    28:32,
                    34:38,
                    40:44,
                    46:50,
                    52:56,
                    58:62,
                    64:68,
                    70:74,
                    76:80,
                    82:86,
                    88:92,
                    94:98,
                    100:104,
                    106:110,
                    112:116)]

#Make the variable names the corresponding years
names(wgi_RL)<- wgi_RL[1,]
names(wgi_RL)[1] <- "country"
wgi_RL = wgi_RL[-c(1:2),]

# Reshape the data
wgi_RL= gather(wgi_RL,"year","RL_EST",2:20)

# Fix missing data
wgi_RL$RL_EST <- as.numeric(wgi_RL$RL_EST)

# Control of corruption, estimate [CC_EST_WGI]
wgi_CC = read_excel(paste(rawdata,"RAWDATA_WGI_2017.xlsx", sep=""), 7, col_names = TRUE)
wgi_CC = wgi_CC[-c(1:12),]
wgi_CC = wgi_CC[,-c(2,4:8,
                    10:14,
                    16:20,
                    22:26,
                    28:32,
                    34:38,
                    40:44,
                    46:50,
                    52:56,
                    58:62,
                    64:68,
                    70:74,
                    76:80,
                    82:86,
                    88:92,
                    94:98,
                    100:104,
                    106:110,
                    112:116)]

#Make the variable names the corresponding years
names(wgi_CC)<- wgi_CC[1,]
names(wgi_CC)[1] <- "country"
wgi_CC = wgi_CC[-c(1:2),]

# Reshape the data
wgi_CC= gather(wgi_CC,"year","CC_EST",2:20)

# Fix missing data
wgi_CC$CC_EST <- as.numeric(wgi_CC$CC_EST)

##### MERGE 
wgi <- merge(wgi_VA, wgi_PV, by=c("country","year"),all=TRUE)
wgi <- merge(wgi, wgi_GE, by=c("country","year"),all=TRUE)
wgi <- merge(wgi,wgi_GQ, by=c("country","year"),all=TRUE)
wgi <- merge(wgi,wgi_RL, by=c("country","year"),all=TRUE)
wgi <- merge(wgi,wgi_CC, by=c("country","year"),all=TRUE)

sum(is.na(wgi$country)) #0
# # Number of countries and observations before cleaning
length(unique(wgi$country))#214
length(wgi$country) #4066

# Rename the country Cote dIvoire because it has special character that R cannot recognize
wgi$country[wgi$country=="Côte d'Ivoire"] = "Cote d'Ivoire"
wgi$country[wgi$country=="Réunion"] = "Reunion"
wgi$country[wgi$country=="São Tomé and Principe"] = "Sao Tome & Principe"

#Append country IDs
wgi = append_ids(wgi, breaks = F)

# Add variable labels
label(wgi$VA_EST) <- "Voice and accountability, estimate  [WB WGI]"
label(wgi$PV_EST) <- "Political stability absence of violence, estimate [WB WGI]"
label(wgi$GE_EST) <- "Government effectiveness, estimate [WB WGI]"
label(wgi$GQ_EST) <- "Regulatory quality, estimate [WB WGI]"
label(wgi$RL_EST) <- "Rule of law, estimate [WB WGI]"
label(wgi$CC_EST) <- "Control of corruption, estimate [WB WGI]"

# Append suffix WGI to vairables
wgi = append_suffix(wgi,"WGI")

length(unique(wgi$country))#198
length(wgi$country) #3731

#check for duplicates
sum(duplicated(wgi[,c("gwno","year")])) # 0 

save(wgi,file=paste(preppeddata,"PREPPED_WGI_2017_AL.RDATA",sep=""))
