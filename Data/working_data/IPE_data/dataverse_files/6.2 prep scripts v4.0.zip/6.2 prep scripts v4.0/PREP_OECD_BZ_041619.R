# /************************* 
# Source: Organisation for Economic Co-operation and Development
# Accessed: March 13, 2017
# URL: http://stats.oecd.org/
# Query specifications: all countries, all years, variables: long term interest rate
# 
# Time: 1954-2016
# By: Grace Xu
# Edited by: Baiyu Zhu
# Time: 1954-2018
# Suffix: OECD
# Variables: Long-term interest rate
# *************************/

library(Hmisc)

#import
oecd <- read.csv(paste(rawdata, "RAWDATA_OECD_2018.csv", sep=""))

#cut out unecessary variables
oecd = oecd[,c("Country",
               "Time",
               "Value")]

#renaming variables
names(oecd)[names(oecd)=="Time"] = "year"
names(oecd)[names(oecd)=="Value"] = "ltint"

#label
label(oecd$ltint) <- "Long-term interest rate (percentage) [OECD]"

oecd$Country = as.character(oecd$Country)

#appending gwnos
oecd = append_ids(oecd, breaks = F)

#labels
label(oecd$ltint) = "Long-term interest rate [OECD], percentage"

#append suffix
oecd = append_suffix(oecd, "OECD")

#save
save(oecd,file=paste(preppeddata,"PREPPED_OECD_BZ_2018.RDATA",sep=""))
