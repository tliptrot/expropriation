# /**************************
# Data: Composite Index of National Capability (CINC) index 
# Dataset: COW materials capabilities (CINC) data
# Data source url: http://www.correlatesofwar.org/data-sets/national-material-capabilities
# Codebook url: http://www.correlatesofwar.org/data-sets/national-material-capabilities/nmc-codebook-v5-1
# Time: 1816-2012
# Updated: 2018.02.17
# By: Sherry on 2017.02.01
# Edited By: Emily on 2018.02.17
# Suffix: MC
# 
# Citation:
#   Singer, J. David, Stuart Bremer, and John Stuckey. (1972). "Capability Distribution, Uncertainty, 
#   and Major Power War, 1820-1965." in Bruce Russett (ed) Peace, War, and Numbers, Beverly Hills: Sage, 19-48.
# 
#   Singer, J. David. 1987. "Reconstructing the Correlates of War Dataset on Material Capabilities of States, 
#   1816-1985" International Interactions, 14: 115-32.
#
# #****************************/

library(Hmisc)
library(countrycode)

mc = read.csv(paste(rawdata,"RAWDATA_MC_2017.csv",sep=""))

#Keep variables we are interestd
mc = mc[, c("stateabb", "ccode", "year", "irst", "tpop", "upop", "cinc", "milex", "milper", "pec")]

#Rename some variables
names(mc)[names(mc)=="stateabb"] = "country"


#Append country names based on COW codes
mc$country <- countrycode(mc$ccode, "cown", "country.name")
mc$country[mc$ccode == 730] <- "Korea"
mc$country[mc$ccode == 260] <- "German Federal Republic"

#change order of columns
mc <-mc[,c("ccode","country", "year","irst","tpop","upop","cinc","milex","milper","pec")]

#Append country IDs 
mc = append_ids(mc, breaks = F)

# Drop a couple of duplicates from Germany and Yemen

# Germany
# Germany 1945- 1949
# Drop duplicates when ccode_raw = 260 (German Federal Republic), 265 (German Democratic Republic) 
# and year = 1990
mc<-mc[!(mc$ccode_raw=="260" & mc$year==1990),]
mc<-mc[!(mc$ccode_raw=="265" & mc$year==1990),]

# Yemen
# Yemen Arab Republic YAR 1926 -1990 
# Yemen 1990 - 2012 ---------Changed to Arab Republic of Yemen
# Yemen People's Republic 1967 - 1990 
mc<-mc[!(mc$countryname_raw=="Yemen" & mc$year==1990),]

# Check duplicates
n_occur <- data.frame(table(mc$country, mc$year))
n_occur[n_occur$Freq > 1,]

#Add variable labels
label(mc$cinc) <- "CINC Score [MC]"
label(mc$milex) <- "Military Expenditures [MC]"
label(mc$milper) <- "Military Personnel  [MC]"
label(mc$irst) <- "Iron and steel production [MC]"
label(mc$pec) <- "Primary energy consumption [MC]"
label(mc$tpop) <- "Total Population [MC]"
label(mc$upop) <- "Urban population [MC]"

# Number of unique countries
length(unique(mc$gwno)) # 217

# Range of years
range(mc$year) #1816-2012

# Append suffix MC to vairables 

mc = append_suffix(mc,"MC")

mc$ccode_raw_MC = NULL

save(mc,file=paste(preppeddata,"PREPPED_MC_EH_02172018.RDATA",sep=""))
