###############################
# BEA US Outward FDI Stocks, Historical Cost Basis [OFS]
# Accessed: March 10, 2019
# Year Range: 1982-2017
# Prepped By: Alicia Kuang
# Suffix: OFS
#
# Data Source: http://www.bea.gov/international/di1usdbal.htm
#
# Citation: U.S. Bureau of Economic Analysis. U.S. Direct Investment Abroad, U.S. Direct Investment Position Abroad on a Historical-Cost Basis. 
# http://www.bea.gov/international/di1usdbal.htm (accessed March, 2019).
#
# Variables: ind_total_OFS , Label: "Rule of Law: Corruption Prevention [SGI]"
# Label: Outward FDI stocks from the US in USD (millions), all industries, BEA [OFS]
#
###############################

library(Hmisc)
library(dplyr)
library(tidyr)
library(readxl)

# --- 2016 - 2017

# importing sheets
ofs_2017 <- read_xlsx(paste(rawdata,"RAWDATA_OFS_2017.xlsx", sep=""), col_names = FALSE, sheet=8)
ofs_2016 <- read_xlsx(paste(rawdata,"RAWDATA_OFS_2017.xlsx", sep=""), col_names = FALSE, sheet=7)

# change rows to columns and columns to rows
ofs_2017 <- as.data.frame(t(ofs_2017))
ofs_2016 <- as.data.frame(t(ofs_2016))

# make first row the header row
colnames(ofs_2017) <- ofs_2017[1, ]
ofs_2017 <- ofs_2017[-1, ]
colnames(ofs_2016) <- ofs_2016[1, ]
ofs_2016 <- ofs_2016[-1, ]

# get columns needed
ofs_2017 <- ofs_2017[, 3:4]
ofs_2017 <- ofs_2017[-1, ]
ofs_2016 <- ofs_2016[, 3:4]
ofs_2016 <- ofs_2016[-1, ]

# rename
colnames(ofs_2017)[1] <- "country"
colnames(ofs_2017)[2] <- "ind_total"
colnames(ofs_2016)[1] <- "country"
colnames(ofs_2016)[2] <- "ind_total"

# add years
ofs_2017$year <- rep(2017, nrow(ofs_2017))
ofs_2016$year <- rep(2016, nrow(ofs_2016))

#------- Read all worksheets in one file

read_excel_allsheets = function(filename) {
  sheets = readxl::excel_sheets(filename)
  x = lapply(sheets, function(X) readxl::read_excel(filename, sheet = X))
  names(x) = sheets
  x
}


# -------- Data prepping function

prep.ofs <- function(newfile){
  # Rename variables
  names(newfile)[1] = "country"
  names(newfile)[2] = "ind_total"
  
  # Remove the header and blank rows
  newfile = newfile[-c(1:5),]
  newfile = newfile[!is.na(newfile$country),]
  
  # Keep only the country and ind_total variables
  newfile = newfile[,c(1:2)]
  
  return(newfile)
}


# -------- Extract dataframes from list; clean them; add a year variable; and merge
#          them into one dataframe.

# --- 2010 - 2015

ofs_sheets_2010_2015 = read_excel_allsheets(paste(rawdata, "RAWDATA_OFS_2015.xlsx", sep=""))

data = NULL
ofs2010_2015 = NULL

for(i in 2010:2015){
  data = as.data.frame(ofs_sheets_2010_2015[as.character(i)])
  data = prep.ofs(data)
  data$year = i  
  
  ofs2010_2015 = rbind(ofs2010_2015, data)
}

# ---- 2000 - 2009

ofs_sheets_2000_2009 = read_excel_allsheets(paste(rawdata, "RAWDATA_OFS_2009.xls", sep=""))

data = NULL
ofs2000_2009 = NULL

for(i in 2000:2009){
  data = as.data.frame(ofs_sheets_2000_2009[as.character(i)])
  data = prep.ofs(data)
  data$year = i  
  
  ofs2000_2009 = rbind(ofs2000_2009, data)
}


# ---- 1990 - 1999

ofs_sheets_1990_1999 = read_excel_allsheets(paste(rawdata, "RAWDATA_OFS_1999.xls", sep=""))

data = NULL
ofs1990_1999 = NULL

for(i in 1990:1999){
  data = as.data.frame(ofs_sheets_1990_1999[as.character(i)])
  data = prep.ofs(data)
  data$year = i  
  
  ofs1990_1999 = rbind(ofs1990_1999, data)
}


# ---- 1982 - 1989

ofs_sheets_1982_1989 = read_excel_allsheets(paste(rawdata, "RAWDATA_OFS_1989.xls", sep=""))

data = NULL
ofs1982_1989 = NULL

for(i in 1982:1989){
  data = as.data.frame(ofs_sheets_1982_1989[as.character(i)])
  data = prep.ofs(data)
  data$year = i  
  
  ofs1982_1989 = rbind(ofs1982_1989, data)
}


####

# --- Merge all the dataframes into one
ofs = rbind(ofs1982_1989, ofs1990_1999, ofs2000_2009, ofs2010_2015, ofs_2016, ofs_2017)

# --- Order rows by country-year
ofs = ofs[order(ofs$country, ofs$year),]

# --- Append country IDs
ofs = append_ids(ofs, breaks = F)
ofs = append_suffix(ofs,"OFS")

# --- Transform ind_total_OFS from character to numeric
str(ofs)
# Removing commas from some of the observations so we can transform from character to numeric
ofs$ind_total_OFS = gsub(",", "", ofs$ind_total_OFS)
ofs$ind_total_OFS = as.numeric(ofs$ind_total_OFS)
str(ofs)
sum(is.na(ofs$ind_total_OFS))

# --- Checking for duplicates - there are none
n_occur <- data.frame(table(ofs$gwno, ofs$year))
n_occur[n_occur$Freq > 1,]

# --- Number of countries in the dataset 
n_countries = ofs %>%
  group_by(country) %>%
  dplyr::summarise(n_years = n() ) %>%
  arrange(desc(n_years)) #59

# --- Add variable labels
label(ofs$ind_total_OFS) = "Outward FDI stocks from the US in USD (millions), all industries, BEA [OFS]"

# --- Saving
save(ofs,file=paste(preppeddata,"PREPPED_OFS_AK_2017.RDATA",sep=""))


