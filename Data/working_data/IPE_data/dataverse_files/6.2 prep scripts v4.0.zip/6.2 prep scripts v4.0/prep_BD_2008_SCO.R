#***************************************************************************************************
#Name: PRIO Battle Deaths Dataset [BD]
#Version: 2008 v3.1
#Year Range: 1946-2008
#Suffix: BD

#Access Date: 2018.09.14
#Prepped By: Sarah Orsborn
  #Last Code Update: 2018.11.24

#Data URL: https://www.prio.org/Data/Armed-Conflict/Battle-Deaths/The-Battle-Deaths-Dataset-version-30/
    #Codebook URL: https://www.prio.org/Global/upload/CSCW/Data/PRIObd3.0_codebook.pdf
#Citation: Lacina, Bethany & Nils Petter Gleditsch (2005) Monitoring trends in global combat: 
          #A new dataset of battle deaths', European Journal of Population 21(2-3): 145-166.

#Variables: bdeadlow, bdeadhigh, bdeadbest
#****************************************************************************************************

library(Hmisc)
library(readxl)
library(tidyr)
library(dplyr)

#import data
prio <-read_excel(paste(rawdata,"RAWDATA_BD_2008.xls",sep=""))

#eliminate extraneous variables
prio <- prio[,c("id","year","bdeadlow","bdeadhig","bdeadbes","location")]

#rename variables
names(prio)[names(prio)=="id"] <- "id_PO"
names(prio)[names(prio)=="bdeadhig"] <- "bdeadhigh"
names(prio)[names(prio)=="bdeadbes"] <- "bdeadbest"
names(prio)[names(prio)=="location"] <- "countryname"

#rearrange columns
prio <- prio[,c("countryname","year","id_PO","bdeadlow","bdeadhigh","bdeadbest")]

#delete countries with no GWNO
#//19//Hyderabad
prio <- prio[- grep("Hyderabad", prio$countryname),]


#****************************************************************************************************
#Process for MULTIPLE COUNTRY conflicts: 
#       This data set does not split battle deaths [BD] between countries in interstate conflicts. 
#       To sum BD per country per year, we 
#Path 1) Determine where most of the fighting happened and assign all BD to that country. 
#       i.e. ("France, Thailand")//Colonial conflict fought in colony. Keep Thailand. 
#Path 2) If unclear, we'll split the BD data to create an observation for each country. 
#       We will assign an equal share of the BD data to each. 
#       i.e. ("India, Pakistan")//Fought in both countries. Keep both. 

#Label is #//id_PO//country
#****************************************************************************************************

#PATH 1 CONFLICTS (fought in one state)

#Address by renaming case by case. 

#//15//France, Thailand
#Colonial conflict fought in colony. Keep Thailand. 
prio$countryname <- gsub("France, Thailand","Thailand",prio$countryname)

#//16//Albania, United Kingdom
#Colonial conflict fought in colony. Keep Albania. 
prio$countryname <- gsub("Albania, United Kingdom","Albania",prio$countryname)

#//28//Hyderabad, India
#Hyderabad has no GWNO, so remove it. Keep India. 
prio$countryname <- gsub("Hyderabad, India","India",prio$countryname)

#//42//Egypt, United Kingdom
#Colonial conflict fought primarily in Egypt. Keep Egypt. 
prio$countryname <- gsub("Egypt, United Kingdom","Egypt",prio$countryname)

#//53//Hungary, Russia (Soviet Union)
#Hungarian Revolution fought primarily in Hungary. Keep Hungary. 
prio$countryname <- gsub("Hungary, Russia","Hungary",prio$countryname)

#//55//Egypt, France, Israel, United Kingdom
#Suez Crisis, fought primarily in Egypt. Keep Egypt. 
prio$countryname <- gsub("Egypt, France, Israel, United Kingdom","Egypt",prio$countryname)

#//75//France, Tunisia
#Fought at the Bizerte Naval Base in Tunisia. Keep Tunisia. 
prio$countryname <- gsub("France, Tunisia","Tunisia",prio$countryname)

#//79//Indonesia, Netherlands
#West New Guinea dispute fought primarily in Indonesia. Keep Indonesia. 
prio$countryname <- gsub("Indonesia, Netherlands","Indonesia",prio$countryname)

#//155//Grenada, United States of America
#U.S. invasion of Grenada. Keep Grenada. 
prio$countryname <- gsub("Grenada, United States of America","Grenada",prio$countryname)

#//173//Panama, United States of America
#U.S. invasion of Panama. Keep Panama. 
prio$countryname <- gsub("Panama, United States of America","Panama",prio$countryname)

#//226//Australia, Iraq, United Kingdom, United States of America
#Invasion of Iraq. Keep Iraq. 
prio$countryname <- gsub("Australia, Iraq, United Kingdom, United States of America","Iraq",prio$countryname)

#//256//Afghanistan, Russia (Soviet Union)
#Fought in Afghanistan. 
prio$countryname <- gsub("Afghanistan, Russia (Soviet Union)","Afghanistan",prio$countryname)

#****************************************************************************************************

#PATH 2 CONFLICTS (keep all remaining countries)

#All remaining conflicts are Path 2. 
#   We will divide battle deaths by number of countries in the "countryname" string. 
#   Then split these rows into separate rows for each country
#     ie.       countryname         year      high  low   best
#               India, Pakistan     1946      20    20    20

#Divide BDs     India, Pakistan     1946      10    10    10

#Sep. Rows      India               1946      10    10    10
#               Pakistan            1946      10    10    10


#Divide battle death values by number of countries. 
#Replace "-999" values with NA

for(row in 1:nrow(prio)){
  countrycount <- count.fields(textConnection(prio$countryname[row]), sep = ",")
  prio$bdeadlow[row] <- prio$bdeadlow[row]/countrycount
  prio$bdeadhigh[row] <- prio$bdeadhigh[row]/countrycount
  if(prio$bdeadbest[row]!=-999){
    prio$bdeadbest[row] <- prio$bdeadbest[row]/countrycount
  }
  else{
    prio$bdeadbest[row] <- NA
  }
}

#Split rows containing a comma into separate observations for each country. 
prio <- separate_rows(prio, countryname, sep = ",", convert = FALSE)

#//20//India, Pakistan
#Fought in both India and Pakistan. Keep both. 

#//30//Egypt, Iraq, Israel, Jordan, Lebanon, Syria
#This was fought in all of them. Keep all. 

#//35//China, Taiwan
#Both were claiming sovereign control over the whole of China and Taiwan. Keep both. 

#//38//North Korea, South Korea
#North-South conflict. Keep both. 

#//58//Honduras, Nicaragua
#Border conflict. Keep both. 

#//71//Ethiopia, Somalia
#Border conflict. Keep both. 

#//77//China, India
#Border conflict. Keep both. 

#//81//Algeria, Morocco
#Border conflict. Keep both. 

#//84//Indonesia, Malaysia
#Largely fought on the border. Keep both. 

#//96//North Vietnam, South Vietnam
#North-South conflict. Keep both. 

#//97//Cambodia, Thailand
#Border conflict. Keep both. 

#//104//Egypt, Israel
#Keep both. 

#//105//Israel, Jordan
#Keep both. 

#//106//Israel, Syria
#Keep both. 

#//108//China, Myanmar
#Border conflict. Keep both. 

#//109//China, Russia (Soviet Union)
#Border conflict. Keep both. 

#//110//El Salvador, Honduras
#Border conflict. Keep both. 

#//124//North Yemen, South Yemen
#North-South conflict. Keep both. 

#//127//Cyprus, Turkey/Ottoman Empire
#Seems to have been fought in Cyprus and Turkey. Keep both. 

#//128//Iran, Iraq
#Keep both. 

#//132//Cambodia, Vietnam
#Border conflict. Keep both. 

#//138//China, Vietnam
#Sino-Vietnamese War. Keep both. 

#//151//Argentina, United Kingdom. 
#Fought in UK-controlled Falkland Islands. 

#//154//Chad, Nigeria
#Border conflict. Keep both. 

#//160//Burkina Faso, Mali
#Border dispute. Keep both. 

#//161//Laos, Thailand
#Border conflict. Keep both. 

#//166//Chad, Libya
#Border conflict. Keep both. 

#//176//Iraq, Kuwait
#Border conflict. Keep both. 

#//208//Ecuador, Peru
#Border conflict. Keep both. 

#//210//Cameroon, Nigeria
#Border conflict. Keep both. 

#//215//Eritrea, Ethiopia
#Border conflict. Keep both. 

#//252//Tanzania, Uganda
#Fought around border. Keep both. 

#//260//Djibouti, Eritrea
#Border conflict. Keep both. 


#****************************************************************************************************
#FINAL PREP

#Sum by country and year - edited MB june 2020
prio <- prio %>% 
  mutate(countryname = str_trim(countryname, "both")) %>%
  group_by(countryname, year) %>% dplyr::summarise_all(sum, na.rm = T)

# resets missing values in bdbest to NA instead of 0 (0s produced by sum())
prio$bdeadbest <- replace(prio$bdeadbest, prio$bdeadbest == 0, NA)  
  
#prio <- aggregate(.~ countryname + year, data = prio, sum)

#Drop id_PO column
prio <- prio[,c("countryname","year","bdeadlow","bdeadhigh","bdeadbest")]

#Append ids
#source(paste(fall2018, "append_ids.R",sep=""))
prio <- append_ids(prio, breaks = F)

n_occur <- data.frame(table(prio$country, prio$year))
print(n_occur[n_occur$Freq > 1,])

# remove duplicate
prio <- prio[!(prio$countryname_raw == "Vietnam" & prio$year == 1975),]

#Sort by country and year
prio <- prio[order(prio$country,prio$year),]

#Append suffix
prio <- append_suffix(prio, "BD")

#Label
label(prio$bdeadlow_BD) <- "Low estimate of annual battle fatalities [BD]"
label(prio$bdeadhigh_BD) <- "High estimate of annual battle fatalities [BD]"
label(prio$bdeadbest_BD) <- "Best estimate of annual battle fatalities [BD]"

#Save
save(prio, file=paste(preppeddata, "PREPPED_BD_SCO_112418.RDATA",sep=""))

        #****************************************************************************************************