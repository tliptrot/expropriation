# /***************************
# World Bank Statistical Capacity Data
# DOwnloaded July 2018
# 
# http://databank.worldbank.org/data/reports.aspx?source=Statistical-capacity-indicators#
# 
# Citation: TBD
# 
# Time Period: 2004-2017
# Coded by: Ben Graham
# Revised by: 
# ****************************/

#import
library(plyr)
library(readxl)

wbsc <- read_excel(paste(rawdata, 'RAWDATA_SC_2018.xlsx', sep = ""))

wbsc = plyr::rename(wbsc, c("Country Name" = "country",
                            "Time" ="year",
                            "Statistical Capacity score (Overall average)" = "statcapacity", 
                            "Source data assessment of statistical capacity (scale 0 - 100)" = "statcapacity_sda",
                            "Methodology assessment of statistical capacity (scale 0 - 100)" ="statcapacity_ma",
                            "Periodicity and timeliness assessment of statistical capacity (scale 0 - 100)" = "statcapacity_per"))

# label variables
library(Hmisc)
label(wbsc$statcapacity) =	"Statistical Capacity score (Overall average) [SC]"
label(wbsc$statcapacity_sda)	= "Source data assessment of statistical capacity (scale 0 - 100) [SC]"
label(wbsc$statcapacity_ma) = "Methodology assessment of statistical capacity (scale 0 - 100) [SC]"
label(wbsc$statcapacity_per) =	"Periodicity and timeliness assessment of statistical capacity (scale 0 - 100) [SC]"

# check for duplicates
n_occur <- data.frame(table(wbsc$country, wbsc$year))
n_occur[n_occur$Freq>1,]

# append IDs
wbsc = append_ids(wbsc, breaks = FALSE)
wbsc = append_suffix(wbsc, "SC")

# how many countries? what time period?
length(unique(wbsc$gwno)) # 145
range(wbsc$year) # 2004 2017

# Save
save(wbsc, file = paste(preppeddata,"prepped_SC_MB_2017.RDATA", sep=""))
