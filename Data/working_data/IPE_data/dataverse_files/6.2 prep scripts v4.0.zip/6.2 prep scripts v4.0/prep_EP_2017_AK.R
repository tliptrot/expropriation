# /************************* 
# Source:  GROWup - Geographical Research On War, Unified Platform 
# Accessed: October 6, 2018
# URL: https://growup.ethz.ch/pfe/
# Query specifications: all countries, all years, variables: egip_groups_count_EP, excl_groups_count_EP, regaut_groups_count_EP, regaut_excl_groups_count_EP, regaut_egip_groups_count_EP, rlvt_groups_count_EP, actv_groups_count_EP, lpop_EP, egippop_EP, legippop_EP, exclpop_EP, lexclpop_EP, discrimpop_EP, ldiscrimpop_EP, maxexclpop_EP, lmaxexclpop_EP, regautpop_EP, regautexclpop_Ep, regautegippop_EP, cntr_relevance_EP
# Time: 1946-2017
# By: Alicia Kuang
# Suffix: EP
# Variables: 
# egip_groups_count_EP: Number of EGIP groups [EP]
# excl_groups_count_EP: Number of MEG groups [EP]
# regaut_groups_count_EP: Number of groups with regional autonomy [EP]
# regaut_excl_groups_count_EP: Number of MEG groups with regional autonomy [EP] 
# regaut_egip_groups_count_EP: Number of EGIP groups with regional autonomy [EP]
# rlvt_groups_count_EP: Number of relevant groups [EP]
# actv_groups_count_EP: Number of active groups [EP]
# lpop_EP: Sum of ethnically relevant population as fraction of total population [EP]
# egippop_EP: Sum of the population of all EGIP groups as fraction of total population [EP]
# legippop_EP: EGIP population as a fraction of ethnically relevant population [EP]
# exclpop_EP: Sum of the population of all MEG groups as fraction of total population [EP]
# lexclpop_EP: MEG population as a fraction of ethnically relevant population [EP]
# discrimpop_EP: Sum of discriminated population as fraction of total population [EP]
# ldiscrimpop_EP: Sum discriminated population as fraction of ethnically relevant population [EP]  
# maxexclpop_EP:  Size of largest MEG group as fraction of total population [EP]
# lmaxexclpop_EP: Size of largest MEG group as fraction of ethnically relevant population [EP]
# regautpop_EP: Sum of population with regional autonomy as fraction of total population [EP]
# regautexclpop_Ep: Sum pop. with regional autonomy and excluded MEG as fraction of total pop. [EP]  
# regautegippop_EP: Sum pop. with regional autonomy and included EGIP as fraction of total pop. [EP]
# cntr_relevance_EP: Is ethnicity relevant at least once in sample period (0=No, 1=Yes) [EP]
# *************************/

library(Hmisc)
library(readxl)

#make sure it matches codebook

EP = read_excel(paste(rawdata,"RAWDATA_EP_2017.xls", sep = ""))

#renaming variables
names(EP)[names(EP)=="countryname"]="Country"

#Keep only the variables we need
EP = EP[, c("Country","year",
            "egip_groups_count",
            "excl_groups_count","regaut_groups_count", "regaut_excl_groups_count", "regaut_egip_groups_count", "rlvt_groups_count", "actv_groups_count", "lpop", "egippop", "legippop", "exclpop", "lexclpop", "discrimpop", "ldiscrimpop", "maxexclpop", "lmaxexclpop", "regautpop", "regautexclpop", "regautegippop", "cntr_relevance")]

#label
label(EP$egip_groups_count) <- "Number of EGIP groups [EP]"
label(EP$excl_groups_count) <- "Number of MEG groups [EP]"
label(EP$regaut_groups_count)<- "Number of groups with regional autonomy [EP]"
label(EP$regaut_excl_groups_count)<- "Number of MEG groups with regional autonomy [EP]" 
label (EP$regaut_egip_groups_count)<- "Number of EGIP groups with regional autonomy [EP]"
label (EP$rlvt_groups_count)<- "Number of relevant groups [EP]"
label (EP$actv_groups_count)<- "Number of active groups [EP]"
label (EP$lpop)<- "Sum of ethnically relevant population as fraction of total population [EP]"
label (EP$egippop)<- "Sum of the population of all EGIP groups as fraction of total population [EP]"
label (EP$legippop)<- "EGIP population as a fraction of ethnically relevant population [EP]"
label (EP$exclpop)<- "Sum of the population of all MEG groups as fraction of total population [EP]"
label (EP$lexclpop)<- "MEG population as a fraction of ethnically relevant population [EP]"
label (EP$discrimpop)<- "Sum of discriminated population as fraction of total population [EP]"
label (EP$ldiscrimpop)<- "Sum discriminated population as fraction of ethnically relevant population [EP]"  
label (EP$maxexclpop)<-  "Size of largest MEG group as fraction of total population [EP]"
label (EP$lmaxexclpop)<-"Size of largest MEG group as fraction of ethnically relevant population [EP]"
label (EP$regautpop)<- "Sum of population with regional autonomy as fraction of total population [EP]"
label (EP$regautexclpop)<- "Sum pop. with regional autonomy and excluded MEG as fraction of total pop. [EP]"  
label (EP$regautegippop)<- "Sum pop. with regional autonomy and included EGIP as fraction of total pop. [EP]"
label(EP$cntr_relevance)<- "Is ethnicity relevant at least once in sample period (0=No, 1=Yes) [EP]"

#appending gwnos
EP = append_ids(EP, breaks = F)

#append suffix
EP = append_suffix(EP, "EP")

save(EP,file=paste(preppeddata,"PREPPED_EP_2017_AK.RDATA",sep=""))
