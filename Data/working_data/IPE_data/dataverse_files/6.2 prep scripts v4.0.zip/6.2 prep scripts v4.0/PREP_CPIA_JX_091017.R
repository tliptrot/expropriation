#**************************
# Data: Country Policy and Institutional Assessment
# Source: The World Bank 
# Data source url: https://data.worldbank.org/data-catalog/CPIA
# Citation: Country Policy and Institutional Assessment, World Bank Group 
# Time: 2005-2016 
# Last Updated: July 18, 2017
#
# Coded by: Jessica Xu 
# Revised by: Suzie Mulesky (5/7/2018)
# Suffix: CPIA 
# Accessed: 9/10/17
#
#
# Variables: 
# buildhr_CPIA: CPIA building human resources rating (1=low to 6=high), 
# regenv_CPIA: CPIA business regulatory environment rating (1=low to 6=high), 
# debtpol_CPIA: CPIA debt policy rating (1=low to 6=high), 
# econman_CPIA: CPIA economic management cluster average (1=low to 6=high), 
# effrev_CPIA: CPIA efficiency of revenue mobilization rating (1=low to 6=high), 
# equitypub_CPIA: CPIA equity of public resource use rating (1=low to 6=high), 
# finsect_CPIA: CPIA financial sector rating (1=low to 6=high), 
# fiscpol_CPIA: CPIA fiscal policy rating (1=low to 6=high), 
# gendereq_CPIA: CPIA gender equality rating (1=low to 6=high), 
# macroman_CPIA: CPIA macroeconomic management rating (1=low to 6=high), 
# socinceq_CPIA: CPIA policies for social inclusion/equity cluster average (1=low to 6=high), 
# envirsus_CPIA: CPIA policy and institutions for environmental sustainability rating (1=low to 6=high), 
# proprights_CPIA: CPIA property rights and rule-based governance rating (1=low to 6=high), 
# pubsecman_CPIA: CPIA public sector management and institutions cluster average (1=low to 6=high), 
# budgfinman_CPIA: CPIA quality of budgetary and financial management rating (1=low to 6=high), 
# pubadmin_CPIA: CPIA quality of public administration rating (1=low to 6=high), 
# socipro_CPIA: CPIA social protection rating (1=low to 6=high), 
# strucpol_CPIA: CPIA structural policies cluster average (1=low to 6=high), 
# traderat_CPIA: CPIA trade rating (1=low to 6=high), 
# transpacc_CPIA: CPIA transparency, accountability, and corruption in the public sector rating (1=low to 6=high), 
# IDAres_CPIA: IDA resource allocation index (1=low to 6=high) 
### Note on IDAres_CPIA: The World Bank's IDA Resource Allocation Index (IRAI) is based on the results of the annual CPIA exercise that covers the IDA eligible countries.

# **********************************************************

library(Hmisc)
library(readxl)
library(dplyr)
library(tidyr)
library(reshape2)

#read the csv file
CPIA <- read.csv(paste(rawdata, "RAWDATA_CPIA_2019.csv", sep=""))

#remove unnecessary variables
CPIA = select(CPIA, -c(Indicator.Code, Country.Code))

#renaming variables
names(CPIA)[names(CPIA)=="Country.Name"]="Country"
names(CPIA)[names(CPIA)=="X2005"] = "2005"
names(CPIA)[names(CPIA)=="X2006"] = "2006"
names(CPIA)[names(CPIA)=="X2007"] = "2007"
names(CPIA)[names(CPIA)=="X2008"] = "2008"
names(CPIA)[names(CPIA)=="X2009"] = "2009"
names(CPIA)[names(CPIA)=="X2010"] = "2010"
names(CPIA)[names(CPIA)=="X2011"] = "2011"
names(CPIA)[names(CPIA)=="X2012"] = "2012"
names(CPIA)[names(CPIA)=="X2013"] = "2013"
names(CPIA)[names(CPIA)=="X2014"] = "2014"
names(CPIA)[names(CPIA)=="X2015"] = "2015"
names(CPIA)[names(CPIA)=="X2016"] = "2016"

#Change year from wide to long
CPIA <- gather(CPIA,"Year","Value", 3:ncol(CPIA))
#change variable from long to wide
CPIA <- dcast(CPIA, Country + Year ~ Indicator.Name, value.var = "Value")

#renaming the variables
names(CPIA)[names(CPIA)=="CPIA building human resources rating (1=low to 6=high)"]="buildhr"
names(CPIA)[names(CPIA)=="CPIA business regulatory environment rating (1=low to 6=high)"]="regenv"
names(CPIA)[names(CPIA)=="CPIA debt policy rating (1=low to 6=high)"]="debtpol"
names(CPIA)[names(CPIA)=="CPIA economic management cluster average (1=low to 6=high)"]="econman"
names(CPIA)[names(CPIA)=="CPIA efficiency of revenue mobilization rating (1=low to 6=high)"]="effrev"
names(CPIA)[names(CPIA)=="CPIA equity of public resource use rating (1=low to 6=high)"]="equitypub"
names(CPIA)[names(CPIA)=="CPIA financial sector rating (1=low to 6=high)"]="finsect"
names(CPIA)[names(CPIA)=="CPIA fiscal policy rating (1=low to 6=high)"]="fiscpol"
names(CPIA)[names(CPIA)=="CPIA gender equality rating (1=low to 6=high)"]="gendereq"
names(CPIA)[names(CPIA)=="CPIA macroeconomic management rating (1=low to 6=high)"]="macroman"
names(CPIA)[names(CPIA)=="CPIA policies for social inclusion/equity cluster average (1=low to 6=high)"]="socinceq"
names(CPIA)[names(CPIA)=="CPIA policy and institutions for environmental sustainability rating (1=low to 6=high)"]="envirsus"
names(CPIA)[names(CPIA)=="CPIA property rights and rule-based governance rating (1=low to 6=high)"]="proprights"
names(CPIA)[names(CPIA)=="CPIA public sector management and institutions cluster average (1=low to 6=high)"]="pubsecman"
names(CPIA)[names(CPIA)=="CPIA quality of budgetary and financial management rating (1=low to 6=high)"]="budgfinman"
names(CPIA)[names(CPIA)=="CPIA quality of public administration rating (1=low to 6=high)"]="pubadmin"
names(CPIA)[names(CPIA)=="CPIA social protection rating (1=low to 6=high)"]="socipro"
names(CPIA)[names(CPIA)=="CPIA structural policies cluster average (1=low to 6=high)"]="strucpol"
names(CPIA)[names(CPIA)=="CPIA trade rating (1=low to 6=high)"]="traderat"
names(CPIA)[names(CPIA)=="CPIA transparency, accountability, and corruption in the public sector rating (1=low to 6=high)"]="transpacc"
names(CPIA)[names(CPIA)=="IDA resource allocation index (1=low to 6=high)"]="IDAres"

# Change data type
str(CPIA)
CPIA$year <- as.numeric(CPIA$ear)

# Check for duplicates
n_occur <- data.frame(table(CPIA$Country, CPIA$Year))
n_occur[n_occur$Freq>1,]

#appending gwnos
CPIA= append_ids(CPIA, breaks = FALSE)

#append suffix
CPIA = append_suffix(CPIA, "CPIA")

# Check for duplicates
n_occur <- data.frame(table(CPIA$gwno, CPIA$year))
n_occur[n_occur$Freq>1,]

CPIA <- CPIA[!is.na(CPIA$year),]

#check the number of countries and year range
length(unique(CPIA$gwno)) # 82
range(CPIA$year) # 2005-2016

# Add variable labels
label(CPIA$buildhr_CPIA) = "CPIA building human resources rating (1=low to 6=high) [CPIA]"
label(CPIA$regenv_CPIA) = "CPIA business regulatory environment rating (1=low to 6=high) [CPIA]"
label(CPIA$debtpol_CPIA) = "CPIA debt policy rating (1=low to 6=high) [CPIA]"
label(CPIA$econman_CPIA) = "CPIA economic management cluster average (1=low to 6=high) [CPIA]"
label(CPIA$effrev_CPIA) = "CPIA efficiency of revenue mobilization rating (1=low to 6=high) [CPIA]"
label(CPIA$equitypub_CPIA) = "CPIA equity of public resource use rating (1=low to 6=high) [CPIA]"
label(CPIA$finsect_CPIA) = "CPIA financial sector rating (1=low to 6=high) [CPIA]"
label(CPIA$fiscpol_CPIA) = "CPIA fiscal policy rating (1=low to 6=high) [CPIA]"
label(CPIA$gendereq_CPIA) = "CPIA gender equality rating (1=low to 6=high) [CPIA]"
label(CPIA$macroman_CPIA) = "CPIA macroeconomic management rating (1=low to 6=high) [CPIA]"
label(CPIA$socinceq_CPIA) = "CPIA policies for social inclusion/equity cluster average (1=low to 6=high) [CPIA]"
label(CPIA$envirsus_CPIA) = "CPIA policy and institutions for environmental sustainability rating (1=low to 6=high) [CPIA]"
label(CPIA$proprights_CPIA) = "CPIA property rights and rule-based governance rating (1=low to 6=high) [CPIA]"
label(CPIA$pubsecman_CPIA) = "CPIA public sector management and institutions cluster average (1=low to 6=high) [CPIA]"
label(CPIA$budgfinman_CPIA) = "CPIA quality of budgetary and financial management rating (1=low to 6=high) [CPIA]"
label(CPIA$pubadmin_CPIA) = "CPIA quality of public administration rating (1=low to 6=high) [CPIA]"
label(CPIA$socipro_CPIA) = "CPIA social protection rating (1=low to 6=high) [CPIA]"
label(CPIA$strucpol_CPIA) = "CPIA structural policies cluster average (1=low to 6=high) [CPIA]"
label(CPIA$traderat_CPIA) = "CPIA trade rating (1=low to 6=high) [CPIA]"
label(CPIA$transpacc_CPIA) = "CPIA transparency, accountability, and corruption in the public sector rating (1=low to 6=high) [CPIA]"
label(CPIA$IDAres_CPIA) = "IDA resource allocation index (1=low to 6=high) [CPIA]"


#save the file 
save(CPIA,file=paste(preppeddata,"PREPPED_CPIA_JX_2019.RDATA",sep=""))

#write.csv(CPIA,file=paste(preppeddata,"PREPPED_CPIA_JX_091017.csv",sep=""))

