# /************************* 
# Data: World Bank Education Statistics [ES]
# Data source url: http://databank.worldbank.org/data/reports.aspx?source=education-statistics-~-all-indicators

# Time:1970-2015	
# By: Sherry
# Suffix: ES

# Updated by Anna Lipscomb (October 6, 2018)
# Time 1970-2017
# Updated by Baiyu Zhu (April 2, 2019) 
# Time 1970-2018
#
# Citation:
# World Bank. 2015. Education Statistics - All Indicators. 
# http://databank.worldbank.org/data/reports.aspx?source=education-statistics-~-all-indicators
# Accessed on May 23, 2017s

# *************************/

library(Hmisc)
#library(reshape)
library(readxl)

#Read raw data
ES <-read_excel(path = (paste(rawdata, "RAWDATA_ES_2018.xlsx", sep="")), skip = 0) 

# Keep the years 1970 - 2017
# Get rid of the notes after line 264
ES <- ES[c(1:265),c(1:2, 5:53)]

# Format the column names to just the year number 

# Create a vector to hold all the years
years <- NULL
for(i in names(ES[, c(3:51)])) {
   year = substr(i, 1, 5)
   years <- c(years, year)
   names(ES)[names(ES)==i] = year
   
}

# Rename
names(ES)[names(ES)=="Country Name"] <- "Country"
names(ES)[names(ES)=="Country Code"] <- "Country.Code"

# Reshape the Dataframe so that it is country-year paired
ES <- reshape(ES, direction="long", varying=years, v.names="ptratio_seced",
                 idvar=c("Country", "Country.Code"), timevar="Year", times=1970:2018,sep = "")


#Get rid of additional attributes
row.names(ES) <- NULL

#Append ids
ES <- append_ids(ES)

# Add variable labels
label(ES$ptratio_seced) <- "Pupil-teacher ratio in secondary education (headcount basis) [ES]"

# Append suffix ES to variables
ES = append_suffix(ES,"ES")

# Order the dataframe by Country name alphabetically
ES <- ES[order(ES$country),]

length(unique(ES$gwno))  #198
range(ES$year) #1970-2018

save(ES,file=paste(preppeddata,"PREPPED_ES_BZ_2018.RDATA",sep=""))