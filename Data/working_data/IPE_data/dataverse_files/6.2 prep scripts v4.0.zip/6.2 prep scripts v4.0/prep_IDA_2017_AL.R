#/***********************
#  CPIA property rights and rule-based governance rating (1=low to 6=high)
#Data: http://data.worldbank.org/indicator/IQ.CPA.PROP.XQ

# Years: 2005 - 2017
# Number of countries: 195
# Variables: pr_rbgovn_IDA: Measure of Property Rights and Rule Based Governance [IDA]

#Citation:
#  World Bank Group, CPIA database ( worldbank.org/ida )

# Anna Lipscomb, April 2019

# Originally a .do file
#************************/

library(Hmisc)
library(readxl)
library(tidyr)


#import data
ida = read_excel(paste(rawdata,"RAWDATA_IDA_2017.xlsx", sep=""), 1, col_names = TRUE)

# change column names
colnames(ida) <- unlist(ida[row.names(ida)=='3',])
names(ida)[1] = "country"

# get rid of extra rows/columns that we don't need
ida = ida[-c(1:3),-c(2:49,63)]

# gather
ida = ida[,c(1:14)]
ida = gather(ida, "year", "pr_rbgovn", 2:14)

# append ids
ida = append_ids(ida)

#Check duplicates
sum(duplicated(ida[,c("gwno","year")])) #0

#append suffix
ida = append_suffix(ida,"IDA")

# label variables
label(ida$pr_rbgovn_IDA) = "Measure of Property Rights and Rule Based Governance [IDA]"

# how many countries? what time period?
length(unique(ida$gwno)) # 197
range(ida$year) # 2005-2017

# save
save(ida,file=paste(preppeddata,"PREPPED_IDA_2017_AL.RDATA",sep=""))
