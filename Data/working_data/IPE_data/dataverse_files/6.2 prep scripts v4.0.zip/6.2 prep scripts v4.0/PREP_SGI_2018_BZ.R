###############################
# SGI Quality of Governance Indicators
# Version: 2017
# Accessed: April 04, 2017
# Year Range: 2014-2017
# Prepped By: Sarah Orsborn
# Suffix: SGI
# Edited by: Baiyu Zhu 03.02.2019
#
# Data: http://www.sgi-network.org/2016/Downloads
# Codebook: http://www.sgi-network.org/docs/2016/basics/SGI2016_Codebook.pdf
#   
# Citation: Bertelsmann Stiftung. 2016. Sustainable Governance Indicators 
# 2016. http://www.sgi-network.org/2016/Downloads. Accessed on April 04, 2017.
#
# Variables: corrupprev_SGI, Label: "Rule of Law: Corruption Prevention [SGI]"
#
#
###############################

library(readxl)

#read raw data 2018
sgi18 = read_excel(path = (paste(rawdata, "RAWDATA_SGI_2018.xls", sep="")), sheet = "SGI 2018 Scores", skip = 0)

#For 2018 sheet
#Keep the corruption prevention variable
colnames(sgi18)[1] <- "country"

varsToKeep <- c("country", "Corruption Prevention")
sgi18 <- sgi18[varsToKeep]

sgi18$year <- 2018

#read raw data 2017
sgi17 = read_excel(path = (paste(rawdata, "RAWDATA_SGI_2018.xls", sep="")), sheet = "SGI 2017 Scores", skip = 0)

#For 2017 sheet
#Keep the corruption prevention variable
colnames(sgi17)[1] <- "country"

varsToKeep <- c("country", "Corruption Prevention")
sgi17 <- sgi17[varsToKeep]

sgi17$year <- 2017

#Read raw data 2016
sgi16 = read_excel(path = (paste(rawdata, "RAWDATA_SGI_2018.xls", sep="")), sheet = "SGI 2016 Scores", skip = 0)

#For 2016 sheet
#Keep the corruption prevention variable
colnames(sgi16)[1] <- "country"

varsToKeep <- c("country", "Corruption Prevention")
sgi16 <- sgi16[varsToKeep]

sgi16$year <- 2016

#Read raw data 2015
sgi15 = read_excel(path = (paste(rawdata, "RAWDATA_SGI_2018.xls", sep="")), sheet = "SGI 2015 Scores", skip = 0)

#For 2015 sheet
#Keep the corruption prevention variable
colnames(sgi15)[1] <- "country"

varsToKeep <- c("country", "Corruption Prevention")
sgi15 <- sgi15[varsToKeep]

sgi15$year <- 2015

#Read raw data 2014
sgi14 = read_excel(path = (paste(rawdata, "RAWDATA_SGI_2018.xls", sep="")), sheet = "SGI 2014 Scores", skip = 0)

#For 2014 sheet
#Keep the corruption prevention variable
colnames(sgi14)[1] <- "country"

varsToKeep <- c("country", "Corruption Prevention")
sgi14 <- sgi14[varsToKeep]

sgi14$year <- 2014

#Merge all three years
sgi <- rbind(sgi14, sgi15, sgi16, sgi17, sgi18)

#Change name of variable
names(sgi)[names(sgi)=="Corruption Prevention"] <- "corrupprev"

#Append ids
#source(paste(dofiles, "append_ids.R",sep=""))
sgi <- append_ids(sgi, breaks = F)

## Append Suffix
sgi <- append_suffix(sgi, "SGI")

#Label
library(Hmisc)
label(sgi$corrupprev_SGI) <- "Rule of Law: Corruption Prevention [SGI]" 

#save prepped data
save(sgi,file=paste(preppeddata,"PREPPED_SGI_BZ_03022019.RDATA",sep=""))