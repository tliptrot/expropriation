##########################################
#  Bertelsmann Transformation Index 2006-2018
# Source: Bertelsmann Transformation Index
#Data: http://www.bti-project.org/en/index/
#  Years: 2006, 2008, 2010, 2012, 2014, 2016, 2018
# Suffix: BTI
# Variables:
# prty_rights_BTI	Extent of government ensuring private property rights and regulations [BTI]
# edu_rd_BTI	Successfulness of education policies and government support for R&D [BTI]

#Citation:
#  Stiftung, Bertelsmann. 2016. Bertelsmann Transformation Index. 
# http://www.bti-project.org/en/index/. Accessed on March 4, 2019.


# Updated by Anna Lipscomb, March 2019
# Note:
#####################################

library(Hmisc)
library(readxl)

#import data
bti2006 = read_excel(paste(rawdata,"RAWDATA_BTI_2018.xlsx", sep=""), 1, col_names = TRUE)
bti2006 = bti2006[,c(1,41,50)]
bti2006$year = rep("2006",nrow(bti2006))
bti2006 = bti2006[,c(1,4,2,3)]
bti2006 = bti2006[-130,]
names(bti2006)[1] <- "country"
names(bti2006)[3] <- "prty_rights"
names(bti2006)[4] <- "edu_rd"

bti2008 = read_excel(paste(rawdata,"RAWDATA_BTI_2018.xlsx", sep=""), 2, col_names = TRUE)
bti2008 = bti2008[,c(1,41,50)]
bti2008$year = rep("2008",nrow(bti2008))
bti2008 = bti2008[,c(1,4,2,3)]
names(bti2008)[1] <- "country"
names(bti2008)[3] <- "prty_rights"
names(bti2008)[4] <- "edu_rd"

bti2010 = read_excel(paste(rawdata,"RAWDATA_BTI_2018.xlsx", sep=""), 3, col_names = TRUE)
bti2010 = bti2010[,c(1,41,50)]
bti2010$year = rep("2010",nrow(bti2010))
bti2010 = bti2010[,c(1,4,2,3)]
names(bti2010)[1] <- "country"
names(bti2010)[3] <- "prty_rights"
names(bti2010)[4] <- "edu_rd"

bti2012 = read_excel(paste(rawdata,"RAWDATA_BTI_2018.xlsx", sep=""), 4, col_names = TRUE)
bti2012 = bti2012[,c(1,41,50)]
bti2012$year = rep("2012",nrow(bti2012))
bti2012 = bti2012[,c(1,4,2,3)]
names(bti2012)[1] <- "country"
names(bti2012)[3] <- "prty_rights"
names(bti2012)[4] <- "edu_rd"

bti2014 = read_excel(paste(rawdata,"RAWDATA_BTI_2018.xlsx", sep=""), 5, col_names = TRUE)
bti2014 = bti2014[,c(1,41,50)]
bti2014$year = rep("2014",nrow(bti2014))
bti2014 = bti2014[,c(1,4,2,3)]
names(bti2014)[1] <- "country"
names(bti2014)[3] <- "prty_rights"
names(bti2014)[4] <- "edu_rd"

bti2016 = read_excel(paste(rawdata,"RAWDATA_BTI_2018.xlsx", sep=""), 6, col_names = TRUE)
bti2016 = bti2016[,c(1,41,50)]
bti2016$year = rep("2016",nrow(bti2016))
bti2016 = bti2016[,c(1,4,2,3)]
names(bti2016)[1] <- "country"
names(bti2016)[3] <- "prty_rights"
names(bti2016)[4] <- "edu_rd"

bti2018 = read_excel(paste(rawdata,"RAWDATA_BTI_2018.xlsx", sep=""), 7, col_names = TRUE)
bti2018 = bti2018[,c(1,41,50)]
bti2018$year = rep("2018",nrow(bti2018))
bti2018 = bti2018[,c(1,4,2,3)]
names(bti2018)[1] <- "country"
names(bti2018)[3] <- "prty_rights"
names(bti2018)[4] <- "edu_rd"

# Merge

bti <- merge(bti2006, bti2008, by=c("country","year","prty_rights","edu_rd"),all=TRUE)
bti <- merge(bti, bti2010, by=c("country","year","prty_rights","edu_rd"),all=TRUE)
bti <- merge(bti, bti2012, by=c("country","year","prty_rights","edu_rd"),all=TRUE)
bti <- merge(bti, bti2014, by=c("country","year","prty_rights","edu_rd"),all=TRUE)
bti <- merge(bti, bti2016, by=c("country","year","prty_rights","edu_rd"),all=TRUE)
bti <- merge(bti, bti2018, by=c("country","year","prty_rights","edu_rd"),all=TRUE)


bti = append_ids(bti, breaks = F)
bti = append_suffix(bti,"BTI")

# Fix missing data
bti$prty_rights_BTI <- as.numeric(bti$prty_rights_BTI)
bti$edu_rd_BTI <- as.numeric(bti$edu_rd_BTI)

label(bti$prty_rights_BTI) <- "Extent of government ensuring private property rights and regulations [BTI]"
label(bti$edu_rd_BTI) <- "Successfulness of education policies and government support for R&D [BTI]"
  
remove(bti2006,
       bti2008,
       bti2010,
       bti2012,
       bti2014,
       bti2016,
       bti2018)

# how many countries? what time period?
length(unique(bti$gwno)) # 130
range(bti$year) # 2006-2018

# Save
save(bti,file=paste(preppeddata,"PREPPED_BTI_2018_AL.RDATA",sep=""))
