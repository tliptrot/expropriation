# /**************************
# Data: The trilemma indexes
# Dataset: Aizenman, Chinn, and Ito
# Data source url: http://web.pdx.edu/~ito/trilemma_indexes.htm
# Codebook url: http://web.pdx.edu/~ito/ReadMe_trilemma_indexes2014.pdf
# Time: 1960-2017
# Updated: Feb 12, 2019
# By: Anna Lipscomb
# Suffix: TR
# 
# Citation:
#   Aizenman, Joshua, Menzie D. Chinn, and Hiro Ito (2010). "The Emerging Global Financial 
# Architecture: Tracing and Evaluating the New Patterns of the Trilemma's Configurations", 
# Journal of International Money and Finance, Vol. 29, No. 4, p. 615–641.
# 
#   Aizenman, Joshua, Menzie D. Chinn, and Hiro Ito (2013). "The 'Impossible Trinity' Hypothesis 
# in an Era of Global Imbalances: Measurement and Testing," 
# Review of International Economics, 21(3), 447–458(August 2013).


# #****************************/
library(Hmisc)
library(readxl)

tr = read_excel(paste(rawdata, "RAWDATA_TR_2017.xlsx", sep=""))

#Keep all variables
#Rename some variables
names(tr)[names(tr)=="Country Name"] = "country"

# Append country ID not recognize the "?"
#tr$country[tr$country=="S? Tom\xb7and Principe"] = "Sao Tome and Principe"

# Number of unique countries and observations
length(unique(tr$country)) #199
length(tr$country) #11483

#Append country IDs
tr = append_ids(tr, breaks = F)
tr <- tr[-which(tr$countryname_raw == "Czechoslovakia" & tr$year > 1992),]

# Number of countries and observations after cleaning
length(unique(tr$country)) #189
length(tr$country) #10814

#Drop the "cn" variable 
tr$cn <- NULL

#columns not changing? look into this
#rename columns
colnames(tr)[colnames(tr)=="Exchange Rate Stability Index"] <- "ers"
colnames(tr)[colnames(tr)=="Monetary Independence Index"] <- "mi"
colnames(tr)[colnames(tr)=="Financial Openness Index"] <- "ka_open"

#Add variable labels
label(tr$ers) <- "Exchange Rate Stability Index [TR]"
label(tr$mi) <- "Monetary Independence Index [TR]"
label(tr$ka_open) <- "Financial Openness Index [TR]"

#drop IMF-World Bank Country codes since we already have it
cols.dont.want <- "IMF-World Bank Country Code"
tr <- tr[, ! names(tr) %in% cols.dont.want, drop = F]

# Append suffix TR to vairables 
tr = append_suffix(tr,"TR")

save(tr,file=paste(preppeddata,"PREPPED_TR_2017.RDATA",sep=""))

