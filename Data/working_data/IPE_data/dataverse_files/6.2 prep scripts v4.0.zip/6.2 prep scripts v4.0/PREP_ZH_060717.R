# /************************* 
# Drop gwno >= 1000
# run .do prep script first
#
# *************************/

library(foreign)
library(Hmisc)
library(readstata13)



# Read the dta file from prepped data folder
ZHAO <-read.dta13(paste(rawdata,"Zhao_IPP.dta", sep=""))

# Drop gwno>1000
ZHAO <- ZHAO[!ZHAO$gwno >= 1000, ]

# Drop gwno == 730 & year > 1910
ZHAO = ZHAO[-which(ZHAO$gwno == 730 & ZHAO$year > 1947),]


# Add variable labels
label(ZHAO$ippstrength_ZH) = " IPP, 1 for weak 2 for strong [Zhao]"



length(unique(ZHAO$gwno)) #223
range(ZHAO$year) #1800-2015

save(ZHAO,file=paste(preppeddata,"PREPPED_ZHAO_SW_063017.RDATA",sep=""))



