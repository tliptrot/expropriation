######################
# Project: Master IPE Data
# Dataset: Database of Political Institutions
# 2017 Version

# Note: Previous script was a .do file, not an R script
# URL: https://publications.iadb.org/en/publication/database-political-institutions-2017-dpi2017

# Citation: Keefer, Philip. 2010. DPI 2010: Database of Political Institutions: Changes and Variable Definitions. Development Research Group, World Bank.
#Beck, Thorsten, George Clarke, Alberto Groff, Philip Keefer, and Patrick Walsh. "New tools in comparative political economy: The Database of Political Institutions." 15:1, 165-176 (September), World Bank Economic Review. 2001. 
# Cruz, Cesi, Philip Keefer and Carlos Scartascini (2016). "Database of Political Institutions Codebook, 2015 Update (DPI2015)." Inter-American Development Bank. http://www.iadb.org/en/research-and-data/publication-details,3169.html?pub_id=IDB-DB-121

# 2017 Version Citation: Cruz, Cesi, Philip Keefer and Carlos Scartascini (2018)."Database of Political Institutions 2017 (DPI2017)." Inter-American Development Bank. Numbers for Development. https://mydata.iadb.org/Reform-Modernization-of-the-State/Database-of-Political-Institutions-2017/938i-s2bw

######################

library(readstata13)
library(Hmisc)

dpi <- read.dta13(paste(rawdata, "RAWDATA_DPI_2017.dta", sep=""))

# Change column name
colnames(dpi)[1] <- "country"
colnames(dpi)[86] <- "plurality" # there was a typo in the downloaded data, now it's corrected

# drop ifs and gwno
dpi <- dpi[,!(colnames(dpi) %in% c("ifs", "gwno"))]

dpi = append_ids(dpi, breaks = FALSE)
dpi = append_suffix(dpi, "DPI")

#check for duplicates
n_occur <- data.frame(table(dpi$country, dpi$year))
n_occur[n_occur$Freq > 1,]

# how many countries? what time period?
length(unique(dpi$gwno)) # 180
range(dpi$year) # 1975-2017

# label variables
label(dpi$system_DPI) = "Political System [DPI]"
label(dpi$yrsoffc_DPI) = "Chief Executive Years in Office [DPI]"
label(dpi$finittrm_DPI) = "Finite Term in Office [DPI]"
label(dpi$yrcurnt_DPI) = "Years Left in Current Term [DPI]"
label(dpi$multpl_DPI) = "Can Chief Executive Serve Multiple Terms [DPI]"
label(dpi$military_DPI) = "Is Chief Executive a Military Officer? [DPI]"
label(dpi$defmin_DPI) = "Is Defense Minister a Military Officer? [DPI]"
label(dpi$percent1_DPI) = "President Percentage of Votes, first round [DPI]"
label(dpi$percentl_DPI) = "President Percentage of Votes, last round [DPI]"
label(dpi$prtyin_DPI) = "Party of Chief Executive Length of Time in Office [DPI]"
label(dpi$execme_DPI) = "Name of Executive Party [DPI]"
label(dpi$execrlc_DPI) = "Chief Executive Party Orientation [DPI]"
label(dpi$execnat_DPI) = "Chief Executive Party: Nationalist [DPI]"
label(dpi$execrurl_DPI) = "Chief Executive Party: Rural [DPI]"
label(dpi$execreg_DPI) = "Chief Executive Party: Regional [DPI]"
label(dpi$execrel_DPI) = "Chief Executive Party: Religious [DPI]"
label(dpi$execage_DPI) = "Age of Chief Executive Party [DPI]"
label(dpi$allhouse_DPI) = "Does Party of Executive Control All Houses? [DPI]"
label(dpi$nonchief_DPI) = "Party affiliation of Non-Chief Exec in Systems with both President and PM [DPI]"
label(dpi$totalseats_DPI) = "Total Seats in Legislature [DPI]"
label(dpi$gov1me_DPI) = "Name of Largest Government Party [DPI]"
label(dpi$gov1seat_DPI) = "Number of Seats of Largest Government Party [DPI]"
label(dpi$gov1vote_DPI) = "Vote Share of Largest Government Party [DPI]"
label(dpi$gov1rlc_DPI) = "Largest Government Party Orientation [DPI]"
label(dpi$gov1nat_DPI) = "Largest Government Party: Nationalist [DPI]"
label(dpi$gov1rurl_DPI) = "Largest Government Party: Rural [DPI]"
label(dpi$gov1reg_DPI) = "Largest Government Party: Regional [DPI]"
label(dpi$gov1rel_DPI) = "Largest Government Party: Religious [DPI]"
label(dpi$gov1age_DPI) = "Age of Largest Government Party [DPI]"
label(dpi$gov2me_DPI) = "Name of 2nd Largest Government Party [DPI]"
label(dpi$gov2seat_DPI) = "Number of Seats of 2nd Largest Government Party [DPI]"
label(dpi$gov2vote_DPI) = "Vote Share of 2nd Largest Government Party [DPI]"
label(dpi$gov2rlc_DPI) = "2nd Largest Government Party Orientation [DPI]"
label(dpi$gov2nat_DPI) = "2nd Largest Government Party: Nationalist [DPI]"
label(dpi$gov2rurl_DPI) = "2nd Largest Government Party: Rural [DPI]"
label(dpi$gov2reg_DPI) = "2nd Largest Government Party: Regional [DPI]"
label(dpi$gov2rel_DPI) = "2nd Largest Government Party: Religious [DPI]"
label(dpi$gov2age_DPI) = "Age of 2nd Largest Government Party [DPI]"
label(dpi$gov3me_DPI) = "Name of 3rd Largest Government Party [DPI]"
label(dpi$gov3seat_DPI) = "Number of Seats of 3rd Largest Government Party [DPI]"
label(dpi$gov3vote_DPI) = "Vote Share of 3rd Largest Government Party [DPI]"
label(dpi$gov3rlc_DPI) = "3rd Largest Government Party Orientation [DPI]"
label(dpi$gov3nat_DPI) = "3rd Largest Government Party: Nationalist [DPI]"
label(dpi$gov3rurl_DPI) = "3rd Largest Government Party: Rural [DPI]"
label(dpi$gov3reg_DPI) = "3rd Largest Government Party: Regional [DPI]"
label(dpi$gov3rel_DPI) = "3rd Largest Government Party: Religious [DPI]"
label(dpi$gov3age_DPI) = "Age of 3rd Largest Government Party [DPI]"
label(dpi$govoth_DPI) = "Number of Other Government Parties [DPI]"
label(dpi$govothst_DPI) = "Number of Seats of Other Government Parties [DPI]"
label(dpi$govothvt_DPI) = "Vote Share of Other Government Parties [DPI]"
label(dpi$opp1me_DPI) = "Name of Largest Opposition Party [DPI]"
label(dpi$opp1seat_DPI) = "Number of Seats of Largest Opposition Party [DPI]"
label(dpi$opp1vote_DPI) = "Vote Share of Largest Opposition Party [DPI]"
label(dpi$opp1rlc_DPI) = "Largest Opposition Party Orientation [DPI]"
label(dpi$opp1nat_DPI) = "Largest Opposition Party: Nationalist [DPI]"
label(dpi$opp1rurl_DPI) = "Largest Opposition Party: Rural [DPI]"
label(dpi$opp1reg_DPI) = "Largest Opposition Party: Regional [DPI]"
label(dpi$opp1rel_DPI) = "Largest Opposition Party: Religious [DPI]"
label(dpi$opp1age_DPI) = "Age of Largest Opposition Party [DPI]"
label(dpi$opp2me_DPI) = "Name of 2nd Largest Opposition Party [DPI]"
label(dpi$opp2seat_DPI) = "Number of Seats of 2nd Largest Opposition Party [DPI]"
label(dpi$opp2vote_DPI) = "Vote Share of 2nd Largest Opposition Party [DPI]"
label(dpi$opp3me_DPI) = "Name of 3rd Largest Opposition Party [DPI]"
label(dpi$opp3seat_DPI) = "Number of Seats of 3rd Largest Opposition Party [DPI]"
label(dpi$opp3vote_DPI) = "Vote Share of 3rd Largest Opposition Party [DPI]"
label(dpi$oppoth_DPI) = "Number of Other Opposition Parties [DPI]"
label(dpi$oppothst_DPI) = "Number of Seats of Other Opposition Parties [DPI]"
label(dpi$oppothvt_DPI) = "Number of Votes of Other Opposition Parties [DPI]"
label(dpi$ulprty_DPI) = "Number of Non-Aligned Parties [DPI]"
label(dpi$numul_DPI) = "Number of Seats of Non-Aligned Parties [DPI]"
label(dpi$ulvote_DPI) = "Vote Share of Non-Aligned Parties [DPI]"
label(dpi$oppmajh_DPI) = "Does One Opposition Party have a Majority in the House? [DPI]"
label(dpi$oppmajs_DPI) = "Does One Opposition Party have a Majority in the Senate? [DPI]"
label(dpi$dateleg_DPI) = "Month Legislative Elections Held [DPI]"
label(dpi$dateexec_DPI) = "Month Presidential Elections Held [DPI]"
label(dpi$legelec_DPI) = "Legislative Election Held [DPI]"
label(dpi$exelec_DPI) = "Presidential Election Held [DPI]"
label(dpi$liec_DPI) = "Legislative Electoral Competitiveness [DPI]"
label(dpi$eiec_DPI) = "Executive Electoral Competitiveness [DPI]"
label(dpi$mdmh_DPI) = "Mean District Magnitude House [DPI]"
label(dpi$mdms_DPI) = "Mean District Magnitude Senate [DPI]"
label(dpi$ssh_DPI) = "Number of Seats in Senate/Total Seats in Both Houses [DPI]"
label(dpi$plurality_DPI) = "Plurality [DPI]"
label(dpi$pr_DPI) = "Proportional Representation [DPI]"
label(dpi$housesys_DPI) = "Electoral Rule House [DPI]"
label(dpi$sensys_DPI) = "Electoral Rule Senate [DPI]"
label(dpi$thresh_DPI) = "Vote Threshold [DPI]"
label(dpi$dhondt_DPI) = "D’Hondt System [DPI]"
label(dpi$cl_DPI) = "Closed List [DPI]"
label(dpi$select_DPI) = "Candidate Selection [DPI]"
label(dpi$fraud_DPI) = "Vote Fraud [DPI]"
label(dpi$auton_DPI) = "Autonomous Regions [DPI]"
label(dpi$muni_DPI) = "Municipal Government [DPI]"
label(dpi$state_DPI) = "State Government [DPI]"
label(dpi$author_DPI) = "State Government Authority over Taxing, Spending, or Legislating [DPI]"
label(dpi$stconst_DPI) = "Are the Constituencies of the Senators the States/Provinces? [DPI]"
label(dpi$numgov_DPI) = "Number of Government Seats [DPI]"
label(dpi$numvote_DPI) = "Vote Share of Government Parties [DPI]"
label(dpi$numopp_DPI) = "Number of Opposition Seats [DPI]"
label(dpi$oppvote_DPI) = "Vote Share of Opposition Parties [DPI]"
label(dpi$maj_DPI) = "Margin of Majority [DPI]"
label(dpi$partyage_DPI) = "Average Age of Parties [DPI]"
label(dpi$herfgov_DPI) = "Herfindahl Index of Government Parties [DPI]"
label(dpi$herfopp_DPI) = "Herfindahl Index of Opposition Parties [DPI]"
label(dpi$herftot_DPI) = "Herfindahl Index Total [DPI]"
label(dpi$frac_DPI) = "Fractionalization Index [DPI]"
label(dpi$oppfrac_DPI) = "Opposition Fractionalization Index [DPI]"
label(dpi$govfrac_DPI) = "Government Fractionalization Index [DPI]"
label(dpi$tensys_strict_DPI) = "tensys_strict [DPI]"
label(dpi$tensys_DPI) = "System Tenure [DPI]"
label(dpi$checks_lax_DPI) = "checks_lax [DPI]"
label(dpi$checks_DPI) = "Checks and Balances [DPI]"
label(dpi$stabs_strict_DPI) = "Stability (Threshold: LIEC = 6) [DPI]"
label(dpi$stabs_DPI) = "Stability [DPI]"
label(dpi$stabns_strict_DPI) = "Stability, single chamber (Threshold: LIEC = 6) [DPI]"
label(dpi$stabns_DPI) = "Stability, single chamber [DPI]"
label(dpi$tenlong_strict_DPI) = "Longest Tenure of a Veto Player (Threshold: LIEC = 6) [DPI]"
label(dpi$tenlong_DPI) = "Longest Tenure of a Veto Player [DPI]"
label(dpi$tenshort_strict_DPI) = "Shortest Tenure of a Veto Player (Threshold: LIEC = 6) [DPI]"
label(dpi$tenshort_DPI) = "Shortest Tenure of a Veto Player [DPI]"
label(dpi$polariz_DPI) = "Polarization [DPI]"

#save
save(dpi,file=paste(preppeddata,"PREPPED_DPI_2017_AL.RDATA",sep=""))