# /***************************
# Boix, Miller, and Rosato Democracy Data [BX]
# V 3.0
# 
# URL: https://sites.google.com/site/mkmtwo/data
# 
# Countries: 210
# Time Period: 1800-2015
#
# Miriam Barnum
# ****************************/

#import
bx <- read.csv(paste(rawdata, "RAWDATA_BX_2015.csv", sep=""))

bx <- bx[c("country","year","democracy","democracy_trans","democracy_breakdowns","democracy_duration",
           "democracy_omitteddata","democracy_femalesuffrage")]

# append IDs
#add_name("PAKISTAN  (INCL. BANGLAD.)", "pakistan")
#add_name("ETHIOPIA  (INCL. ERIT)", "ethiopia")
#add_name("MICRONESIA, FED.", "federated states of micronesia")
bx <-  append_ids(bx, breaks = FALSE)

# check for duplicates
n_occur <- data.frame(table(bx$country, bx$year))
n_occur[n_occur$Freq>1,]

bx <- bx[!(bx$countryname_raw == "GERMANY" & bx$year == 1990),]
bx <- bx[!(bx$countryname_raw == "YUGOSLAVIA, FED. REP." & bx$year == 1991),]
bx <- bx[!(bx$countryname_raw == "SERBIA" & bx$year == 2006),]

# how many countries? what time period?
length(unique(bx$gwno)) #210
range(bx$year) #1800-2015

# label variables
library(Hmisc)
label(bx$democracy) <- "Democracy [Boix]"
#label(bx$sovereign) <- "Sovereign Dummy [Boix]" #this variable no longer included in v 3.0
label(bx$democracy_trans) <- "Democratic Transition [Boix]"
label(bx$democracy_breakdowns) <- "Democratic Breakdowns [Boix]"
label(bx$democracy_duration) <- "Democratic Duration [Boix]"
label(bx$democracy_omitteddata) <- "Democracy Omitted Data [Boix]"

#suffix
bx <- append_suffix(bx, "BX")

# Save
save(bx, file = paste(preppeddata,"Prepped_BX_2019_MB.RDATA", sep=""))

