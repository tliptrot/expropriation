###############################
# Economic Freedom of the World from the Fraser Institude [EF]
# Accessed: February 21, 2019
# Year Range: 1970-2016
# Prepped By: Alicia Kuang
# Suffix: EF
#
# Data Source: https://www.fraserinstitute.org/economic-freedom/dataset.
#
# Citation: Gwartney, James, Robert A. Lawson, Joshua C. Hall, and Fred McMahon. 
# "Economic Freedom of the World." Fraser Institute. https://www.fraserinstitute.org/economic-freedom/dataset.
#
# Variables: top_margintax_EF, top_margin_payrolltaxEF, propright_EF, impartcourts_EF, bixcrimecost_EF, policerely_EF
# Labels: Top marginal income tax rate [EF], Top marginal income and payroll tax rate [EF], Protection of property rights [EF], 
# Impartial Courts [EF], Business cost of crime [EF], Reliability of police [EF]
#
###############################

library(Hmisc)
library(readxl)

# importing dataset
ef <- read_xlsx(paste(rawdata,"RAWDATA_EF_2016.xlsx", sep=""), col_names = FALSE)

# getting rid of blank rows
ef = ef[c(-1),]
ef = ef[c(-1),]
ef = ef[c(-1),]

# adding column headers
colnames(ef) <- ef[1,]

# getting rid of headers, as well as end has a lot of blank rows
ef = ef[c(-1),]

#Keep only the variables we need
ef = ef[, c("Year", 
            "Countries", 
            "Top marginal income tax rate", 
            "Top marginal income and payroll tax rate", 
            "Protection of property rights", 
            "Impartial courts", 
            "Business costs of crime", 
            "Reliability of police")]

#Rename some variables
names(ef)[names(ef)=="Countries"] = "countryname"
names(ef)[names(ef)=="Top marginal income tax rate"] = "top_margintax"
names(ef)[names(ef)=="Top marginal income and payroll tax rate"] = "top_margin_payrolltax"
names(ef)[names(ef)=="Protection of property rights"] = "propright"
names(ef)[names(ef)=="Impartial courts"] = "impartcourts"
names(ef)[names(ef)=="Business costs of crime"] = "bizcrimecost"
names(ef)[names(ef)=="Reliability of police"] = "policerely"

#Append country IDs
ef = append_ids(ef)
ef = append_suffix(ef,"EF")

#Change data types
ef$year = as.numeric(ef$year)
ef$top_margintax_EF = as.numeric(ef$top_margintax_EF)
ef$top_margin_payrolltax_EF = as.numeric(ef$top_margin_payrolltax_EF)
ef$propright_EF = as.numeric(ef$propright_EF)
ef$impartcourts_EF = as.numeric(ef$impartcourts_EF)
ef$bizcrimecost_EF = as.numeric(ef$bizcrimecost_EF)
ef$policerely_EF = as.numeric(ef$policerely_EF)

#Add variable labels
label(ef$top_margintax_EF) = "Top marginal income tax rate [EF]"
label(ef$top_margin_payrolltax_EF) = "Top marginal income and payroll tax rate [EF]"
label(ef$propright_EF) = "Protection of property rights [EF]"
label(ef$impartcourts_EF) = "Impartial courts [EF]"
label(ef$bizcrimecost_EF) = "Business cost of crime [EF]"
label(ef$policerely_EF) = "Reliability of police [EF]"

save(ef,file=paste(preppeddata,"PREPPED_EF_AK_2016.RDATA",sep=""))
