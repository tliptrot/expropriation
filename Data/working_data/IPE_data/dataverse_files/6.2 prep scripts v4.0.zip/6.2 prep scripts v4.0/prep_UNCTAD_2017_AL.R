###############################
#   UNCTAD FDI Data
# Accessed: February 13, 2019
# URL: http://unctadstat.unctad.org/
#   
#   Citation:
#   United Nations Conference on Trade and Development. 2016. Foreign direct investment: Inward and outward flowas and stock, annual, 1980-2017. http://unctadstat.unctad.org/. Accessed on February 13, 2019.
#   Created by: JT
#   Edited by: Anna Lipscomb, Feb 2019
###############################
library(Hmisc)
library(readxl)
library(dplyr)
library(tidyr)

#############
#Prep Flows
#############
flows = read_excel(path = (paste(rawdata, "RAWDATA_UNCTAD_flow_2017.xlsx", sep="")))
#flows <- read.csv(paste(rawdata,"RAWDATA_UNCTAD_flow_2017.csv",sep=""),header=FALSE)
#Drop the file header
flows = flows[-c(1:6),]
names(flows)[1] = "country"

#Make the variable names the corresponding years
yr = 1970
for (i in 2:ncol(flows)) {
  names(flows)[i] = as.character(yr)
  paste("year",yr,sep="")
  yr = yr+1
}

#Reshape the data
flows <- flows[ , c(1:49)]
flows <- gather(flows, "year", "fdiflows", 2:49)

# These ones didn't work
#flows = melt(flows,id="country",variable_name="Year")
#names(flows)[names(flows)=="value"] = "fdiflows"
#flows <- reshape(as.data.frame(flows), direction = "long", varying = yearsToKeep, v.names = "fdiflows", idvar=c("country"), timevar="year", times=1970:2017)

#Fix missing data
flows$fdiflows <- as.numeric(flows$fdiflows)

#############
#Prep Stocks
############
stocks = read_excel(path = (paste(rawdata, "RAWDATA_UNCTAD_stock_2017.xlsx", sep="")))
#Drop the file header
stocks = stocks[-c(1:6),]
names(stocks)[1] = "country"

#Make the variable names the corresponding years
yr = 1970
for (i in 2:ncol(stocks)) {
  names(stocks)[i] = as.character(yr)
  #paste("y",yr,sep="")
  yr = yr+1
}

#Reshape the data
stocks <- stocks[ , c(1:49)]
stocks <- gather(stocks, "year", "fdistocks", 2:49)

#Reshape the data
#stocks = melt(stocks,id="country",variable_name="year")
#names(stocks)[names(stocks)=="value"] = "fdistocks"

#Fix missing data
stocks$fdistocks <- as.numeric(stocks$fdistocks)

###########
#Merge
###########
fdi = merge(flows,stocks,by=c("country","year"))
bf = nrow(fdi)
# fdi$country = as.character(fdi$country)
# fdi$country[fdi$country=="Côte d'Ivoire"] = "Cote d'Ivoire"
# fdi$country[fdi$country=="Curaçao"] = "Curacao"
fdi$country[fdi$country=="Switzerland, Liechtenstein" ] = "Switzerland" 
# fdi$country = trimws(fdi$country,which="both")
# fdi$year = as.character(fdi$year)
fdi$year = as.numeric(fdi$year)

fdi = append_ids(fdi)

#How many observations are dropped?
bf-nrow(fdi)
fdi = append_suffix(fdi,"UNCTAD")

###########
#Check duplicates
###########
sum(duplicated(fdi[,c("gwno","year")]))
View(fdi[duplicated(fdi[,c("gwno","year")]),])

#Handle duplicates
#Drop data for Panama, Canal Zone to preference the Panama observations (thes are the ones
# that contain data. All observations for the canal zone are missing)
# Panama before 1980 data are missing
# Panama, excluding Canal Zone after 1980 are mssing
fdi$drops = 0
#fdi$drops[fdi$countryname_raw_UNCTAD=="Panama, Canal Zone"] = 1
fdi$drops[fdi$countryname_raw_UNCTAD=="Panama" & fdi$year < 1981] = 1
fdi$drops[fdi$countryname_raw_UNCTAD=="Panama, excluding Canal Zone" & fdi$year > 1980] = 1

#Germany is united after 1989
fdi$drops[fdi$gwno==260 & fdi$countryname_raw_UNCTAD=="Germany" & fdi$year < 1990] = 1
fdi$drops[fdi$gwno==260 & fdi$countryname_raw_UNCTAD=="Germany, Federal Republic of" & fdi$year>1989] = 1

#Only Serbia and Montenegro has data for gwno==345
fdi$drops[fdi$countryname_raw_UNCTAD != "Serbia and Montenegro" & fdi$gwno==345] = 1
###############################
#Only Serbia has data for gwno == 340, except year 2007
fdi$drops[fdi$countryname_raw_UNCTAD != "Serbia" & fdi$gwno==340] = 1
fdi$drops[fdi$countryname_raw_UNCTAD == "Serbia" & fdi$gwno==340 & fdi$year == 2007] = 1
fdi$drops[fdi$countryname_raw_UNCTAD == "Serbia and Montenegro" & fdi$gwno==340 & fdi$year == 2007] = 0

################################
#There are observations for Russia and the Soviet Union -- Data as of Feb 2019 don't have both
#fdi$drops[fdi$countryname_raw_UNCTAD == "Russian Federation" & fdi$year<1992] = 1
#fdi$drops[fdi$countryname_raw_UNCTAD == "Union of Soviet Socialist Republics" & fdi$year>1991] = 1
#Handle Ethiopia pre fall of the Empire
fdi$drops[fdi$gwno==530 & fdi$countryname_raw_UNCTAD != "Ethiopia (...1991)" & fdi$year < 1992] = 1
#Handle Sudan pre 2012
fdi$drops[fdi$gwno==625 & fdi$year < 2012 & fdi$countryname_raw_UNCTAD != "Sudan (...2011)"] = 1
fdi$drops[fdi$gwno==625 & fdi$year > 2011 & fdi$countryname_raw_UNCTAD == "Sudan (...2011)"] = 1
#Only observations for Yemen have data for GWNO==678
fdi$drops[fdi$gwno==678 & fdi$countryname_raw_UNCTAD != "Yemen"] = 1 ########this line of code doesn't work... go back to this!#######
#Handle Indonesia pre 2003
fdi$drops[fdi$gwno==850 & fdi$countryname_raw_UNCTAD=="Indonesia" & fdi$year < 2003] = 1
fdi$drops[fdi$gwno==850 & fdi$countryname_raw_UNCTAD=="Indonesia (...2002)" & fdi$year>2002]=1

#Handle Czechoslovakia #####make sure to come back to this and double check!
# Drop Czech Republic data gwno = 315
# Drop Czechoslovakia data gwno = 316
fdi$drops[fdi$gwno==315 & fdi$countryname_raw_UNCTAD=="Czechia"] = 1 
fdi$drops[fdi$gwno==316 & fdi$countryname_raw_UNCTAD=="Czechoslovakia"]=1

fdi = fdi[fdi$drops==0,]

#Double check to make sure there are no duplicates left
sum(duplicated(fdi[,c("gwno","year")]))

#get rid of drops column
cols.dont.want <- "drops"
fdi <- fdi[, ! names(fdi) %in% cols.dont.want, drop = F]

#change values of fdiflows and fdistocks from character to numeric
fdi$fdiflows_UNCTAD = as.numeric(fdi$fdiflows_UNCTAD)
fdi$fdistocks_UNCTAD = as.numeric(fdi$fdistocks_UNCTAD)

################
#Label Variables
################
label(fdi$fdiflows_UNCTAD) = "FDI Flows (Inward) USD Millions [UNCTAD]"
label(fdi$fdistocks_UNCTAD) = "FDI Stocks (Inward) USD Millions [UNCTAD]"

###########
#Save Data
###########
save(fdi,file=paste(preppeddata,"PREPPED_UNCTAD_2017_AL.RDATA"))

