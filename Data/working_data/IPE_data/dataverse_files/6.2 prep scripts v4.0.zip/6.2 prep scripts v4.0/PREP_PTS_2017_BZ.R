###############################
# Political Terror Scale [PTS]
# Version: September 2016
# Accessed: April 28, 2017
# Year Range: 1976-2015
# Prepped By: Rohit Madan
# Suffix: PTS
# Last update: 04/28/2017
#
# Edited by: Anna Lipscomb (September 12, 2018)
# Year Range 1976-2016
# Edited by: Baiyu Zhu (March 26, 2019)
# Year Range 1976-2017
#
# Data: http://www.politicalterrorscale.org/Data/Download.html
# 
#
# Variables: politterr_a_PTS, politterr_s_PTS, politterr_HRW_PTS
#
# Notes: Israel in Occupied Territories and Israel in pre-1976 borders is dropped
#        Just 'Israel' is retained
# 
###############################

library(readxl)

#Read raw data 
pts <- read_excel(path = (paste(rawdata, "RAWDATA_PTS_2017.xlsx", sep="")), skip = 0)

#Look into variable country_old
pts$Country <- as.character(pts$Country)
pts$Country_OLD <- as.character(pts$Country_OLD)
which(pts$Country != pts$Country_OLD)

#Keep needed variables
varsToKeep <- c("Country", "Year", "PTS_A", "PTS_H", "PTS_S")
pts <- pts[varsToKeep]

#Rename
names(pts)[names(pts)=="PTS_A"] <- "politterr_a"
names(pts)[names(pts)=="PTS_H"] <- "politterr_HRW"
names(pts)[names(pts)=="PTS_S"] <- "politterr_s"

#Drop Israel in Occupied Territories and Israel in pre-1976 borders, just 'Israel' is retained
pts = pts[-which(pts$Country == "Israel in Occupied Territories"),]
pts = pts[-which(pts$Country == "Israel in pre-1967 borders"),]

# Check Duplicates
n_occur <- data.frame(table(pts$Country, pts$Year))
print(n_occur[n_occur$Freq > 1,])

# --- Drop the duplicates
# Yemen Duplicates
pts = pts[-which(pts$Country == "Yemen" & pts$Year <= 1989),]
pts = pts[-which(pts$Country == "Yemen Arab Republic" & pts$Year > 1989),]
pts = pts[-which(pts$Country == "Yemen People's Republic"),] 

# Serbia and Yugoslavia Duplicates
pts = pts[-which(pts$Country == "Serbia" & pts$Year < 2007),] 
pts = pts[-which(pts$Country == "Yugoslavia, Socialist Federal Republic of" & pts$Year >= 1992),] 
pts = pts[-which(pts$Country == "Yugoslavia, Federal Republic of" & pts$Year < 1992),] 
pts = pts[-which(pts$Country == "Yugoslavia, Federal Republic of" & pts$Year > 2006),] 

# Germany Duplicates
pts = pts[-which(pts$Country == "Germany" & pts$Year < 1990),]
pts = pts[-which(pts$Country == "German Federal Republic" & pts$Year >= 1990),] 
pts = pts[-which(pts$Country == "German Democratic Republic" & pts$Year >= 1990),] 

# Russia Duplicates
pts = pts[-which(pts$Country == "Russian Federation" & pts$Year <= 1991),]
pts = pts[-which(pts$Country == "Soviet Union" & pts$Year > 1991),]

# Czech Republic Duplicates
pts = pts[-which(pts$Country == "Czech Republic" & pts$Year < 1992),]
pts = pts[-which(pts$Country == "Czechoslovakia" & pts$Year > 1991),]

#Append ids
pts <- append_ids(pts, breaks = F)

## Append Suffix
pts <- append_suffix(pts, "PTS")

#Label
library(Hmisc)
label(pts$politterr_a_PTS) <- "Political Terror Scale based on Amnesty International [PTS]" 
label(pts$politterr_HRW_PTS) <- "Political Terror Scale based on HRW [PTS]" 
label(pts$politterr_s_PTS) <- "Political Terror Scale based on the US State Department [PTS]" 

#save prepped data
save(pts,file=paste(preppeddata,"PREPPED_PTS_BZ_2017.RDATA",sep=""))

