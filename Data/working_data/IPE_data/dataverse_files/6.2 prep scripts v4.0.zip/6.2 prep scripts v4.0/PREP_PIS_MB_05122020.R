# /************************* 
# Source: Organization for Economic Cooperation and Development. Program for International Student Assesment. 
# Accessed: May 12, 2020
# URL: http://pisadataexplorer.oecd.org/ide/idepisa/report.aspx
# 
# Time: 2000, 2003, 2006, 2009, 2012, 2015, 2018
# Coded by: Grace Xu
# Updated MB, May 2020
# Suffix: PIS
# Variables: math_avg, reading_avg, science_avg
# *************************/

library(readxl)
library(tidyr)
library(dplyr)
library(Hmisc)

reading <- read_xls(paste(rawdata,"RAWDATA_PIS_2018.xls", sep = ""), sheet = 1, col_names=FALSE)
math <- read_xls(paste(rawdata,"RAWDATA_PIS_2018.xls", sep = ""), sheet = 1, col_names=FALSE)
science <- read_xls(paste(rawdata,"RAWDATA_PIS_2018.xls", sep = ""), sheet = 1, col_names=FALSE)

# trim junk, add names, fill in year values
reading <- reading[-c(1:10), 1:3]
names(reading) <- c("year","country","reading_avg")
reading <- fill(reading, year)

math <- math[-c(1:10), 1:3]
names(math) <- c("year","country","math_avg")
math <- fill(math, year)

science <- science[-c(1:10), 1:3]
names(science) <- c("year","country","science_avg")
science <- fill(science, year)

#combine the 3 datasets; numeric var types
pis <- full_join(math, science) %>%
  full_join(reading) %>%
  mutate_at(vars(-country), as.numeric)

# labels
label(pis$math_avg) = "Average mathematics scores [PIS]"
label(pis$reading_avg) = "Average reading scores [PIS]"
label(pis$science_avg) = "Average science scores [PIS]"

# Change country name Korea into South Korea
pis$country[pis$country=="Korea"] = "South Korea"
pis$country <- gsub("\\d", "", pis$country) 
# add_name("B-S-J-Z (China)", "China")
# add_name("B-S-J-G (China)", "China")
# add_name("Baku (Azerbaijan)", "Azerbaijan")

# delete duplicate blank rows for some countries
pis <- pis %>% filter_at(vars(ends_with("_avg")), any_vars(!is.na(.))) 

pis = append_ids(pis, breaks = F)
pis = append_suffix(pis, "PIS")

#save
save(pis, file = paste(preppeddata, "PREPPED_PIS_MB_12052020.RDATA", sep=""))
