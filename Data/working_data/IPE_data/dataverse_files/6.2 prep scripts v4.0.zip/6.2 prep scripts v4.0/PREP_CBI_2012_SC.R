###############################
# Central Bank Intelligence data, Garriga
# Accessed 04/13/2018
# Year Range: 1970-2012
# Suffix: CBI
# Dataset last update: October 4th, 2016
#
# Data: https://dataverse.harvard.edu/dataset.xhtml?persistentId=doi:10.7910/DVN/I2BUGZ
# "CBI Dataset Garriga"
#
# Citation: (retrieved from https://sites.google.com/site/carogarriga/cbi-data-1)
# Garriga, Ana Carolina.  2016.  Central Bank Independence in the World: A New Dataset. International Interactions 42 (5):849-868  
# doi: 10.1080/03050629.2016.1188813
#
# Variables: creation, reform, direction, increase, decrease, regional, lvau_garriga: CBI Index (Unweighted), lvaw_garriga: CBI Index (Weighted)
#
# Prepped by Stephen Campbell, 04/2018
################################

library(readxl)
library(Hmisc)

library(dplyr)
library(tidyr)
library(stringr)

#read in data
CBI <- load(paste(rawdata, "RAWDATA_CBI_2012.RData",sep=""))

#put data from global environment into variable, remove global environment variable
CBI <- get(CBI)
rm(x)

#remove unused variables
CBI <- CBI[,c("cname","year","creation", "reform", "direction", "increase", "decrease", "regional", "lvau_garriga", "lvaw_garriga")]

#rename variables
names(CBI)[names(CBI)=="cname"] = "Country"
names(CBI)[names(CBI)=="year"] = "Year"

#convert data to numerics, from atomic vector to num
CBI$Year = as.numeric(CBI$Year)
CBI$creation = as.numeric(CBI$creation)
CBI$reform = as.numeric(CBI$reform)
CBI$direction = as.numeric(CBI$direction)
CBI$increase = as.numeric(CBI$increase)
CBI$decrease = as.numeric(CBI$decrease)
CBI$regional = as.numeric(CBI$regional)
CBI$lvau_garriga = as.numeric(CBI$lvau_garriga)
CBI$lvaw_garriga = as.numeric(CBI$lvaw_garriga)

#change labels
label(CBI$lvau_garriga) <- "CBI Index (Unweighted) [CBI]"
label(CBI$lvaw_garriga) <- "CBI Index (Weighted) [CBI]"

#appending gwnos
CBI = append_ids(CBI, breaks = F)
CBI = append_suffix(CBI, "CBI")

range(CBI$year) # 1970 2012
length(unique(CBI$gwno)) # 184

#save data, finished 04-27-2018
save(CBI,file=paste(preppeddata,"prepped_CBI_SC_040272018.RDATA",sep=""))
