# /*************************
# Polity IV [P4]
#
# Source: Marshall, Monty G., Ted Robert Gurr, and Keith Jaggers. 2017. "Polity IV Project: Political Regime Characteristics and Transitions, 1800-2016." 
# Data source URL: http://www.systemicpeace.org/inscrdata.html 
# Codebook URL: http://www.systemicpeace.org/inscr/p4manualv2015.pdf
# Time: 1800-2017
# Suffix: P4
# By:AJ
# Updated by Anna Lipscomb, Feb 2019
#
# Variables:
# fragment
# democ
# autoc
# polity
# polity2
# durable
# xconst
# parreg
# parcomp
# polcomp
# change
# sf
# regtrans

# /*************************

library(Hmisc)
library(readxl)
library(dplyr)

# --- importing dataset
p4 = read_excel(paste(rawdata,"RAWDATA_P4_2017.xlsx", sep=""), 1, col_names = TRUE)

# --- keep only the variables we need
p4 = p4[, c("country", 
            "year", 
            "fragment",
            "democ",
            "autoc",
            "polity",
            "polity2",
            "durable",
            "xconst",
            "parreg",
            "parcomp",
            "polcomp",
            "change",
            "sf",
            "regtrans")]

# --- Order rows by country-year
p4 = p4[order(p4$country, p4$year),]

# --- Checking for duplicates
n_occur <- data.frame(table(p4$country, p4$year))
n_occur[n_occur$Freq > 1,]

# --- There are 2 duplicates: Yugoslavia-1991 and Ethiopia-1993. 
# Drop the Yugoslavia observation that represents the FRY. It doesn't become independent until 1992.
p4 = p4[-which(p4$country == "Yugoslavia" & p4$year == 1991 & p4$durable == 0),]
# Drop the Ethiopia observation that represents "state demise." 1993 was a transition year.
p4 = p4[-which(p4$country == "Ethiopia" & p4$year == 1993 & p4$regtrans == 98),]

# --- Append country IDs
p4 = append_ids(p4, breaks = F)
p4 = append_suffix(p4,"P4")

# --- Checking for duplicates
n_occur <- data.frame(table(p4$gwno, p4$year))
n_occur[n_occur$Freq > 1,]

# --- There are 6 duplicates: 
# Italy/Sardinia in 1861
# Russia/Soviet Union in 1922 
# vietnam North / Vietnam in 1976
# Germany West / Germany in 1990
# North Yemen / Yemen in 1990
# Serbia & Montenegro / Serbia in 2006
# Sudan / Sudan-North in 2011
# --- Drop the duplicates

p4 = p4[-which(p4$countryname_raw_P4 == "Sardinia" & p4$year == 1861),]
p4 = p4[-which(p4$countryname_raw_P4 == "Russia" & p4$year == 1922),]
p4 = p4[-which(p4$countryname_raw_P4 == "Vietnam" & p4$year == 1976),]
p4 = p4[-which(p4$countryname_raw_P4 == "Germany West" & p4$year == 1990),]
p4 = p4[-which(p4$countryname_raw_P4 == "Yemen" & p4$year == 1990),]
p4 = p4[-which(p4$countryname_raw_P4 == "Serbia" & p4$year == 2006),]
p4 = p4[-which(p4$countryname_raw_P4 == "Sudan-North" & p4$year == 2011),]

# --- Add variable labels
label(p4$fragment_P4) = "Polity fragmentation [P4]"
label(p4$democ_P4) = "Institutionalized democracy [P4]"
label(p4$autoc_P4) = "Institutionalized autocracy [P4]"
label(p4$polity_P4) = "Combined polity score [P4]"
label(p4$polity2_P4) = "Revised combined polity score [P4]"
label(p4$durable_P4) = "Regime durability [P4]"
label(p4$xconst_P4) = "Executive constraints [P4]"
label(p4$parreg_P4) = "Regulation of participation [P4]"
label(p4$parcomp_P4) = "Competitiveness of participation [P4]"
label(p4$polcomp_P4) = "Political competition [P4]"
label(p4$change_P4) = "Total change in polity value [P4]"
label(p4$sf_P4) = "State failure [P4]"
label(p4$regtrans_P4) = "Regime transition [P4]"

length(unique(p4$gwno)) # 186
range(p4$year) # 1800-2017

# --- Saving
save(p4,file=paste(preppeddata,"PREPPED_P4_2017_AL.RDATA",sep=""))