# /************************* 
# Data: KOF Index of Globalization [KOF]
# Data source url: http://globalization.kof.ethz.ch
# Codebook url: http://globalization.kof.ethz.ch/media/filer_public/2017/04/19/press_release_2017_en.pdf

# Time:1970 - 2014
# By: Sherry
# Updated: MB, 2020
# Suffix: KOF
# 
# Citation:

# Dreher, Axel (2006): Does Globalization Affect Growth? Evidence from a new Index of Globalization, Applied Economics 38, 10: 1091-1110.
# 
# Updated in:
#   Dreher, Axel, Noel Gaston and Pim Martens (2008), Measuring Globalisation – Gauging its Consequences (New York: Springer).

# *************************/


library(foreign)
library(Hmisc)
library(readxl)

# Read the excel file that contains year 2012- 2014
KOF <-read_excel(paste(rawdata,"RAWDATA_KOF_2019.xlsx", sep=""), na = "NA")

# Drop Code Column
KOF$code <- NULL

# Rename the column names
names(KOF)[names(KOF)=="KOFEcGI"] = "eco_glob"
names(KOF)[names(KOF)=="KOFEcGIdf"] = "act_flow"
names(KOF)[names(KOF)=="KOFEcGIdj"] = "restr"
names(KOF)[names(KOF)=="KOFSoGI"] = "soc_glob"
names(KOF)[names(KOF)=="KOFIpGI"] = "pers_cont"
names(KOF)[names(KOF)=="KOFInGI"] = "info_flow"
names(KOF)[names(KOF)=="KOFCuGI"] = "cult_prox"
names(KOF)[names(KOF)=="KOFPoGI"] = "poli_glob"
names(KOF)[names(KOF)=="KOFGI"] = "overallGlob_index"

# remove unneeded variables
KOF <- KOF[, c("country" ,"year", "overallGlob_index", "eco_glob", "act_flow", "restr", "soc_glob", "info_flow", "cult_prox", "poli_glob")]


#Append country IDs
KOF = append_ids(KOF)

# Label Variables ##########
# TODO

# Append suffix to vairables 
KOF = append_suffix(KOF,"KOF")

save(KOF,file=paste(preppeddata,"PREPPED_KOF_SW_2019.RDATA",sep=""))
