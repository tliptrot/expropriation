###############################
# Relative Political Capacity
# Accessed 3/30/2018
# Year Range: 1960-2012
# Suffix: RPC
# Dataset last update: Nov 21, 2013
#
# Data: https://dataverse.harvard.edu/file.xhtml;jsessionid=7eba997ee402bfea547b42a7ac5e?fileId=2449265&version=RELEASED&version=.0
# Codebook: https://dataverse.harvard.edu/file.xhtml?fileId=2449266&version=RELEASED&version=.0
#
# Citation: Marina Arbetman-Rabinowitz; Ali Fisunoglu; Jacek Kugler; Mark Abdollahian; Kristin Johnson; Kyungkook Kang; Zining Yang, 2011,
# "Replication data for: Relative Political Capacity Dataset", https://hdl.handle.net/1902.1/16845, Harvard Dataverse, V4; RPC_v2.1_2013.xlsx [fileName]
#
# Variables: rpe_agri: Relative Political Extraction (Model 1), rpe_gdp: Relative Political Extraction (Model 2),
# rpe_gdp_oecd: Relative Political Extraction with the adjusted OECD data (Model 2),
# rpr_work: Relative Political Reach (Model 3), rpr_eap: Relative Political Reach (Model 4),
# rpa1: Relative Political Allocation (Model 5), rpa2: Relative Political Allocation with income partitions (Model 5)
#
# Prepped by Stephen Campbell, 04/2018
################################

library(readxl)
library(Hmisc)

library(dplyr)
library(tidyr)
library(stringr)

#read in data
RPC <- read_excel(paste(rawdata, "RAWDATA_RPC_2012.xlsx",sep=""))

#Remove unused variables
RPC <- RPC[, c("country", "year", "rpe_agri", "rpe_gdp", "rpe_gdp_oecd", "rpr_work","rpr_eap","rpa1","rpa2")]

#change labels, using codebook as reference. Link:https://www.researchgate.net/publication/271588514_Relative_Political_Capacity_Dataset_Documentation-
label(RPC$rpe_agri) <- "Relative Political Extraction (Model 1) [RPE]"
label(RPC$rpe_gdp) <- "Relative Political Extraction (Model 2) [RPE]"
label(RPC$rpe_gdp_oecd) <- "Relative Political Extraction with the adjusted OECD data (Model 2) [RPE]"
label(RPC$rpr_work) <- "Relative Political Reach (Model 3) [RPE]"
label(RPC$rpr_eap) <- "Relative Political Reach (Model 4) [RPE]"
label(RPC$rpa1) <- "Relative Political Allocation (Model 5) [RPE]"
label(RPC$rpa2) <- "Relative Political Allocation with income partitions (Model 5) [RPE]"

#appending gwnos
RPC = append_ids(RPC, breaks = F)
RPC = append_suffix(RPC, "RPC")

range(RPC$year) # 1960 2012
length(unique(RPC$gwno)) # 191

#saving prepped data, finished on 04-12-2018
save(RPC,file=paste(preppeddata,"prepped_RPC_SC_040122018.RDATA",sep=""))

                     