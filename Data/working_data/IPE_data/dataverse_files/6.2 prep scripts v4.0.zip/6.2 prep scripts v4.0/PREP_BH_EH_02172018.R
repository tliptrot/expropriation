# /*************************
#   Bodea and Hicks Central Bank Independence Data
# 
# Source: Bodea, Cristina, and Raymond Hicks.  2015.  "Price Stability 
# and Central Bank Independence: Discipline, Credibility, and 
# Democratic Institutions."  International Organization 69: 35-61.
# 
# URL: http://www.princeton.edu/~rhicks/data/cb_rh_data.zip
# 
# Updated On: 2018.02.17
# Updated By: Emily
# Variables:
#   - Central Bank Independence score
# - Weighted Central Bank Independence score
# - Reform year (yes/no)
# *************************/
library(foreign)
library(Hmisc)

bh = read.dta(paste(rawdata,"RAWDATA_BH_2010.dta",sep=""))

#Keep only the variables we need
bh = bh[, c("year", "lvau", "lvaw", "reform", "countryname", "cowcode")]

#Rename some variables
names(bh)[names(bh)=="lvau"] = "cbi"
names(bh)[names(bh)=="lvaw"] = "cbiw"

#Append country IDs
bh = append_ids(bh, breaks = F)

#Add variable labels
label(bh$cbi) <- "Central bank indepedence score [BH]"
label(bh$cbiw) <- "Weighted Central Bank Independence score [BH]"
label(bh$reform) <- "Reform year (yes/no) [BH]"

bh = append_suffix(bh,"BH")

length(unique(bh$gwno)) #83
range(bh$year) #1972 - 2010

save(bh,file=paste(preppeddata,"PREPPED_BH_EH_02172018.RDATA",sep=""))
