#/**************************
# Data: Penn World Table version 9.0
# Dataset: Penn World Table version 9.0
# Data source url: http://www.rug.nl/ggdc/productivity/pwt/
# Codebook url: http://www.rug.nl/ggdc/docs/user_guide_to_pwt90_data_files.pdf
# Time: 1950-2017
# Updated: MAY 2020
# By: MB
# Suffix: PW  
# 
# Citation:
#  Feenstra, Robert C., Robert Inklaar, and Marcel P. Timmer. 2015. 
#  “The Next Generation of the Penn World Table.” American Economic Review 105(10): 3150–3182. 
#  Available for download at www.ggdc.net/pwt.
# #****************************/

library(Hmisc)
library(readstata13)

pw = read.dta13(paste(rawdata,"RAWDATA_PW_2017.dta",sep=""))


#Keep variables we are interestd 
pw = pw[, c("country", "currency_unit", "year", "rgdpe", "rgdpo", "pop", "emp",
            "hc", "cgdpe", "cgdpo", "ck", "ctfp", "rgdpna", "rkna", 
            "rtfpna","rwtfpna", "labsh", "xr", "statcap")]


# Number of unique countries and observations
length(unique(pw$country)) #182
length(pw$country) #11830


#Append country IDs
pw = append_ids(pw)


# Number of countries and observations after cleaning
length(unique(pw$country)) #175
length(pw$country) #11180

#Add variable labels
label(pw$currency_unit) <- "Currency Unit [PW]"
label(pw$rgdpe) <- "Expenditure-side real GDP at chained PPPs (in mil. 2011US$) [PW]"
label(pw$rgdpo) <- "Output-side real GDP at chained PPPs (in mil. 2011US$) [PW]"
label(pw$pop) <- "Population (in millions) [PW]"
label(pw$emp) <- "Number of persons engaged (in millions) [PW]"
label(pw$hc) <- "Average annual hours worked by persons engaged [PW]"
label(pw$cgdpe) <- "Expenditure-side real GDP at current PPPs (in mil. 2011US$) [PW]"
label(pw$cgdpo) <- "Output-side real GDP at current PPPs (in mil. 2011US$) [PW]"
label(pw$ck) <- "Capital stock at current PPPs (in mil. 2011US$) [PW]"
label(pw$ctfp) <- "TFP level at current PPPs (USA=1) [PW]"
label(pw$rgdpna) <- "Real GDP at constant 2011 national prices (in mil. 2011US$) [PW]"
label(pw$rkna) <- "Capital stock at constant 2011 national prices (in mil. 2011US$) [PW]"
label(pw$rtfpna) <- "TFP at constant national prices (2011=1) [PW]"
label(pw$rwtfpna) <- "Welfare-relevant TFP at constant national prices (2011=1) [PW]"
label(pw$labsh) <- "Share of labor compensation in GDP at current national prices [PW]"
label(pw$xr) <- "Exchange rate, national currency/USD (market+estimated) [PW]"
label(pw$statcap) <- "Statistical capacity indicator (source: World Bank, developing countries only) [PW]"





# Append suffix
pw = append_suffix(pw,"PW")

save(pw,file=paste(preppeddata,"PREPPED_PW_SW_051420.RDATA",sep=""))
