# /**************************
# Data: World Bank's World Development Indicators 
# Dataset: 
# Data source url: https://datacatalog.worldbank.org/%23
# Codebook url: 
# Time: 1960-2009
# Updated: 2018.02.19
# By: Emily on 2018.02.19
# Edited MB 5/5/2020
# Suffix: WB
# 
# Citation:
#   The World Bank. World Development Indicators 2010. http://data.worldbank.org/data-
# catalog/world-development- indicators/wdi-2010. Accessed on May 5 2020.
# 
# #****************************/

library(reshape2)
library(Hmisc)

wb = read.csv(paste(rawdata, "RAWDATA_WB_2010.csv", sep=""), header = F, stringsAsFactors = F)
names(wb) <- wb[3,]
wb <- wb[-c(1,2,3),]


# Keep the variables we need
# We no longer need to keep the Series Name variable
# The only variables we have left in the dataset are for Daily Newspapers
wb = wb[, c("Country Name", "1960":"2019")]

# Rename Country
names(wb)[names(wb)=="Country Name"] = "country"

# Reshape the dataset
wb = melt(wb, id=c("country"))

wb <- wb[!is.na(wb$value),]

# Rename variables
names(wb)[names(wb)=="value"] = "news"
names(wb)[names(wb) == "variable"] <- "year"
wb$year <- as.numeric(as.character(wb$year))

# Append Ids
wb$country[wb$country == "Korea"] <- "ROK"
wb = append_ids(wb, breaks = F)

# Label Variables
label(wb$news) <- "Daily newspapers (per 1,000 people) [WB]"

# Number of unique countries
length(unique(wb$country)) #176

# Range of years
range(wb$year) # 1970 - 2005

# Append Suffix
wb = append_suffix(wb, "WB")

save(wb,file=paste(preppeddata,"PREPPED_WB_MB_05052020.RDATA",sep=""))
