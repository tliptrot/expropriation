# /**************************/
# Data: Global Financial Development Report 2017/2018: Banking without Borders 
# Dataset: Financial Structure Dataset
# Data Source URL: http://www.worldbank.org/en/publication/gfdr/data/financial-structure-database
# Codebook URL: 
# Time: 1960 - 2015
# By: Emily on 03.29.18
# Suffix: FS
# 
# Citation: 
# Beck, Thorsten, Asli Demirgüç-Kunt, and Ross Levine. 2000. “A New Database on Financial
# Development and Structure.” World Bank Economic Review 14: 597–605. (An earlier version was
# issued as World Bank Policy Research Working Paper 2146.).
#
# Beck, Thorsten, Aslı Demirgüç-Kunt, and Ross Levine. 2010. “Financial Institutions and Markets
# across Countries and over Time: The Updated Financial Development and Structure Database.”
# The World Bank Economic Review 24(1): 77–92.
#
# Čihák, Martin, Asli Demirgüç-Kunt, Erik Feyen, and Ross Levine. 2012. “Benchmarking
# Financial Development Around the World.” World Bank Policy Research Working Paper 6175,
# August 2012.
#
# /****************************/

library(Hmisc)
library(readxl)

#import
fs <- read_excel(paste(rawdata,"RAWDATA_FS_2017.xlsx", sep = ""), sheet = 3, skip = 1, col_names = TRUE)

#Rename variables
names(fs)[names(fs)=="cncode"] = "ifs"
names(fs)[names(fs)=="pcrdbgdp"] = "pcredb"
names(fs)[names(fs)=="pcrdbofgdp"] = "pcredbo"

#Keep variables we are interested in
fs = fs[,c("country", "year", "pcredb", "pcredbo")]

#label variables
label(fs$pcredb) <- "Private credit by deposit money banks (% GDP) [FS]"
label(fs$pcredbo) <- "Private credit by money banks and other financial institutions (% GDP)"
 
#Change name of Sao Tome and Principe
fs$country[fs$ifs=="STP"] <- "Sao Tome and Principe"

#Append ids
fs = append_ids(fs, breaks = F)

#number of unique countries
length(unique(fs$gwno)) #126

#range of dataset
range(fs$year) #1960 - 2015

#Append suffix
fs = append_suffix(fs, "FS")

save(fs,file=paste(preppeddata, "PREPPED_FS_EH_03302018.RDATA", sep=""))
